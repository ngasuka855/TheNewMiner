﻿<#
TheNewMiner on Windows through WSL2 - setup and daily use. Windows PowerShell 5.1 (every Windows 10 / 11) or newer.
TheNewMiner.bat passes every argument here unchanged:

  TheNewMiner.bat [ACTION] [-Package FILE|URL] [-Sha256 HEX] [-Wallet W] [-Worker NAME] [-Proxy SPEC]
                  [-DataDir DIR] [-Lang en|zh-Hant|zh-Hans] [-Background] [-NoStart] [-Yes]
  ACTION = auto (default: install if needed, then mine) | setup | start | background | logs | stop | status | uninstall

The miner is our LINUX package, unchanged, inside a dedicated WSL2 distribution "TheNewMiner" (registered from the
Ubuntu 24.04 image, so a user's own Ubuntu is never touched): ~/thenewminer/<package> on WSL's own disk, never /mnt/c.
tnm-wsl.sh (beside this file) is the part that runs inside WSL. No proxy is built in. Elevation (UAC) is asked only to
turn WSL on.

Where things live (none of it inside the kit folder, so the kit can be moved or deleted; an upgrade is simply the new
zip unpacked anywhere and double-clicked):
  - the distro's disk + the model: a data folder chosen ONCE at the first install (shown with its free space, Enter
    accepts); later launches find it through the WSL registration (HKCU\...\Lxss, DistributionName, BasePath);
  - %LOCALAPPDATA%\TheNewMiner: per-user, locked to the user / SYSTEM / Administrators: the copy of tnm-wsl.sh and the
    staging copy of the package (its sha256 is checked again inside WSL right before unpacking).
The Linux package is the one bundled in files\ (its .sha256 is mandatory). -Package installs another one, only with a
sha256 (-Sha256, or a .sha256 / SHA256SUMS beside it). Newer vs older is decided by the version and revision in the
file name (TheNewMiner-vX.Y.Z-linux-x86_64-sealed[-rN].tar.xz), never by file dates.
#>
[CmdletBinding(PositionalBinding = $false)]
param(
    [Parameter(Position = 0)]
    [string]$Action = 'auto',
    [string]$Package = '',
    [string]$Sha256 = '',
    [string]$Wallet = '',
    [string]$Worker = '',
    [string]$Proxy = '',
    [string]$DataDir = '',
    [ValidateSet('auto', 'en', 'zh-Hant', 'zh-Hans')]
    [string]$Lang = 'auto',
    [string]$Distro = 'TheNewMiner',
    [switch]$Background,
    [switch]$NoStart,
    [switch]$Yes
)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$env:WSL_UTF8 = '1'                      # wsl.exe's own messages in UTF-8 (older WSL ignores it: NULs are stripped)
$MinDriver = 580
$MinBuild = 19044                         # Windows 10 21H2: the oldest Windows whose WSL2 has the GPU
$NeedFreshGb = 20                         # a first install: Ubuntu + the 8.1 GiB model + the miner
$BaseDistro = 'Ubuntu-24.04'              # the distro image registered under the dedicated name $Distro
$KitRoot = Split-Path -Parent $PSScriptRoot   # the kit folder (this ps1 lives in files\)
$EntryBat = Join-Path $KitRoot 'TheNewMiner.bat'
$LocalBase = Join-Path $env:LOCALAPPDATA 'TheNewMiner'
$StageDir = Join-Path $LocalBase 'stage'
$InnerSrc = Join-Path $PSScriptRoot 'tnm-wsl.sh'
$InnerWin = Join-Path $LocalBase 'wsl\tnm-wsl.sh'
$DataMarker = '.thenewminer-data'         # written into a data folder we created: uninstall removes only such a folder
$OnWindows = ([Environment]::OSVersion.Platform -eq 'Win32NT')
$Script:InnerLinux = ''
$Script:HelpText = ''
$Script:Plan = New-Object System.Collections.Specialized.OrderedDictionary

function Say([string]$m) { Write-Host $m }
function Warn([string]$m) { Write-Host ((T 'warn_prefix') + $m) -ForegroundColor Yellow }
function Fail([string]$m, [int]$code = 1) {
    Write-Host ''
    Write-Host ((T 'fail_prefix') + $m) -ForegroundColor Red
    exit $code
}
function Fmt([double]$x) { if ($x -lt 1) { return '<1' } return [string][math]::Ceiling($x) }
# The on-screen language: -Lang wins, else the Windows UI language (zh-TW/HK/MO -> 繁體, zh-CN/SG -> 简体, else English).
function Pick-Lang([string]$want) {
    if ($want -and $want -ne 'auto') { return $want }
    $c = ''
    try { $c = (Get-UICulture).Name } catch { }
    switch -Wildcard ($c) {
        'zh-Hant*' { return 'zh-Hant' }
        'zh-TW*' { return 'zh-Hant' }
        'zh-HK*' { return 'zh-Hant' }
        'zh-MO*' { return 'zh-Hant' }
        'zh-Hans*' { return 'zh-Hans' }
        'zh-CN*' { return 'zh-Hans' }
        'zh-SG*' { return 'zh-Hans' }
        default { return 'en' }
    }
}
$Script:Lang = Pick-Lang $Lang

# Every line shown to people, by message id: @(zh-Hant, zh-Hans, en). One entry per line (tools/test_windows_wsl.py
# reads this table: every id in all three languages, no Cantonese in zh-Hans / en).
$Script:Msg = @{
    'warn_prefix' = @('注意:', '注意:', 'Note: ')
    'fail_prefix' = @('失敗:', '失败:', 'Failed: ')
    'shortcut_made' = @('  已經喺桌面整咗「TheNewMiner」捷徑。', '  已在桌面创建“TheNewMiner”快捷方式。', '  A "TheNewMiner" shortcut was put on the desktop.')
    'step_hdr' = @('[{0}/{1}] {2}(約 {3} 分鐘)— 全部剩約 {4} 分鐘,預計 {5} 完成(本機時間,香港 {6})', '[{0}/{1}] {2}(约 {3} 分钟)— 全部剩余约 {4} 分钟,预计 {5} 完成(本地时间,香港 {6})', '[{0}/{1}] {2} (about {3} min) - about {4} min left in total, done about {5} local time ({6} Hong Kong time)')
    'uac_hint' = @('  (會彈出 Windows 嘅管理員權限確認,請撳「是」)', '  (会弹出 Windows 管理员权限确认,请点击“是”)', '  (Windows will ask for administrator permission: click "Yes")')
    'no_inner' = @('搵唔到 {0}:tnm-wsl.sh 要同呢個檔放喺同一個資料夾。', '找不到 {0}:tnm-wsl.sh 必须和这个文件放在同一个文件夹。', 'Cannot find {0}: tnm-wsl.sh must be in the same folder as this file.')
    'no_wslpath' = @('{0} 入面搵唔到 {1}(wslpath)。', '在 {0} 中找不到 {1}(wslpath)。', 'Cannot find {1} inside {0} (wslpath).')
    'need_wsl' = @('未裝 WSL:請先雙擊 TheNewMiner.bat。', '未安装 WSL:请先双击 TheNewMiner.bat。', 'WSL is not installed: double-click TheNewMiner.bat first.')
    'need_distro' = @('未裝 {0}:請先雙擊 TheNewMiner.bat。', '未安装 {0}:请先双击 TheNewMiner.bat。', '{0} is not installed: double-click TheNewMiner.bat first.')
    'help_title' = @('之後點用(喺 TheNewMiner.bat 同一個資料夾,或者用桌面「TheNewMiner」捷徑):', '之后怎么用(在 TheNewMiner.bat 所在的文件夹,或者使用桌面“TheNewMiner”快捷方式):', 'How to use it from now on (in the folder of TheNewMiner.bat, or with the "TheNewMiner" desktop shortcut):')
    'help_start' = @('  開始挖(有視窗,關咗視窗就停):      TheNewMiner.bat', '  开始挖矿(有窗口,关闭窗口即停止):  TheNewMiner.bat', '  Mine in a window (closing it stops):            TheNewMiner.bat')
    'help_bg' = @('  背景挖(冇視窗):                   TheNewMiner.bat background', '  后台挖矿(无窗口):                  TheNewMiner.bat background', '  Mine without a window:                          TheNewMiner.bat background')
    'help_logs' = @('  睇 log(Ctrl+C 離開,礦工照挖):     TheNewMiner.bat logs', '  查看日志(Ctrl+C 退出,矿工继续挖): TheNewMiner.bat logs', '  Watch the log (Ctrl+C leaves, mining goes on): TheNewMiner.bat logs')
    'help_stop' = @('  停:                                TheNewMiner.bat stop', '  停止:                              TheNewMiner.bat stop', '  Stop:                                           TheNewMiner.bat stop')
    'help_status' = @('  狀態同最近速度:                    TheNewMiner.bat status', '  状态和最近速度:                    TheNewMiner.bat status', '  Status and recent rates:                        TheNewMiner.bat status')
    'bg_started' = @('背景挖緊礦(冇視窗,挖緊嗰陣 Windows 唔會瞓)。登出或者重新開機會停;之後用 TheNewMiner.bat background 再開。', '正在后台挖矿(无窗口,挖矿期间 Windows 不会休眠)。注销或重启会停止;之后用 TheNewMiner.bat background 重新开始。', 'Mining in the background (no window; Windows does not sleep while it mines). Signing out or restarting stops it; start it again with TheNewMiner.bat background.')
    'bg_hint' = @('睇 log:TheNewMiner.bat logs     停:TheNewMiner.bat stop', '查看日志:TheNewMiner.bat logs     停止:TheNewMiner.bat stop', 'Log: TheNewMiner.bat logs     Stop: TheNewMiner.bat stop')
    'fg_started' = @('挖礦開始。呢個視窗要開住(關咗就停);停:撳 Ctrl+C,或者另一個視窗打 TheNewMiner.bat stop。', '开始挖矿。请保持这个窗口打开(关闭即停止);停止:按 Ctrl+C,或者在另一个窗口输入 TheNewMiner.bat stop。', 'Mining started. Keep this window open (closing it stops mining); to stop, press Ctrl+C or run TheNewMiner.bat stop in another window.')
    'already_bg' = @('已經挖緊(可能喺背景)。睇 log:TheNewMiner.bat logs', '已经在挖矿(可能在后台)。查看日志:TheNewMiner.bat logs', 'Already mining (maybe in the background). Log: TheNewMiner.bat logs')
    'already' = @('已經挖緊。睇 log:TheNewMiner.bat logs', '已经在挖矿。查看日志:TheNewMiner.bat logs', 'Already mining. Log: TheNewMiner.bat logs')
    'version' = @('版本:', '版本:', 'Version: ')
    'state_on' = @('狀態:挖緊', '状态:正在挖矿', 'Status: mining')
    'state_off' = @('狀態:冇挖', '状态:没有在挖矿', 'Status: not mining')
    'inst_running' = @('已安裝 v{0},而且已經挖緊。以下係 log(Ctrl+C 離開,礦工照挖):', '已安装 v{0},并且已经在挖矿。以下是日志(Ctrl+C 退出,矿工继续挖):', 'v{0} is installed and already mining. Here is its log (Ctrl+C leaves, mining goes on):')
    'inst_start' = @('已安裝 v{0},直接開始挖礦(改設定:TheNewMiner.bat setup)。', '已安装 v{0},直接开始挖矿(修改设置:TheNewMiner.bat setup)。', 'v{0} is installed, starting to mine (to change the settings: TheNewMiner.bat setup).')
    'title' = @('TheNewMiner Windows 安裝(WSL2)', 'TheNewMiner Windows 安装(WSL2)', 'TheNewMiner Windows setup (WSL2)')
    'intro' = @('礦工程式係 Linux 版,喺 Windows 內置嘅 WSL2(Ubuntu)入面行;數值同 Linux 一樣。', '矿工程序是 Linux 版,在 Windows 内置的 WSL2(Ubuntu)中运行;计算结果与 Linux 相同。', 'The miner is the Linux build; it runs in WSL2 (Ubuntu), which is built into Windows, with the same results as on Linux.')
    'step1' = @('Windows 同 NVIDIA driver', 'Windows 和 NVIDIA 驱动', 'Windows and the NVIDIA driver')
    'need64' = @('要 64 位元 Windows 10 / 11。', '需要 64 位 Windows 10 或 11。', '64-bit Windows 10 or 11 is required.')
    'old_win' = @('Windows 版本太舊(build {0}):要 Windows 10 21H2(19044)或更新,或者 Windows 11。請先做 Windows Update。', 'Windows 版本太旧(build {0}):需要 Windows 10 21H2(19044)或更新版本,或者 Windows 11。请先运行 Windows 更新。', 'This Windows is too old (build {0}); Windows 10 21H2 (19044) or later, or Windows 11, is required. Run Windows Update first.')
    'no_driver' = @('搵唔到 NVIDIA driver(nvidia-smi.exe)。請由 https://www.nvidia.com/Download/index.aspx 安裝 580 或更新嘅 driver,重新開機再試。', '找不到 NVIDIA 驱动(nvidia-smi.exe)。请从 https://www.nvidia.com/Download/index.aspx 安装 580 或更新版本的驱动,重启电脑后再试。', 'No NVIDIA driver found (nvidia-smi.exe). Install driver 580 or newer from https://www.nvidia.com/Download/index.aspx, restart Windows and try again.')
    'smi_broken' = @('nvidia-smi 用唔到:請重新安裝 NVIDIA driver(580 或更新),重新開機再試。', 'nvidia-smi 无法使用:请重新安装 NVIDIA 驱动(580 或更新),重启电脑后再试。', 'nvidia-smi does not work: reinstall the NVIDIA driver (580 or newer), restart Windows and try again.')
    'gpu_line' = @('  GPU:{0},{1} MiB,driver {2}', '  GPU:{0},{1} MiB,驱动 {2}', '  GPU: {0}, {1} MiB, driver {2}')
    'low_vram' = @('呢張卡而家得 {0} MiB 空(桌面 / 瀏覽器用緊)。10-12 GB 卡要 9472 MiB 空先行快速模式;顯示器可以接去主機板(內顯),或者挖礦時關咗其他程式。', '这张显卡目前只有 {0} MiB 空闲(桌面 / 浏览器正在占用)。10-12 GB 显卡需要 9472 MiB 空闲才能运行快速模式;可以把显示器接到主板(核显),或者挖矿时关闭其他程序。', 'This card has only {0} MiB free right now (the desktop / browser use the rest). A 10-12 GB card needs 9472 MiB free for the fast mode: plug the display into the motherboard (integrated graphics), or close other programs while mining.')
    'old_driver' = @('NVIDIA driver {0} 太舊:要 {1} 或更新。請由 https://www.nvidia.com/Download/index.aspx 更新,重新開機再試。唔好喺 WSL 入面裝 driver。', 'NVIDIA 驱动 {0} 太旧:需要 {1} 或更新版本。请从 https://www.nvidia.com/Download/index.aspx 更新,重启电脑后再试。不要在 WSL 中安装驱动。', 'NVIDIA driver {0} is too old: {1} or newer is needed. Update it from https://www.nvidia.com/Download/index.aspx, restart Windows and try again. Never install a driver inside WSL.')
    'low_data' = @('資料夾 {0} 嘅磁碟得 {1} GB 空位:要約 {2} GB 放 Ubuntu + 模型 8.1 GiB + 礦工。可以用 TheNewMiner.bat setup -DataDir <路徑> 揀第二個磁碟。', '文件夹 {0} 所在磁盘只有 {1} GB 可用空间:需要约 {2} GB 存放 Ubuntu + 模型 8.1 GiB + 矿工。可以用 TheNewMiner.bat setup -DataDir <路径> 选择其他磁盘。', 'The drive of {0} has only {1} GB free: about {2} GB is needed for Ubuntu + the 8.1 GiB model + the miner. Pick another drive with TheNewMiner.bat setup -DataDir <path>.')
    'low_sys' = @('{0}: 得 {1} GB 空位:WSL 本身要約 1 GB。', '{0}: 只有 {1} GB 可用空间:WSL 本身需要约 1 GB。', '{0}: has only {1} GB free: WSL itself needs about 1 GB.')
    'sys_line' = @('  Windows build {0},RAM {1} GB,{2} 有 {3} GB 空', '  Windows build {0},内存 {1} GB,{2} 可用 {3} GB', '  Windows build {0}, RAM {1} GB, {2} {3} GB free')
    'low_ram' = @('RAM 得 {0} GB:挖礦得,但第一次安裝會慢啲。', '内存只有 {0} GB:可以挖矿,但第一次安装会慢一些。', 'Only {0} GB of RAM: mining works, but the first install is slower.')
    'no_virt' = @('BIOS 似乎冇開虛擬化(Intel VT-x / AMD SVM)。WSL2 要佢:如果下面裝唔到 Ubuntu,入 BIOS 開咗再試。', 'BIOS 似乎没有开启虚拟化(Intel VT-x / AMD SVM)。WSL2 需要它:如果下面无法安装 Ubuntu,请进入 BIOS 开启后再试。', 'Virtualization (Intel VT-x / AMD SVM) seems to be off in the BIOS. WSL2 needs it: if Ubuntu fails to install below, turn it on in the BIOS and try again.')
    'step2' = @('開啟 WSL2', '开启 WSL2', 'Turning on WSL2')
    'wsl_enabling' = @('  開啟 WSL(Windows Subsystem for Linux),要下載同安裝幾分鐘 ...', '  正在开启 WSL(Windows Subsystem for Linux),下载和安装需要几分钟 ...', '  Turning on WSL (Windows Subsystem for Linux): a few minutes of download and install ...')
    'wsl_need_admin' = @('開 WSL 要管理員權限:請再雙擊 TheNewMiner.bat,彈出確認時撳「是」。', '开启 WSL 需要管理员权限:请再次双击 TheNewMiner.bat,弹出确认时点击“是”。', 'Turning on WSL needs administrator rights: double-click TheNewMiner.bat again and click "Yes" when asked.')
    'wsl_fail' = @('開唔到 WSL(結束碼 {0})。請檢查網絡同 Windows Update,之後再試。', '无法开启 WSL(退出码 {0})。请检查网络和 Windows 更新,然后再试。', 'Could not turn on WSL (exit code {0}). Check the network and Windows Update, then try again.')
    'wsl_after_reboot' = @('已經重開過機,WSL 仍然未用得。請喺 Microsoft Store 裝「Windows Subsystem for Linux」,或者打 wsl --install,完成後再試。', '已经重启过电脑,WSL 仍然无法使用。请在 Microsoft Store 安装“Windows Subsystem for Linux”,或者输入 wsl --install,完成后再试。', 'Windows was restarted but WSL still does not work. Install "Windows Subsystem for Linux" from the Microsoft Store, or run wsl --install, then try again.')
    'need_reboot' = @('WSL 已經開咗,要重新開機先用得。重新開機之後會自動由呢度繼續(亦可以自己再雙擊 TheNewMiner.bat)。', 'WSL 已经开启,需要重启电脑才能使用。重启后会自动从这里继续(也可以自己再次双击 TheNewMiner.bat)。', 'WSL is on but needs a restart. After the restart, setup continues from here by itself (or double-click TheNewMiner.bat again).')
    'wsl_updating' = @('  更新 WSL(Ubuntu 24.04 要 WSL 2.4.4 或更新)...', '  正在更新 WSL(Ubuntu 24.04 需要 WSL 2.4.4 或更新版本)...', '  Updating WSL (Ubuntu 24.04 needs WSL 2.4.4 or newer) ...')
    'wsl_update_admin' = @('更新 WSL 要管理員權限:請再雙擊 TheNewMiner.bat,彈出確認時撳「是」。', '更新 WSL 需要管理员权限:请再次双击 TheNewMiner.bat,弹出确认时点击“是”。', 'Updating WSL needs administrator rights: double-click TheNewMiner.bat again and click "Yes" when asked.')
    'wslconfig' = @('  WSL 設定 {0}:{1}(下次 WSL 開機生效)', '  WSL 设置 {0}:{1}(下次 WSL 启动时生效)', '  WSL settings {0}: {1} (they take effect at the next WSL start)')
    'step3' = @('安裝 {0}(下載約 300-600 MB)', '安装 {0}(下载约 300-600 MB)', 'Installing {0} (about 300-600 MB download)')
    'data_prompt' = @('  撳 Enter 用呢個位置,或者打另一個資料夾', '  按 Enter 使用这个位置,或者输入其他文件夹', '  Press Enter to use it, or type another folder')
    'no_location' = @('  呢個 WSL 唔支援 --location:資料會放喺 WSL 嘅預設位置(C: 你嘅用戶資料夾)。', '  这个 WSL 不支持 --location:数据将存放在 WSL 的默认位置(C: 盘你的用户文件夹)。', '  This WSL does not support --location: the data goes to the default WSL location (your user folder on C:).')
    'reboot_again' = @('請重新開機,之後再雙擊 TheNewMiner.bat。', '请重启电脑,然后再次双击 TheNewMiner.bat。', 'Please restart Windows, then double-click TheNewMiner.bat again.')
    'distro_fail' = @('{0} 裝唔到(wsl --install 結束碼 {1})。上面有 WSL 嘅訊息;見到 0x80370102 就入 BIOS 開虛擬化,其他情況請打 wsl --update 再試。', '{0} 安装失败(wsl --install 退出码 {1})。上方有 WSL 的信息;如果看到 0x80370102,请进入 BIOS 开启虚拟化;其他情况请运行 wsl --update 后再试。', '{0} could not be installed (wsl --install exit code {1}). The WSL message is above; 0x80370102 means virtualization is off in the BIOS; otherwise run wsl --update and try again.')
    'distro_nostart' = @('{0} 開唔到。請喺開始功能表開一次「{0}」(佢會要你建立一個 Linux 用戶),之後再雙擊 TheNewMiner.bat。', '{0} 无法启动。请在开始菜单中打开一次“{0}”(它会要求你创建一个 Linux 用户),然后再次双击 TheNewMiner.bat。', '{0} could not be started. Open "{0}" once from the Start menu (it asks you to create a Linux user), then double-click TheNewMiner.bat again.')
    'restart_wsl_q' = @('  新嘅 WSL 設定要重新開 WSL 先生效:會行 wsl --shutdown,停晒所有 WSL distro(而家行緊:{0})。而家重開?(y = 重開 / Enter = 下次先)', '  新的 WSL 设置需要重启 WSL 才能生效:将运行 wsl --shutdown,停止所有 WSL 发行版(正在运行:{0})。现在重启吗?(y = 重启 / Enter = 下次再说)', '  The new WSL settings take effect after WSL restarts: this runs wsl --shutdown, which stops every WSL distribution (running now: {0}). Restart now? (y = restart / Enter = later)')
    'wsl_restarting' = @('  重新開 WSL 令設定生效 ...', '  正在重启 WSL,使设置生效 ...', '  Restarting WSL so that the settings take effect ...')
    'wsl_later' = @('  WSL 設定會喺下次 WSL 重新開(wsl --shutdown 或者重新開機)之後生效。', '  WSL 设置会在下次 WSL 重启(wsl --shutdown 或重启电脑)后生效。', '  The WSL settings take effect after the next WSL restart (wsl --shutdown or a Windows restart).')
    'wsl1_convert' = @('  {0} 係 WSL 1,轉做 WSL 2 ...', '  {0} 是 WSL 1,正在转换为 WSL 2 ...', '  {0} is WSL 1, converting it to WSL 2 ...')
    'step4' = @('WSL 入面:GPU、所需套件、時鐘', 'WSL 内部:GPU、所需软件包、时钟', 'Inside WSL: the GPU, the packages needed, the clock')
    'no_gpu_wsl' = @('WSL 入面見唔到 GPU:請更新 Windows 嘅 NVIDIA driver(580 或更新),喺命令提示字元打 wsl --shutdown,再雙擊 TheNewMiner.bat。', 'WSL 中看不到 GPU:请更新 Windows 的 NVIDIA 驱动(580 或更新),在命令提示符中输入 wsl --shutdown,然后再次双击 TheNewMiner.bat。', 'WSL cannot see the GPU: update the NVIDIA driver on Windows (580 or newer), run wsl --shutdown in a Command Prompt, then double-click TheNewMiner.bat again.')
    'still_wsl1' = @('{0} 仲係 WSL 1:請喺命令提示字元打 wsl --set-version {0} 2,再試。', '{0} 仍然是 WSL 1:请在命令提示符中输入 wsl --set-version {0} 2,然后再试。', '{0} is still WSL 1: run wsl --set-version {0} 2 in a Command Prompt and try again.')
    'check_fail' = @('WSL 入面嘅檢查失敗({0})。上面有詳細訊息。', 'WSL 内部检查失败({0})。详细信息见上方。', 'The check inside WSL failed ({0}). The details are above.')
    'check_incomplete' = @('WSL 入面嘅檢查冇完成。上面有詳細訊息。', 'WSL 内部检查没有完成。详细信息见上方。', 'The check inside WSL did not finish. The details are above.')
    'linux_driver_warn' = @('WSL 入面裝咗 Linux 版 NVIDIA driver,會遮住 Windows driver 嘅 GPU;如果之後出錯,請照上面講嘅移除。', 'WSL 中安装了 Linux 版 NVIDIA 驱动,会遮蔽 Windows 驱动提供的 GPU;如果之后出错,请按上面的说明将它移除。', 'A Linux NVIDIA driver is installed inside WSL and hides the GPU of the Windows driver; if errors follow, remove it as described above.')
    'step5' = @('礦工程式(Linux 包):用本機個包(或者下載)、核對 sha256、解壓入 WSL', '矿工程序(Linux 包):使用本地的包(或者下载)、校验 sha256、解压到 WSL', 'The miner (Linux package): use the local package (or download it), check its sha256, unpack it into WSL')
    'no_pkg' = @('搵唔到內置嘅礦工程式包(files\ 入面)。請用返完整個 zip 解壓,或者 TheNewMiner.bat setup -Package <檔案> -Sha256 <64 個字元>。', '找不到内置的矿工程序包(files\ 中)。请重新解压完整的 zip,或者使用 TheNewMiner.bat setup -Package <文件> -Sha256 <64 个字符>。', 'The bundled miner package (in files\) was not found. Unzip the complete zip again, or run TheNewMiner.bat setup -Package <file> -Sha256 <64 characters>.')
    'use_local' = @('  用內置嘅包(唔使下載):', '  使用内置的包(不用下载):', '  Using the bundled package (no download): ')
    'bad_name' = @('{0} 唔係 TheNewMiner 嘅 Linux 包(TheNewMiner-vX.Y.Z-linux-x86_64-sealed.tar.xz)。', '{0} 不是 TheNewMiner 的 Linux 包(TheNewMiner-vX.Y.Z-linux-x86_64-sealed.tar.xz)。', '{0} is not a TheNewMiner Linux package (TheNewMiner-vX.Y.Z-linux-x86_64-sealed.tar.xz).')
    'downloading' = @('  下載 {0}', '  下载 {0}', '  Downloading {0}')
    'dl_fail' = @('下載唔到 {0}(curl 結束碼 {1})。', '无法下载 {0}(curl 退出码 {1})。', 'Could not download {0} (curl exit code {1}).')
    'not_found' = @('搵唔到 {0}', '找不到 {0}', 'Not found: {0}')
    'url_no_sha' = @('網址包冇 sha256 可以核對:請俾 -Sha256 <64 個字元>,或者將 <網址>.sha256 放喺同一個網址。', '网址包没有可以校验的 sha256:请提供 -Sha256 <64 个字符>,或者把 <网址>.sha256 放在同一个网址。', 'The downloaded package has no sha256 to check: give -Sha256 <64 characters>, or publish <URL>.sha256 next to it.')
    'sha_bad' = @('sha256 唔啱:呢個包係 {0},應該係 {1}。包壞咗或者唔係官方嘅:唔好用。', 'sha256 不符:这个包是 {0},应该是 {1}。包已损坏或者不是官方的:请不要使用。', 'sha256 mismatch: this package is {0}, it should be {1}. It is damaged or not official: do not use it.')
    'sha_ok' = @('  sha256 啱:{0}', '  sha256 正确:{0}', '  sha256 OK: {0}')
    'stopping_old' = @('  停緊而家行緊嘅礦工(換版本之前)...', '  正在停止当前运行的矿工(更换版本之前)...', '  Stopping the running miner (before switching versions) ...')
    'unpack_fail' = @('解壓失敗({0})。', '解压失败({0})。', 'Unpacking failed ({0}).')
    'installed_at' = @('  裝咗喺 WSL 入面:', '  已安装到 WSL 中:', '  Installed inside WSL: ')
    'step6' = @('錢包、礦池密碼、礦工名、proxy', '钱包、矿池密码、矿工名、代理', 'Wallet, pool password, worker name, proxy')
    'prev_settings' = @('  之前嘅設定:錢包 {0},礦工名 {1},proxy {2}', '  之前的设置:钱包 {0},矿工名 {1},代理 {2}', '  Previous settings: wallet {0}, worker {1}, proxy {2}')
    'keep_q' = @('  沿用?(Y = 沿用 / n = 重新輸入)', '  继续使用吗?(Y = 继续使用 / n = 重新输入)', '  Keep them? (Y = keep / n = enter again)')
    'bad_worker' = @('礦工名:1-64 個英文字母、數字、. _ 或 -。', '矿工名:1-64 个英文字母、数字、. _ 或 -。', 'Worker name: 1-64 letters, digits, . _ or -.')
    'bad_proxy' = @('Proxy 格式唔啱:{0}', '代理格式不正确:{0}', 'Invalid proxy: {0}')
    'wallet_hint' = @('錢包地址要係 tc1 開頭(細楷英文字母同數字)。', '钱包地址必须以 tc1 开头(小写英文字母和数字)。', 'The wallet address starts with tc1 (lower-case letters and digits).')
    'wallet_q' = @('  錢包地址(tc1...)', '  钱包地址(tc1...)', '  Wallet address (tc1...)')
    'bad_wallet' = @('錢包地址唔啱。', '钱包地址不正确。', 'Invalid wallet address.')
    'pw_hint' = @('礦池密碼:6-128 個英文字母、數字、_ 或 -。', '矿池密码:6-128 个英文字母、数字、_ 或 -。', 'Pool password: 6-128 letters, digits, _ or -.')
    'pw_q' = @('  礦池密碼(6-128 個英文字母、數字、_ 或 -)', '  矿池密码(6-128 个英文字母、数字、_ 或 -)', '  Pool password (6-128 letters, digits, _ or -)')
    'pw_again' = @('  再輸入一次礦池密碼', '  再输入一次矿池密码', '  Pool password again')
    'pw_differ' = @('兩次唔同,再嚟。', '两次输入不一致,请重新输入。', 'The two entries differ, try again.')
    'bad_pw' = @('礦池密碼唔啱。', '矿池密码不正确。', 'Invalid pool password.')
    'worker_q' = @('  礦工名(礦池上顯示;直接撳 Enter = {0})', '  矿工名(显示在矿池上;直接按 Enter = {0})', '  Worker name (shown on the pool; Enter = {0})')
    'direct' = @('  直接連礦池(冇 proxy)。', '  直接连接矿池(不使用代理)。', '  Connecting directly to the pool (no proxy).')
    'via_proxy' = @('  經 proxy 連礦池(記住,之後唔使再俾)。', '  通过代理连接矿池(已记住,之后不用再提供)。', '  Connecting through the proxy (remembered, no need to give it again).')
    'installed_nostart' = @('裝好咗(未開始挖)。', '安装完成(还没有开始挖矿)。', 'Installed (not mining yet).')
    'not_saved' = @('錢包同密碼未儲存:第一次開始時請再雙擊 TheNewMiner.bat。', '钱包和密码还没有保存:第一次开始时请再次双击 TheNewMiner.bat。', 'The wallet and password are not saved yet: double-click TheNewMiner.bat again for the first start.')
    'step7' = @('第一次開始:下載模型(8.1 GiB)、測試 GPU、校準,之後開始挖', '第一次启动:下载模型(8.1 GiB)、测试 GPU、校准,然后开始挖矿', 'First start: download the model (8.1 GiB), test the GPU, calibrate, then mine')
    'dl_time' = @('  下載時間睇網速:100 Mbit/s 約 12 分鐘,500 Mbit/s 約 3 分鐘(進度行有剩餘時間);GPU 測試 1-2 分鐘,校準 1-3 分鐘。', '  下载时间取决于网速:100 Mbit/s 约 12 分钟,500 Mbit/s 约 3 分钟(进度行会显示剩余时间);GPU 测试 1-2 分钟,校准 1-3 分钟。', '  The download time depends on the network: about 12 min at 100 Mbit/s, 3 min at 500 Mbit/s (the progress line shows the time left); the GPU test takes 1-2 min, calibration 1-3 min.')
    'data_where' = @('  資料夾(Ubuntu 磁碟 + 模型):{0}(呢個磁碟有 {1} GB 空,要約 {2} GB)', '  数据文件夹(Ubuntu 磁盘 + 模型):{0}(该磁盘可用 {1} GB,需要约 {2} GB)', '  Data folder (the Ubuntu disk + the model): {0} ({1} GB free on that drive; about {2} GB is needed)')
    'data_not_kitdrive' = @('  (資料唔放喺 kit 所在嘅 {0}:{1})', '  (数据不放在 kit 所在的 {0}:{1})', '  (the data does not go on the drive of this kit, {0}: {1})')
    'why_removable' = @('佢係可移除磁碟', '它是可移动磁盘', 'it is a removable drive')
    'why_notntfs' = @('佢唔係 NTFS', '它不是 NTFS', 'it is not NTFS')
    'why_unc' = @('佢係網絡位置', '它是网络位置', 'it is a network location')
    'why_space' = @('佢空位唔夠', '它的空间不足', 'it has too little free space')
    'data_bad_path' = @('要完整路徑,例如 D:\TheNewMinerData。', '需要完整路径,例如 D:\TheNewMinerData。', 'Type a full path, for example D:\TheNewMinerData.')
    'data_low_try' = @('{0} 得 {1} GB 空,唔夠 {2} GB:請揀另一個磁碟。', '{0} 只有 {1} GB 可用,不足 {2} GB:请选择其他磁盘。', '{0} has only {1} GB free, less than {2} GB: pick another drive.')
    'data_missing' = @('搵唔到 TheNewMiner 嘅資料夾 {0}(個磁碟拔咗,定係資料夾刪咗?)。如果個磁碟返嚟咗,再雙擊 TheNewMiner.bat 就得;否則打 TheNewMiner.bat setup 重新建立(模型要重新下載)。', '找不到 TheNewMiner 的数据文件夹 {0}(磁盘被移除,还是文件夹被删除?)。如果磁盘已重新连接,再次双击 TheNewMiner.bat 即可;否则请运行 TheNewMiner.bat setup 重新创建(模型需要重新下载)。', 'The TheNewMiner data folder {0} is missing (was its drive removed, or the folder deleted?). If the drive is back, just start again; otherwise run TheNewMiner.bat setup to create it again (the model is downloaded again).')
    'data_recreate_q' = @('  {0} 已經冇咗。重新建立 TheNewMiner 嘅 WSL(舊嘅登記會移除)?(y = 重新建立 / Enter = 取消)', '  {0} 已不存在。重新创建 TheNewMiner 的 WSL(旧的注册会被移除)吗?(y = 重新创建 / Enter = 取消)', '  {0} is gone. Create the TheNewMiner WSL again (the old registration is removed)? (y = recreate / Enter = cancel)')
    'cancelled' = @('已取消。', '已取消。', 'Cancelled.')
    'datadir_ignored' = @('-DataDir 唔使用:{0} 已經裝喺 {1}。要搬位置就先 TheNewMiner.bat uninstall,再 TheNewMiner.bat setup -DataDir <路徑>。', '-DataDir 不使用:{0} 已经安装在 {1}。如需更换位置,请先运行 TheNewMiner.bat uninstall,再运行 TheNewMiner.bat setup -DataDir <路径>。', '-DataDir is not used: {0} is already installed in {1}. To move it, run TheNewMiner.bat uninstall, then TheNewMiner.bat setup -DataDir <path>.')
    'acl_warn' = @('  (設定唔到 {0} 嘅權限;照用,但其他 Windows 用戶可能睇到)', '  (无法设置 {0} 的权限;照常使用,但其他 Windows 用户可能看到)', '  (could not restrict the permissions of {0}; it is still used, but other Windows users may see it)')
    'low_sys_data' = @('{0} 得 {1} GB 空位:WSL 嘅預設位置要約 {2} GB。請打 wsl --update(之後可以揀其他磁碟),或者清出空位。', '{0} 只有 {1} GB 可用空间:WSL 的默认位置需要约 {2} GB。请运行 wsl --update(之后可以选择其他磁盘),或者清理空间。', '{0} has only {1} GB free: the default WSL location needs about {2} GB. Run wsl --update (then another drive can be chosen), or free some space.')
    'wslconfig_skip' = @('  呢部機仲有其他 WSL distro:唔改 {0}(唔郁佢哋嘅記憶體設定)。', '  这台电脑还有其他 WSL 发行版:不修改 {0}(不影响它们的内存设置)。', '  Other WSL distributions exist on this PC: {0} is left unchanged (their memory settings are not touched).')
    'none_word' = @('冇', '无', 'none')
    'clock_off' = @('WSL 時鐘同 Windows 差 {0:N1} 秒。如果礦工報時鐘錯誤:喺 Windows「設定 > 時間與語言」撳「立即同步」,再喺命令提示字元打 wsl --shutdown(會停晒所有 WSL distro),之後重新開始。', 'WSL 时钟与 Windows 相差 {0:N1} 秒。如果矿工报告时钟错误:在 Windows“设置 > 时间和语言”中点击“立即同步”,然后在命令提示符中输入 wsl --shutdown(会停止所有 WSL 发行版),再重新开始。', 'The WSL clock is {0:N1} s off Windows. If the miner reports a clock error: in Windows Settings > Time & language click "Sync now", then run wsl --shutdown in a Command Prompt (it stops every WSL distribution) and start again.')
    'bundle_no_sha' = @('內置嘅包冇 .sha256:{0}。呢個 zip 唔完整,請重新下載完整嘅 zip。', '内置的包没有 .sha256:{0}。这个 zip 不完整,请重新下载完整的 zip。', 'The bundled package has no .sha256: {0}. This zip is incomplete: download the complete zip again.')
    'pkg_no_sha' = @('{0} 冇 sha256 可以核對:請將 {0}.sha256(或者 SHA256SUMS)放喺佢旁邊,或者加 -Sha256 <64 個字元>。', '{0} 没有可以校验的 sha256:请把 {0}.sha256(或者 SHA256SUMS)放在它旁边,或者加上 -Sha256 <64 个字符>。', 'There is no sha256 to check {0}: put {0}.sha256 (or a SHA256SUMS) next to it, or add -Sha256 <64 characters>.')
    'pkg_keep_newer' = @('  已安裝嘅 v{0} 比內置嘅 v{1} 新:保留已安裝嘅版本。', '  已安装的 v{0} 比内置的 v{1} 新:保留已安装的版本。', '  The installed v{0} is newer than the bundled v{1}: the installed one is kept.')
    'pkg_same' = @('  v{0} 已經裝好(同一個包),唔使再解壓。', '  v{0} 已经安装(同一个包),无需再次解压。', '  v{0} is already installed (the same package): nothing to unpack.')
    'low_upgrade' = @('{0} 得 {1} GB 空位:要約 {2} GB。請清出空位再試。', '{0} 只有 {1} GB 可用空间:需要约 {2} GB。请清理空间后再试。', '{0} has only {1} GB free: about {2} GB is needed. Free some space and try again.')
    'bad_action' = @('唔識呢個動作:{0}。用得:setup、start、background、logs、stop、status、uninstall。', '无法识别的操作:{0}。可用:setup、start、background、logs、stop、status、uninstall。', 'Unknown action: {0}. Use one of: setup, start, background, logs, stop, status, uninstall.')
    'help_uninstall' = @('  全部移除(礦工、資料、捷徑):       TheNewMiner.bat uninstall', '  全部卸载(矿工、数据、快捷方式):   TheNewMiner.bat uninstall', '  Remove everything (miner, data, shortcut):     TheNewMiner.bat uninstall')
    'uninst_q' = @('  會移除 TheNewMiner:WSL 嘅「{0}」(礦工、設定、模型)、資料夾 {1}、桌面捷徑。錢包唔受影響。確定?(打 y 確認 / Enter = 取消)', '  将卸载 TheNewMiner:WSL 中的“{0}”(矿工、设置、模型)、文件夹 {1}、桌面快捷方式。钱包不受影响。确定吗?(输入 y 确认 / Enter = 取消)', '  This removes TheNewMiner: the WSL distribution "{0}" (miner, settings, model), the folder {1} and the desktop shortcut. Your wallet is not affected. Continue? (type y to confirm / Enter = cancel)')
    'uninst_unreg_fail' = @('wsl --unregister {0} 失敗(結束碼 {1})。', 'wsl --unregister {0} 失败(退出码 {1})。', 'wsl --unregister {0} failed (exit code {1}).')
    'uninst_left' = @('  {0} 入面有唔係 TheNewMiner 整嘅檔案,所以保留咗個資料夾。', '  {0} 中有不是 TheNewMiner 创建的文件,所以保留了这个文件夹。', '  {0} holds files TheNewMiner did not create, so the folder was kept.')
    'uninst_done' = @('已移除 TheNewMiner。', '已卸载 TheNewMiner。', 'TheNewMiner was removed.')
    'wsl_update_failed' = @('WSL 更新唔到(結束碼 {0}):用住呢個 WSL 繼續;部份功能(揀資料位置)可能用唔到。', 'WSL 无法更新(退出码 {0}):继续使用当前的 WSL;部分功能(选择数据位置)可能不可用。', 'WSL could not be updated (exit code {0}): going on with this WSL; some features (choosing the data folder) may not be available.')
    'moving_distro' = @('  將 WSL 磁碟搬去 {0} ...', '  正在把 WSL 磁盘移到 {0} ...', '  Moving the WSL disk to {0} ...')
    'move_failed' = @('搬唔到 WSL 磁碟(結束碼 {0}):資料留喺 WSL 嘅預設位置(C:)。', '无法移动 WSL 磁盘(退出码 {0}):数据保留在 WSL 的默认位置(C:)。', 'The WSL disk could not be moved (exit code {0}): the data stays in the default WSL location (C:).')
    'distro_fail_old' = @('{0} 裝唔到(wsl --install 結束碼 {1}):呢個 WSL 太舊,又更新唔到。請連上網絡,喺 Microsoft Store 裝「Windows Subsystem for Linux」或者打 wsl --update,之後再雙擊 TheNewMiner.bat。', '{0} 安装失败(wsl --install 退出码 {1}):这个 WSL 太旧,并且无法更新。请连接网络,在 Microsoft Store 安装“Windows Subsystem for Linux”或运行 wsl --update,然后再次双击 TheNewMiner.bat。', '{0} could not be installed (wsl --install exit code {1}): this WSL is too old and could not be updated. Connect to the internet, install "Windows Subsystem for Linux" from the Microsoft Store or run wsl --update, then double-click TheNewMiner.bat again.')
    'vram_small' = @('冇一張 NVIDIA 卡有 10 GB 或以上顯示記憶體({0}):TheNewMiner 要 10 GB 或以上嘅卡(例如 RTX 3080 10 GB)。', '没有一张 NVIDIA 显卡有 10 GB 或以上显存({0}):TheNewMiner 需要 10 GB 或以上的显卡(例如 RTX 3080 10 GB)。', 'No NVIDIA card has 10 GB of video memory or more ({0}): TheNewMiner needs a card with 10 GB or more (for example an RTX 3080 10 GB).')
    'unknown_place' = @('(唔知道)', '(未知)', '(unknown)')
}
function T([string]$id) {
    $e = $Script:Msg[$id]
    if ($null -eq $e) { return $id }
    if ($Script:Lang -eq 'zh-Hans') { return $e[1] }
    if ($Script:Lang -eq 'en') { return $e[2] }
    return $e[0]
}
# The part inside WSL (tnm-wsl.sh) prints its lines in the same language.
$env:TNM_LANG = $Script:Lang
if (-not $env:WSLENV) { $env:WSLENV = 'TNM_LANG/u' }
elseif ($env:WSLENV -notmatch '(^|:)TNM_LANG(/|:|$)') { $env:WSLENV = 'TNM_LANG/u:' + $env:WSLENV }

$Actions = @('auto', 'setup', 'start', 'background', 'logs', 'stop', 'status', 'uninstall')
if (-not $Action) { $Action = 'auto' }            # TheNewMiner.bat "" ...
$Action = $Action.ToLowerInvariant()
if ($Actions -notcontains $Action) { Fail ((T 'bad_action') -f $Action) 2 }

function Open-DriverPage { try { Start-Process 'https://www.nvidia.com/Download/index.aspx' } catch { } }
function Strip-Quotes([string]$s) {
    $s = ($s + '').Trim()
    while ($s.Length -ge 2 -and (($s.StartsWith('"') -and $s.EndsWith('"')) -or ($s.StartsWith("'") -and $s.EndsWith("'")))) {
        $s = $s.Substring(1, $s.Length - 2).Trim()
    }
    return $s
}
$DataDir = Strip-Quotes $DataDir

# ---------------------------------------------------------------- processes and quoting
# One argument for a Windows command line (the CommandLineToArgvW / MSVCRT rules wsl.exe and powershell.exe parse):
# quoted when it is empty or has a space, tab or quote; backslashes doubled before a quote and at the end.
function Quote-WinArg([string]$a) {
    if ($a.Length -gt 0 -and $a -notmatch '[\s"]') { return $a }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $bs = 0
    foreach ($ch in $a.ToCharArray()) {
        if ($ch -eq [char]'\') { $bs++; continue }
        if ($ch -eq [char]'"') { [void]$sb.Append(('\' * (2 * $bs + 1)) + '"'); $bs = 0; continue }
        if ($bs -gt 0) { [void]$sb.Append('\' * $bs); $bs = 0 }
        [void]$sb.Append($ch)
    }
    if ($bs -gt 0) { [void]$sb.Append('\' * (2 * $bs)) }
    [void]$sb.Append('"')
    return $sb.ToString()
}
function Join-WinArgs([string[]]$argv) { return ((@($argv) | ForEach-Object { Quote-WinArg $_ }) -join ' ') }

# wsl.exe in THIS console (live output and progress lines, Ctrl+C reaches it), every argument quoted exactly.
# Returns its exit code (-1: it could not be started).
function Wsl-Run([string[]]$argv) {
    try {
        $p = Start-Process -FilePath 'wsl.exe' -ArgumentList (Join-WinArgs $argv) -NoNewWindow -PassThru -ErrorAction Stop
    } catch { return -1 }
    $null = $p.Handle                     # keeps the exit code readable after the wait (Windows PowerShell 5.1)
    $p.WaitForExit()
    return $p.ExitCode
}

# wsl.exe with its output captured as text lines (NULs of an old wsl.exe's UTF-16 removed), the same exact quoting.
# Exit code in $Script:Rc, its error output in $Script:WslErr.
function Wsl-Read([string[]]$argv) {
    $Script:WslErr = ''
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'wsl.exe'
    $psi.Arguments = Join-WinArgs $argv
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    try { $p = [System.Diagnostics.Process]::Start($psi) } catch { $Script:Rc = -1; return @() }
    $errTask = $p.StandardError.ReadToEndAsync()
    $out = $p.StandardOutput.ReadToEnd()
    $p.WaitForExit()
    $Script:WslErr = ($errTask.Result + '') -replace "`0", ''
    $Script:Rc = $p.ExitCode
    $out = $out -replace "`0", ''
    return @($out -split "`r?`n" | Where-Object { $_ -ne '' })
}

function Is-Admin {
    if ($env:TNM_TEST_ADMIN) { return $true }
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

# wsl.exe as Administrator (UAC prompt unless this already runs elevated). Returns its exit code.
function Wsl-Elevated([string[]]$argv) {
    if (Is-Admin) { return (Wsl-Run $argv) }
    Say (T 'uac_hint')
    try {
        $p = Start-Process -FilePath 'wsl.exe' -ArgumentList (Join-WinArgs $argv) -Verb RunAs -PassThru -ErrorAction Stop
        $null = $p.Handle
        $p.WaitForExit()
        return $p.ExitCode
    } catch {
        return -1
    }
}

function Wsl-Ready {
    if (-not (Test-Path -LiteralPath (Join-Path $env:ProgramFiles 'WSL\wsl.exe'))) { return $false }
    $null = Wsl-Read @('--version')
    return ($Script:Rc -eq 0)
}

function Distros {
    $l = Wsl-Read @('-l', '-q')
    if ($Script:Rc -ne 0) { return @() }
    return @($l | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

# yes / no / unknown: does this wsl.exe know `--install --location` (its --help lists the option)?
function Location-Support {
    $h = (@(Wsl-Read @('--help')) -join "`n") + "`n" + $Script:WslErr
    $Script:HelpText = $h
    if (-not $h.Trim()) { return 'unknown' }
    if ($h -match '--location') { return 'yes' }
    return 'no'
}

# ---------------------------------------------------------------- places on Windows
function Desktop-Dir {
    if ($env:TNM_TEST_DESKTOP) { return $env:TNM_TEST_DESKTOP }
    try { return [Environment]::GetFolderPath('Desktop') } catch { return '' }
}
function Drive-Root([string]$p) {
    if ($p -match '^([A-Za-z]):') { return ($Matches[1].ToUpper() + ':\') }
    if ($p -match '^\\\\') { return '' }                      # \\server\share: no drive
    try { return [IO.Path]::GetPathRoot($p) } catch { return '' }
}
# The drives: Name (C:\), Type (Fixed / Removable / Network ...), Format (NTFS ...), FreeGb. TNM_TEST_DRIVES (JSON) in tests.
function Get-Drives {
    $out = @()
    if ($env:TNM_TEST_DRIVES) {
        foreach ($d in (ConvertFrom-Json $env:TNM_TEST_DRIVES)) {
            $out += [pscustomobject]@{ Name = [string]$d.Name; Type = [string]$d.Type; Format = [string]$d.Format; FreeGb = [double]$d.FreeGb }
        }
        return $out
    }
    foreach ($d in [IO.DriveInfo]::GetDrives()) {
        try {
            if (-not $d.IsReady) { continue }
            $out += [pscustomobject]@{ Name = $d.Name; Type = [string]$d.DriveType; Format = [string]$d.DriveFormat; FreeGb = [math]::Floor($d.AvailableFreeSpace / 1GB) }
        } catch { }
    }
    return $out
}
function Free-Gb([string]$p) {
    $root = Drive-Root $p
    if (-not $root) { return -1 }
    if ($env:TNM_TEST_DRIVES) { foreach ($d in (Get-Drives)) { if ($d.Name -eq $root) { return $d.FreeGb } } }
    try { return [math]::Floor((New-Object IO.DriveInfo $root).AvailableFreeSpace / 1GB) } catch { return -1 }
}
function Is-Under([string]$p, [string]$parent) {
    if (-not $p -or -not $parent) { return $false }
    $a = $p.TrimEnd('\', '/') + '\'
    $b = $parent.TrimEnd('\', '/') + '\'
    return $a.StartsWith($b, [StringComparison]::OrdinalIgnoreCase)
}
function Downloads-Dirs {
    $l = @()
    if ($env:TNM_TEST_DOWNLOADS) { $l += $env:TNM_TEST_DOWNLOADS }
    try {
        $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
        $v = (Get-ItemProperty -Path $k -Name '{374DE290-123F-4565-9164-39C4925E467B}' -ErrorAction Stop).'{374DE290-123F-4565-9164-39C4925E467B}'
        if ($v) { $l += [Environment]::ExpandEnvironmentVariables($v) }
    } catch { }
    if ($env:USERPROFILE) { $l += ($env:USERPROFILE.TrimEnd('\') + '\Downloads') }
    return $l
}
# Why the kit's own place is no place for a live virtual disk: onedrive / temp / downloads / removable / notntfs / unc,
# or '' when it is fine.
function Kit-Place([string]$kit) {
    foreach ($od in @($env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial)) { if (Is-Under $kit $od) { return 'onedrive' } }
    if ($kit -match '(?i)\\OneDrive( - [^\\]+)?(\\|$)') { return 'onedrive' }
    foreach ($t in @($env:TEMP, $env:TMP)) { if (Is-Under $kit $t) { return 'temp' } }
    if ($kit -match '(?i)\\(AppData\\Local\\Temp|Windows\\Temp)(\\|$)') { return 'temp' }
    foreach ($dl in (Downloads-Dirs)) { if (Is-Under $kit $dl) { return 'downloads' } }
    $root = Drive-Root $kit
    if (-not $root) { return 'unc' }
    $drv = @(Get-Drives | Where-Object { $_.Name -eq $root }) | Select-Object -First 1
    if (-not $drv) { return 'unc' }
    if ($drv.Type -ne 'Fixed') { return 'removable' }
    if ($drv.Format -ne 'NTFS') { return 'notntfs' }
    return ''
}
# The data folder of a first install, never inside the kit folder: <kit's drive>\TheNewMinerData when that drive is a
# fixed NTFS drive with room (wherever on it the kit sits: OneDrive, Temp or Downloads never hold the data), else the
# fixed NTFS non-system drive with the most free space, else %LOCALAPPDATA%\TheNewMiner\data.
function Choose-DataDir([string]$kit, [double]$need) {
    $sys = Drive-Root ($env:SystemDrive + '\')
    $kitRoot = Drive-Root $kit
    $ok = @(Get-Drives | Where-Object { $_.Type -eq 'Fixed' -and $_.Format -eq 'NTFS' -and $_.FreeGb -ge $need })
    $why = ''
    $k = @($ok | Where-Object { $_.Name -eq $kitRoot })
    if ($k.Count -gt 0) {
        return [pscustomobject]@{ Path = ($kitRoot + 'TheNewMinerData'); FreeGb = $k[0].FreeGb; Why = '' }
    }
    $place = Kit-Place $kit
    if ($place -eq 'removable' -or $place -eq 'notntfs' -or $place -eq 'unc') { $why = $place } else { $why = 'space' }
    $others = @($ok | Where-Object { $_.Name -ne $sys } | Sort-Object -Property FreeGb -Descending)
    if ($others.Count -gt 0) {
        return [pscustomobject]@{ Path = ($others[0].Name + 'TheNewMinerData'); FreeGb = $others[0].FreeGb; Why = $why }
    }
    $la = ($env:LOCALAPPDATA.TrimEnd('\') + '\TheNewMiner\data')
    return [pscustomobject]@{ Path = $la; FreeGb = (Free-Gb $la); Why = $why }
}
function Why-Text([string]$why) {
    switch ($why) {
        'removable' { return (T 'why_removable') }
        'notntfs' { return (T 'why_notntfs') }
        'unc' { return (T 'why_unc') }
        default { return (T 'why_space') }
    }
}
function Is-FullPath([string]$p) {
    if ($OnWindows) { return ($p -match '^[A-Za-z]:\\') }
    return [IO.Path]::IsPathRooted($p)
}
# A typed folder: a drive root or any folder that already exists (empty or not) gets a TheNewMinerData subfolder, so
# uninstall never removes the user's own folder or files put there later. A folder of ours (with the marker) is reused.
function Fit-DataDir([string]$p) {
    $p = $p.TrimEnd('\', '/')
    if ($p -match '^[A-Za-z]:$' -or -not $p) { return ($p + '\TheNewMinerData') }
    if ((Test-Path -LiteralPath $p) -and -not (Test-Path -LiteralPath (Join-Path $p $DataMarker))) {
        return (Join-Path $p 'TheNewMinerData')
    }
    return $p
}

# Only the user, SYSTEM and Administrators (by SID, any Windows language): the distro's disk, the staging copy and
# the script that runs as root in WSL are nobody else's to read or swap. Returns $false when it could not be done.
function Protect-Dir([string]$dir) {
    $sid = $env:TNM_TEST_SID
    if (-not $sid) { try { $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value } catch { $sid = '' } }
    if (-not $sid) { return $false }
    $icacls = 'icacls.exe'
    if ($env:SystemRoot -and (Test-Path -LiteralPath (Join-Path $env:SystemRoot 'System32\icacls.exe'))) { $icacls = Join-Path $env:SystemRoot 'System32\icacls.exe' }
    try {
        $null = & $icacls $dir.TrimEnd('\') '/inheritance:r' '/grant:r' ('*' + $sid + ':(OI)(CI)F') '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}
function Ensure-LocalBase {
    if (Test-Path -LiteralPath $LocalBase) { return }
    New-Item -ItemType Directory -Force -Path $LocalBase | Out-Null
    if (-not (Protect-Dir $LocalBase)) { Warn ((T 'acl_warn') -f $LocalBase) }
}

# The registered data folder of $Distro (HKCU\Software\Microsoft\Windows\CurrentVersion\Lxss\{guid}: DistributionName,
# BasePath), '' when it is not registered. TNM_TEST_LXSS (a JSON list) stands for the registry in tests.
function Get-DistroBase {
    $rows = @()
    if ($env:TNM_TEST_LXSS) {
        if (Test-Path -LiteralPath $env:TNM_TEST_LXSS) {
            foreach ($r in (Get-Content -Raw -LiteralPath $env:TNM_TEST_LXSS | ConvertFrom-Json)) { $rows += $r }
        }
    } else {
        $rows = @(Get-ChildItem -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss' -ErrorAction SilentlyContinue |
            ForEach-Object { Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue })
    }
    foreach ($r in $rows) {
        if ($r.DistributionName -eq $Distro -and $r.BasePath) { return (([string]$r.BasePath) -replace '^\\\\\?\\', '') }
    }
    return ''
}
function Data-Missing {
    $bp = Get-DistroBase
    return ($bp -and -not (Test-Path -LiteralPath $bp))
}

# Package names: TheNewMiner-vX.Y.Z-linux-x86_64[-sealed|-plain][-rN].tar.xz. Key = version, then revision (none = 1).
$PkgRe = '^TheNewMiner-v\d+\.\d+\.\d+-linux-x86_64(-sealed|-plain)?(-r\d+)?\.tar\.xz$'
function Pkg-Version([string]$s) { if ($s -match 'v(\d+\.\d+\.\d+)') { return $Matches[1] } return '' }
function Pkg-Rev([string]$s) { if ($s -match '-r(\d+)(\.tar\.xz)?$') { return [int]$Matches[1] } return 1 }
# >0 when version/revision a is newer than b
function Compare-Key([string]$va, [int]$ra, [string]$vb, [int]$rb) {
    $c = ([version]$va).CompareTo([version]$vb)
    if ($c -ne 0) { return $c }
    return $ra.CompareTo($rb)
}
# The package bundled in this kit (files\ = $PSScriptRoot) - ONLY there, never the current folder or Downloads. Several:
# the highest version / revision.
function Find-BundledPackage {
    $all = @(Get-ChildItem -LiteralPath $PSScriptRoot -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $PkgRe })
    if ($all.Count -eq 0) { return $null }
    $best = $all[0]
    foreach ($f in $all) {
        if ((Compare-Key (Pkg-Version $f.Name) (Pkg-Rev $f.Name) (Pkg-Version $best.Name) (Pkg-Rev $best.Name)) -gt 0) { $best = $f }
    }
    return $best.FullName
}
# The sha256 of a local package: -Sha256, else <file>.sha256, else its line in a SHA256SUMS beside it; '' when none.
function Local-Sha([string]$file) {
    if ($Sha256) { return $Sha256 }
    $name = [IO.Path]::GetFileName($file)
    if (Test-Path -LiteralPath ($file + '.sha256')) {
        $w = (((Get-Content -LiteralPath ($file + '.sha256') -TotalCount 1) + '').Trim() -split '\s+')[0]
        if ($w -match '^[0-9a-fA-F]{64}$') { return $w }
    }
    $sums = Join-Path (Split-Path -Parent $file) 'SHA256SUMS'
    if (Test-Path -LiteralPath $sums) {
        foreach ($ln in (Get-Content -LiteralPath $sums)) {
            $p = @(($ln + '').Trim() -split '\s+')
            if ($p.Count -ge 2 -and ($p[-1] -replace '^\*', '') -eq $name -and $p[0] -match '^[0-9a-fA-F]{64}$') { return $p[0] }
        }
    }
    return ''
}

# A desktop shortcut to this kit's TheNewMiner.bat (re-pointed silently when a newer kit runs from another folder).
function Shortcut-Path { $d = Desktop-Dir; if (-not $d) { return '' } return (Join-Path $d 'TheNewMiner.lnk') }
function New-DesktopShortcut([bool]$quiet) {
    try {
        if (-not (Test-Path -LiteralPath $EntryBat)) { return }
        $lnk = Shortcut-Path
        if (-not $lnk) { return }
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($lnk)
        if ($quiet -and $sc.TargetPath -eq $EntryBat) { return }
        $sc.TargetPath = $EntryBat
        $sc.WorkingDirectory = (Split-Path $EntryBat)
        $sc.Description = 'TheNewMiner'
        $sc.Save()
        if (-not $quiet) { Say (T 'shortcut_made') }
    } catch { }
}
# When a reboot is needed to finish turning WSL on, resume setup automatically at the next sign-in (one time). Every
# exit 3010 goes through Exit-Reboot, so the RunOnce entry is always there.
$RunOnceKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
function Set-ResumeAfterReboot {
    if (-not (Test-Path -LiteralPath $EntryBat)) { return }
    $v = '"' + $EntryBat + '"'
    if ($env:TNM_TEST_RUNONCE) { [IO.File]::WriteAllText($env:TNM_TEST_RUNONCE, $v); return }
    try {
        if (-not (Test-Path -LiteralPath $RunOnceKey)) { New-Item -Path $RunOnceKey -Force | Out-Null }
        New-ItemProperty -LiteralPath $RunOnceKey -Name 'TheNewMiner' -Value $v -PropertyType String -Force | Out-Null
    } catch { }
}
function Exit-Reboot([string]$text) {
    Set-ResumeAfterReboot
    Say ''
    Write-Host $text -ForegroundColor Yellow
    exit 3010
}

# [n/N] title (about X min) - everything left about Y min, done about HH:mm. Minutes come from $Script:Plan, which the
# steps lower as soon as they know a part is already done.
function Step([int]$n, [string]$title) {
    $keys = @($Script:Plan.Keys)
    $left = 0.0
    for ($i = $n - 1; $i -lt $keys.Count; $i++) { $left += [double]$Script:Plan[$keys[$i]] }
    $mine = [double]$Script:Plan[$keys[$n - 1]]
    $finish = (Get-Date).AddMinutes($left).ToString('HH:mm')
    $hkt = [DateTime]::UtcNow.AddMinutes($left).AddHours(8).ToString('HH:mm')
    Write-Host ''
    Write-Host ((T 'step_hdr') -f $n, $keys.Count, $title, (Fmt $mine), (Fmt $left), $finish, $hkt) -ForegroundColor Cyan
}

# A Linux path from wslpath: the first line that is one (a wsl.exe notice on stdout is skipped).
function Linux-Path([string]$win) {
    $l = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'wslpath', '-u', $win)
    return (@($l | Where-Object { $_ -like '/*' }) | Select-Object -First 1)
}

function Inner-Args([string[]]$rest) { return @('-d', $Distro, '-u', 'root', '-e', '/bin/bash', $Script:InnerLinux) + $rest }

# Copy tnm-wsl.sh to %LOCALAPPDATA%\TheNewMiner\wsl\ (locked to this user) with LF line endings (a git checkout on
# Windows may have made them CRLF) and learn its path inside WSL.
function Prepare-Inner {
    if (-not (Test-Path -LiteralPath $InnerSrc)) { Fail ((T 'no_inner') -f $InnerSrc) }
    Ensure-LocalBase
    New-Item -ItemType Directory -Force -Path (Split-Path $InnerWin) | Out-Null
    $text = [IO.File]::ReadAllText($InnerSrc) -replace "`r`n", "`n"
    [IO.File]::WriteAllText($InnerWin, $text, (New-Object System.Text.UTF8Encoding($false)))
    $p = Linux-Path $InnerWin
    if (-not $p) { Fail ((T 'no_wslpath') -f $Distro, $InnerWin) }
    $Script:InnerLinux = $p.Trim()
}

function Inner-Read([string[]]$rest) { return (Wsl-Read (Inner-Args $rest)) }
function Inner-Run([string[]]$rest) { return (Wsl-Run (Inner-Args $rest)) }
function Tnm-Value($lines, [string]$key) {
    foreach ($l in $lines) { if ($l -like "$key=*") { return $l.Substring($key.Length + 1) } }
    return $null
}

function Is-Running {
    $r = Inner-Read @('running')
    return (($r | Select-Object -Last 1) -eq 'yes')
}

# How far WSL's clock is from Windows' (ms). WSL2 can drift after the PC sleeps; the pool binding stops a miner whose
# clock is 30 s off. The VM's clock is shared by every distro on the PC, so it is never set from here: only reported.
function Clock-Skew {
    $t0 = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $l = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'date', '+%s%3N')
    $t1 = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $v = 0L
    $first = @($l | Where-Object { $_ -match '^\s*\d+\s*$' }) | Select-Object -First 1
    if (-not [int64]::TryParse(($first + '').Trim(), [ref]$v)) { return $null }
    return [int64]($v - ($t0 + $t1) / 2)
}
function Check-Clock {
    $s = Clock-Skew
    if ($null -eq $s -or [math]::Abs($s) -le 2000) { return }
    Warn ((T 'clock_off') -f ($s / 1000.0))
}

# Keep Windows from sleeping while this window mines (until this window closes).
function Keep-Awake {
    try {
        Add-Type -Namespace TNM -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);' -ErrorAction Stop
        [void][TNM.Power]::SetThreadExecutionState([uint32]2147483649)   # ES_CONTINUOUS | ES_SYSTEM_REQUIRED
    } catch { }
}

function Need-Installed {
    if (-not (Wsl-Ready)) { Fail (T 'need_wsl') }
    if ((Distros) -notcontains $Distro) { Fail ((T 'need_distro') -f $Distro) }
    if (Data-Missing) { Fail ((T 'data_missing') -f (Get-DistroBase)) }
    Prepare-Inner
}

function Show-Help {
    Say ''
    Say (T 'help_title')
    Say (T 'help_start')
    Say (T 'help_bg')
    Say (T 'help_logs')
    Say (T 'help_stop')
    Say (T 'help_status')
    Say (T 'help_uninstall')
}

function Start-Mining([string[]]$frontArgs, [bool]$hidden) {
    Check-Clock
    if ($hidden) {
        $env:TNM_FRONT_ARGS = ($frontArgs -join ' ')       # worker / proxy: no spaces (validated)
        $me = 'powershell.exe'
        try { $me = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName } catch { }
        $cmd = Join-WinArgs @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath, '-Action', 'start', '-Distro', $Distro, '-Lang', $Script:Lang)
        Start-Process -FilePath $me -ArgumentList $cmd -WindowStyle Hidden | Out-Null
        $env:TNM_FRONT_ARGS = $null
        Say (T 'bg_started')
        Say (T 'bg_hint')
        return 0
    }
    Keep-Awake
    Say (T 'fg_started')
    return (Inner-Run (@('run') + $frontArgs))
}

# ---------------------------------------------------------------- uninstall
if ($Action -eq 'uninstall') {
    $ready = Wsl-Ready
    $registered = $ready -and ((Distros) -contains $Distro)
    $bp = Get-DistroBase
    $where = $bp
    if (-not $where) { $where = (T 'unknown_place') }
    if (-not $Yes) {
        $a = ((Read-Host ((T 'uninst_q') -f $Distro, $where)) + '').Trim()
        if ($a -notmatch '^[yY]') { Say (T 'cancelled'); exit 0 }
    }
    if ($registered) {
        if (-not (Data-Missing)) {
            Prepare-Inner
            if (Is-Running) { Say (T 'stopping_old'); [void](Inner-Run @('stop')) }
        }
        $rc = Wsl-Run @('--unregister', $Distro)
        if ($rc -ne 0 -and ((Distros) -contains $Distro)) { Fail ((T 'uninst_unreg_fail') -f $Distro, $rc) }
    }
    if ($bp -and (Test-Path -LiteralPath $bp)) {
        if (Test-Path -LiteralPath (Join-Path $bp $DataMarker)) {
            Remove-Item -LiteralPath $bp -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            $vhd = Join-Path $bp 'ext4.vhdx'
            if (Test-Path -LiteralPath $vhd) { Remove-Item -LiteralPath $vhd -Force -ErrorAction SilentlyContinue }
            if (@(Get-ChildItem -LiteralPath $bp -Force -ErrorAction SilentlyContinue).Count -eq 0) { Remove-Item -LiteralPath $bp -Force -ErrorAction SilentlyContinue }
            else { Say ((T 'uninst_left') -f $bp) }
        }
    }
    $lnk = Shortcut-Path
    if ($lnk -and (Test-Path -LiteralPath $lnk)) { Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue }
    if ($env:TNM_TEST_RUNONCE) { Remove-Item -LiteralPath $env:TNM_TEST_RUNONCE -Force -ErrorAction SilentlyContinue }
    else { try { Remove-ItemProperty -LiteralPath $RunOnceKey -Name 'TheNewMiner' -ErrorAction Stop } catch { } }
    if (Test-Path -LiteralPath $LocalBase) { Remove-Item -LiteralPath $LocalBase -Recurse -Force -ErrorAction SilentlyContinue }
    if ($env:ProgramData) {
        $old = Join-Path $env:ProgramData 'TheNewMiner'          # where kits before r3 staged the package
        if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say (T 'uninst_done')
    exit 0
}

# ---------------------------------------------------------------- daily use
if ($Action -ne 'setup' -and $Action -ne 'auto') {
    Need-Installed
    switch ($Action) {
        'start' {
            if (Is-Running) { Say (T 'already_bg'); exit 0 }
            $fa = @()
            if ($env:TNM_FRONT_ARGS) { $fa = @($env:TNM_FRONT_ARGS -split ' ' | Where-Object { $_ }) }
            exit (Start-Mining $fa $false)
        }
        'background' {
            if (Is-Running) { Say (T 'already'); exit 0 }
            exit (Start-Mining @() $true)
        }
        'logs' { exit (Inner-Run @('logs')) }
        'stop' { exit (Inner-Run @('stop')) }
        'status' {
            $r = Inner-Read @('status')
            $r | Where-Object { $_ -notlike 'TNM_*' } | ForEach-Object { Say $_ }
            Say ((T 'version') + (Tnm-Value $r 'TNM_VERSION'))
            if ((Tnm-Value $r 'TNM_RUNNING') -eq 'yes') { Say (T 'state_on') } else { Say (T 'state_off') }
            exit 0
        }
    }
}

# ---------------------------------------------------------------- auto: already installed -> just mine (fast)
if ($Action -eq 'auto') {
    # Fast path (a few quick wsl calls, no preflight / UAC / sha re-check / prompts / download): the distro is
    # registered (wherever this kit now sits), the miner is installed with its config, and the bundled package is not
    # newer -> just start mining.
    if ((Wsl-Ready) -and ((Distros) -contains $Distro)) {
        if (Data-Missing) { Fail ((T 'data_missing') -f (Get-DistroBase)) }
        Prepare-Inner
        $m = Inner-Read @('installed')
        $instVer = Tnm-Value $m 'TNM_INSTALLED_VERSION'
        $instRev = 1
        [void][int]::TryParse(((Tnm-Value $m 'TNM_INSTALLED_REV') + ''), [ref]$instRev)
        if ($instRev -lt 1) { $instRev = 1 }
        $haveCfg = (Tnm-Value $m 'TNM_HAVE_CONFIG') -eq 'yes'
        $pkg = $Package; if (-not $pkg) { $pkg = Find-BundledPackage }
        $newer = $false
        if ($pkg -and $instVer) {
            $pn = [IO.Path]::GetFileName((($pkg -split '[?#]')[0]))
            if (Pkg-Version $pn) { $newer = ((Compare-Key (Pkg-Version $pn) (Pkg-Rev $pn) $instVer $instRev) -gt 0) }
        }
        if ($instVer -and $haveCfg -and -not $newer) {
            New-DesktopShortcut $true
            if (Is-Running) { Say ((T 'inst_running') -f $instVer); exit (Inner-Run @('logs')) }
            Say ((T 'inst_start') -f $instVer)
            exit (Start-Mining @() $false)
        }
    }
    # not installed, config missing, or a newer bundle -> full setup below (an upgrade keeps the saved config, no prompts)
}

# ---------------------------------------------------------------- setup
$Script:Plan.Add('windows', 0.2)
$Script:Plan.Add('wsl', 3)
$Script:Plan.Add('ubuntu', 6)
$Script:Plan.Add('inside', 2)
$Script:Plan.Add('package', 1)
$Script:Plan.Add('settings', 1)
$Script:Plan.Add('first', 20)
Say (T 'title')
Say (T 'intro')

# 1. Windows and the NVIDIA driver
Step 1 (T 'step1')
if (-not [Environment]::Is64BitOperatingSystem) { Fail (T 'need64') }
$build = [Environment]::OSVersion.Version.Build
if ($env:TNM_TEST_WINBUILD) { $build = [int]$env:TNM_TEST_WINBUILD }   # tools/test_windows_wsl.py (pwsh on Linux)
if ($build -lt $MinBuild) { Fail ((T 'old_win') -f $build) }
$smi = $null
$c = Get-Command 'nvidia-smi.exe' -ErrorAction SilentlyContinue
if ($c) { $smi = $c.Source }
foreach ($p in @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe")) {
    if (-not $smi -and (Test-Path -LiteralPath $p)) { $smi = $p }
}
if (-not $smi) { Open-DriverPage; Fail (T 'no_driver') }
$rows = @(& $smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv,noheader,nounits 2>$null | Where-Object { $_ -match ',' })
if ($LASTEXITCODE -ne 0 -or $rows.Count -eq 0) { Fail (T 'smi_broken') }
$drv = ''
$bigGpu = $false
$smallest = ''
foreach ($r in $rows) {
    $f = @($r.Split(',') | ForEach-Object { $_.Trim() })
    if ($f.Count -lt 4) { continue }
    $drv = $f[1]
    Say ((T 'gpu_line') -f $f[0], $f[2], $f[1])
    $total = 0; $used = 0
    [void][int]::TryParse(($f[2] -replace '[^0-9]', ''), [ref]$total)
    [void][int]::TryParse(($f[3] -replace '[^0-9]', ''), [ref]$used)
    # a "10 GB" card reports 10240 MiB (some boards a little less): 9728 MiB and up counts as 10 GB
    if ($total -ge 9728) { $bigGpu = $true } else { $smallest = $f[0] + ', ' + $total + ' MiB' }
    if ($total -ge 9728 -and $total -le 12288 -and ($total - $used) -lt 9472) {
        Warn ((T 'low_vram') -f ($total - $used))
    }
}
if (-not $bigGpu) { Fail ((T 'vram_small') -f $smallest) }
$major = 0
[void][int]::TryParse((($drv -replace '[^0-9.]', '').Split('.')[0]), [ref]$major)
if ($major -lt $MinDriver) { Open-DriverPage; Fail ((T 'old_driver') -f $drv, $MinDriver) }
$wslReadyAtStart = Wsl-Ready
$registered = $wslReadyAtStart -and ((Distros) -contains $Distro)
$sysRoot = Drive-Root $env:LOCALAPPDATA
$sysFreeGb = Free-Gb $env:LOCALAPPDATA
$ramGb = 0
try { $ramGb = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch { }
Say ((T 'sys_line') -f $build, $ramGb, $sysRoot, $sysFreeGb)
if (-not $wslReadyAtStart -and $sysFreeGb -ge 0 -and $sysFreeGb -lt 1) { Fail ((T 'low_sys') -f $sysRoot, $sysFreeGb) }
# A first install needs ~20 GB on its data drive; an existing distro is checked later for what the upgrade needs.
$Script:Pick = $null
function Get-Pick {
    if ($DataDir) { return [pscustomobject]@{ Path = (Fit-DataDir $DataDir); FreeGb = (Free-Gb $DataDir); Why = '' } }
    return (Choose-DataDir $KitRoot $NeedFreshGb)
}
if (-not $registered) {
    $Script:Pick = Get-Pick
    if ($Script:Pick.FreeGb -ge 0 -and $Script:Pick.FreeGb -lt $NeedFreshGb -and ($Yes -or $DataDir)) {
        Fail ((T 'low_data') -f $Script:Pick.Path, $Script:Pick.FreeGb, $NeedFreshGb)
    }
}
if ($ramGb -gt 0 -and $ramGb -lt 12) { Warn ((T 'low_ram') -f $ramGb) }
try {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $cs = Get-CimInstance Win32_ComputerSystem
    if (-not ($cpu.VirtualizationFirmwareEnabled -or $cs.HypervisorPresent)) {
        Warn (T 'no_virt')
    }
} catch { }

# 2. WSL2
if ($wslReadyAtStart) { $Script:Plan['wsl'] = 0.2 }
Step 2 (T 'step2')
$enabledNow = $false
Ensure-LocalBase
$rebootMark = Join-Path $LocalBase 'wsl-reboot.txt'
$bootTime = ''
try { $bootTime = [string](Get-CimInstance Win32_OperatingSystem).LastBootUpTime } catch { }
if (-not (Wsl-Ready)) {
    Say (T 'wsl_enabling')
    $rc = Wsl-Elevated @('--install', '--no-distribution')
    if ($rc -eq -1) { Fail (T 'wsl_need_admin') }
    if (-not (Wsl-Ready) -and @(0, 3010, 1641) -notcontains $rc) { $rc = Wsl-Elevated @('--update') }
    $enabledNow = $true
    if (-not (Wsl-Ready)) {
        if (@(0, 3010, 1641) -notcontains $rc) { Fail ((T 'wsl_fail') -f $rc) }
        if ((Test-Path -LiteralPath $rebootMark) -and ([IO.File]::ReadAllText($rebootMark).Trim() -ne $bootTime)) {
            Fail (T 'wsl_after_reboot')
        }
        [IO.File]::WriteAllText($rebootMark, $bootTime)
        Exit-Reboot (T 'need_reboot')
    }
}
if (Test-Path -LiteralPath $rebootMark) { Remove-Item -LiteralPath $rebootMark -Force }
# WSL older than 2.4.4 lacks `--install --name / --location`: update it first, then look at the version again. When
# the update is impossible (offline, blocked by policy, UAC declined) setup goes on with what this WSL can do (step 3).
function Wsl-Version {
    $v = (@(Wsl-Read @('--version')) | Select-Object -First 1) + ''
    if ($v -match '(\d+)\.(\d+)\.(\d+)') { return [version]$Matches[0] }
    return $null
}
$wv = Wsl-Version
if ($wv) { Say ('  WSL ' + $wv) }
if (-not $wv -or $wv -lt [version]'2.4.4') {
    Say (T 'wsl_updating')
    $rc = Wsl-Elevated @('--update')
    $wv = Wsl-Version
    if ($wv) { Say ('  WSL ' + $wv) }
    if (-not $wv -or $wv -lt [version]'2.4.4') {
        if ($rc -eq -1) { Warn (T 'wsl_update_admin') } else { Warn ((T 'wsl_update_failed') -f $rc) }
    }
}
$null = Wsl-Read @('--set-default-version', '2')

# .wslconfig: memory and swap for the model, written only where the user set nothing and only when TheNewMiner is the
# only distro (the file is global: other distros' memory is never changed). The model (8.1 GiB) is read once through
# the page cache into the GPU; the miner then needs about 1-2 GB. Default WSL memory is half the RAM.
$cfg = Join-Path $env:USERPROFILE '.wslconfig'
$cfgChanged = $false
$otherDistros = @(Distros | Where-Object { $_ -ne $Distro })
if ($otherDistros.Count -gt 0) {
    Say ((T 'wslconfig_skip') -f $cfg)
} else {
    $cfgText = ''
    if (Test-Path -LiteralPath $cfg) { $cfgText = [IO.File]::ReadAllText($cfg) }
    $add = @()
    if ($cfgText -notmatch '(?im)^\s*memory\s*=' -and $ramGb -ge 10 -and $ramGb -lt 12) { $add += 'memory=6GB' }
    if ($cfgText -notmatch '(?im)^\s*swap\s*=') { $add += 'swap=8GB' }
    if ($add.Count -gt 0) {
        if ($cfgText) { Copy-Item -LiteralPath $cfg -Destination ($cfg + '.bak-thenewminer') -Force }
        $lines = New-Object System.Collections.Generic.List[string]
        foreach ($ln in ($cfgText -split "`r?`n")) { $lines.Add($ln) }
        $at = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*\[wsl2\]\s*$') { $at = $i; break } }
        if ($at -ge 0) {
            $lines.InsertRange($at + 1, [string[]]$add)
        } else {
            if ($cfgText.Trim()) { $lines.Add('') }
            $lines.Add('[wsl2]')
            $lines.AddRange([string[]]$add)
        }
        $new = ($lines -join "`r`n").Trim() + "`r`n"
        [IO.File]::WriteAllText($cfg, $new, (New-Object System.Text.UTF8Encoding($false)))
        $cfgChanged = $true
        Say ((T 'wslconfig') -f $cfg, ($add -join ', '))
    }
}

# 3. The dedicated distro and its data folder
$registered = (Distros) -contains $Distro
if ($registered -and (Data-Missing)) {
    # its disk is gone (drive removed, folder deleted): recreate only when the user says so
    $a = 'y'
    if (-not $Yes) { $a = ((Read-Host ((T 'data_recreate_q') -f (Get-DistroBase))) + '').Trim() }
    if ($a -notmatch '^[yY]') { Say (T 'cancelled'); exit 1 }
    [void](Wsl-Run @('--unregister', $Distro))
    $registered = (Distros) -contains $Distro
    if (-not $Script:Pick) { $Script:Pick = Get-Pick }
}
if ($registered) { $Script:Plan['ubuntu'] = 0.3 }
Step 3 ((T 'step3') -f $Distro)
$firstInstall = $false
if ($registered) {
    if ($DataDir) { Warn ((T 'datadir_ignored') -f $Distro, (Get-DistroBase)) }
} else {
    if (-not $Script:Pick) { $Script:Pick = Get-Pick }
    $loc = Location-Support
    $target = $Script:Pick.Path
    if ($Script:Pick.Why -and (Drive-Root $KitRoot)) { Say ((T 'data_not_kitdrive') -f (Drive-Root $KitRoot), (Why-Text $Script:Pick.Why)) }
    # Shown once, with its free space; Enter accepts, or another folder is typed (quotes stripped, space re-checked).
    for ($try = 0; $try -lt 6 -and $loc -ne 'no'; $try++) {
        $free = Free-Gb $target
        Say ((T 'data_where') -f $target, $free, $NeedFreshGb)
        if ($Yes -or $DataDir) { break }
        $ans = Strip-Quotes (Read-Host (T 'data_prompt'))
        if (-not $ans) {
            if ($free -lt 0 -or $free -ge $NeedFreshGb) { break }
            Warn ((T 'data_low_try') -f $target, $free, $NeedFreshGb)
            continue
        }
        if (-not (Is-FullPath $ans)) { Warn (T 'data_bad_path'); continue }
        $target = Fit-DataDir $ans
    }
    $free = Free-Gb $target
    if ($loc -ne 'no' -and $free -ge 0 -and $free -lt $NeedFreshGb) { Fail ((T 'low_data') -f $target, $free, $NeedFreshGb) }
    if ($loc -eq 'no') {
        # an old wsl.exe without --location: the distro goes to WSL's default place on the system drive
        Say (T 'no_location')
        if ($sysFreeGb -ge 0 -and $sysFreeGb -lt $NeedFreshGb) { Fail ((T 'low_sys_data') -f $sysRoot, $sysFreeGb, $NeedFreshGb) }
        $rc = Wsl-Run @('--install', $BaseDistro, '--name', $Distro, '--no-launch')
        if ((Distros) -contains $Distro -and $Script:HelpText -match '--move') {
            # this WSL can move a distro afterwards: put it into the chosen data folder after all
            New-Item -ItemType Directory -Force -Path $target | Out-Null
            [IO.File]::WriteAllText((Join-Path $target $DataMarker), "TheNewMiner: the disk of its WSL distribution. Remove it with TheNewMiner.bat uninstall.`r`n")
            if (-not (Protect-Dir $target)) { Warn ((T 'acl_warn') -f $target) }
            Say ((T 'moving_distro') -f $target)
            $mrc = Wsl-Run @('--manage', $Distro, '--move', $target)
            if ($mrc -ne 0) { Warn ((T 'move_failed') -f $mrc) }
        }
        if ((Distros) -notcontains $Distro -and -not $enabledNow) { Fail ((T 'distro_fail_old') -f $Distro, $rc) }
    } else {
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        [IO.File]::WriteAllText((Join-Path $target $DataMarker), "TheNewMiner: the disk of its WSL distribution. Remove it with TheNewMiner.bat uninstall.`r`n")
        if (-not (Protect-Dir $target)) { Warn ((T 'acl_warn') -f $target) }
        $rc = Wsl-Run @('--install', $BaseDistro, '--name', $Distro, '--no-launch', '--location', $target)
    }
    if ((Distros) -notcontains $Distro) {
        if ($enabledNow) { Exit-Reboot (T 'reboot_again') }
        Fail ((T 'distro_fail') -f $Distro, $rc)
    }
    $firstInstall = $true
}
$null = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'true')
if ($Script:Rc -ne 0) {
    if ($enabledNow) { Exit-Reboot (T 'reboot_again') }
    Fail ((T 'distro_nostart') -f $Distro)
}
if ($cfgChanged) {
    # memory / swap apply from WSL's next start. wsl --shutdown stops EVERY distro, so it only runs on the first
    # install and only when the user says yes - never silently, not even with -Yes.
    $go = $false
    if ($firstInstall) {
        $running = @(Wsl-Read @('-l', '--running', '-q') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        $list = $running -join ', '
        if (-not $list) { $list = (T 'none_word') }
        $a = ((Read-Host ((T 'restart_wsl_q') -f $list)) + '').Trim()
        $go = ($a -match '^[yY]')
    }
    if ($go) { Say (T 'wsl_restarting'); $null = Wsl-Read @('--shutdown') }
    else { Say (T 'wsl_later') }
}
foreach ($line in (Wsl-Read @('-l', '-v'))) {
    if ($line -match ('\b' + [regex]::Escape($Distro) + '\s+\S+\s+1\s*$')) {
        Say ((T 'wsl1_convert') -f $Distro)
        [void](Wsl-Run @('--set-version', $Distro, '2'))
    }
}

# 4. Inside WSL: the GPU, the packages the installer needs, the clock
Step 4 (T 'step4')
Prepare-Inner
$chkWin = Join-Path (Split-Path $InnerWin) 'check.txt'
if (Test-Path -LiteralPath $chkWin) { Remove-Item -LiteralPath $chkWin -Force }
$chkLinux = ($Script:InnerLinux -replace '/[^/]*$', '') + '/check.txt'
[void](Inner-Run @('check', $chkLinux))             # live output: the package installation shows its progress
$chk = @()
if (Test-Path -LiteralPath $chkWin) { $chk = @(Get-Content -LiteralPath $chkWin) }
$why = Tnm-Value $chk 'TNM_FAIL'
if ($why -eq 'nvidia-smi' -or $why -eq 'libcuda') { Fail (T 'no_gpu_wsl') }
if ($why -eq 'wsl1') { Fail ((T 'still_wsl1') -f $Distro) }
if ($why) { Fail ((T 'check_fail') -f $why) }
if ((Tnm-Value $chk 'TNM_OK') -ne 'check') { Fail (T 'check_incomplete') }
if (Tnm-Value $chk 'TNM_WARN') { Warn (T 'linux_driver_warn') }
Check-Clock

# 5. The miner (our Linux package): the one bundled in files\ (its .sha256 is mandatory), or -Package with a sha256.
Step 5 (T 'step5')
$m = Inner-Read @('installed')
$instVer = Tnm-Value $m 'TNM_INSTALLED_VERSION'
$instRev = 1
[void][int]::TryParse(((Tnm-Value $m 'TNM_INSTALLED_REV') + ''), [ref]$instRev)
if ($instRev -lt 1) { $instRev = 1 }
$instSha = (Tnm-Value $m 'TNM_INSTALLED_SHA') + ''
$haveModel = (Tnm-Value $m 'TNM_HAVE_MODEL') -eq 'yes'
$src = $Package
$want = ''
if ($src) {
    $want = $Sha256
} else {
    $src = Find-BundledPackage
    if (-not $src) { Fail (T 'no_pkg') }
    $want = Local-Sha $src
    if (-not $want) { Fail ((T 'bundle_no_sha') -f $src) }
    Say ((T 'use_local') + $src)
}
$name = [IO.Path]::GetFileName((($src -split '[?#]')[0]))
if ($name -notmatch $PkgRe) { Fail ((T 'bad_name') -f $name) }
$skipPkg = $false
if (-not $Package -and $instVer) {
    $cmp = Compare-Key (Pkg-Version $name) (Pkg-Rev $name) $instVer $instRev
    if ($cmp -lt 0) { Say ((T 'pkg_keep_newer') -f $instVer, (Pkg-Version $name)); $skipPkg = $true }
    elseif ($cmp -eq 0 -and $instSha -and $instSha -eq $want.ToLower()) { Say ((T 'pkg_same') -f $instVer); $skipPkg = $true }
}
if (-not $skipPkg) {
    Ensure-LocalBase
    New-Item -ItemType Directory -Force -Path $StageDir | Out-Null
    $dest = Join-Path $StageDir $name
    $isUrl = $src -match '^https?://'
    if ($isUrl) {
        Say ((T 'downloading') -f $src)
        & curl.exe -fL --retry 3 --connect-timeout 30 -o ($dest + '.part') $src
        if ($LASTEXITCODE -ne 0) { Fail ((T 'dl_fail') -f $src, $LASTEXITCODE) }
        Move-Item -LiteralPath ($dest + '.part') -Destination $dest -Force
        if (-not $want) {
            $t = & curl.exe -fsL --retry 3 --connect-timeout 30 ($src + '.sha256')
            if ($LASTEXITCODE -eq 0 -and $t) { $want = ((($t | Select-Object -First 1) + '').Trim() -split '\s+')[0] }
        }
        if ($want -notmatch '^[0-9a-fA-F]{64}$') { Remove-Item -LiteralPath $dest -Force; Fail (T 'url_no_sha') }
    } else {
        if (-not (Test-Path -LiteralPath $src)) { Fail ((T 'not_found') -f $src) }
        if (-not $want) { $want = Local-Sha $src }
        if ($want -notmatch '^[0-9a-fA-F]{64}$') { Fail ((T 'pkg_no_sha') -f $name) }
        # room: the staging copy here, then (inside the distro's growing disk) the copy, the unpacked files, the model
        $size = (Get-Item -LiteralPath $src).Length
        $stageNeed = [math]::Ceiling($size / 1GB + 0.5)
        if ($sysFreeGb -ge 0 -and $sysFreeGb -lt $stageNeed) { Fail ((T 'low_upgrade') -f $sysRoot, $sysFreeGb, $stageNeed) }
        Copy-Item -LiteralPath $src -Destination $dest -Force
    }
    if (-not $firstInstall) {
        $bp = Get-DistroBase
        $dataPath = $bp
        if (-not $dataPath) { $dataPath = $env:LOCALAPPDATA }
        $need = [math]::Ceiling(6 * (Get-Item -LiteralPath $dest).Length / 1GB + 1)
        if (-not $haveModel) { $need += 10 }
        $dfree = Free-Gb $dataPath
        if ($dfree -ge 0 -and $dfree -lt $need) { Remove-Item -LiteralPath $dest -Force; Fail ((T 'low_upgrade') -f $dataPath, $dfree, $need) }
    }
    # the staged copy is checked here, and again inside WSL right before it is unpacked
    $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $dest).Hash.ToLower()
    if ($got -ne $want.ToLower()) {
        Remove-Item -LiteralPath $dest -Force
        Fail ((T 'sha_bad') -f $got, $want.ToLower())
    }
    Say ((T 'sha_ok') -f $got)
    if (Is-Running) {
        Say (T 'stopping_old')
        [void](Inner-Run @('stop'))
    }
    $destLinux = Linux-Path $dest
    if (-not $destLinux) { Fail ((T 'no_wslpath') -f $Distro, $dest) }
    $dirName = $name -replace '\.tar\.xz$', ''
    $u = Inner-Read @('unpack', $destLinux, $dirName, $got)
    Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
    $u | Where-Object { $_ -notlike 'TNM_*' } | ForEach-Object { Say ('  ' + $_) }
    $why = Tnm-Value $u 'TNM_FAIL'
    if ($why) { Fail ((T 'unpack_fail') -f $why) }
    Say ((T 'installed_at') + (Tnm-Value $u 'TNM_DIR'))
    if ($env:ProgramData) {
        $old = Join-Path $env:ProgramData 'TheNewMiner\pkg'      # kits before r3 staged the package in this shared folder
        if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# 6. Wallet, pool password, worker name, proxy
Step 6 (T 'step6')
$frontArgs = @()
$haveSaved = $false
$s = Inner-Read @('settings')
if ((Tnm-Value $s 'TNM_SET') -ne 'none' -and (Tnm-Value $s 'TNM_SET_WALLET')) {
    Say ((T 'prev_settings') -f (Tnm-Value $s 'TNM_SET_WALLET'), (Tnm-Value $s 'TNM_SET_WORKER'), (Tnm-Value $s 'TNM_SET_PROXY'))
    $keep = 'y'
    # an auto-triggered upgrade (or -Yes) reuses the saved settings silently - no prompt.
    if ($Wallet) { $keep = 'n' } elseif (-not $Yes -and $Action -ne 'auto') { $keep = Read-Host (T 'keep_q') }
    if ($keep -notmatch '^[nN]') {
        $haveSaved = $true
        if ($PSBoundParameters.ContainsKey('Worker') -and $Worker) {
            if ($Worker -notmatch '^[A-Za-z0-9._-]{1,64}$') { Fail (T 'bad_worker') }
            $frontArgs += @('-w', $Worker)
        }
        if ($PSBoundParameters.ContainsKey('Proxy')) {
            $px = $Proxy
            if (-not $px) { $px = 'none' }
            if ($px -notmatch '^(none|direct|off|\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?|socks5://\S+|http://\S+)$') { Fail ((T 'bad_proxy') -f $px) }
            $frontArgs += @('--proxy', $px)
        }
    }
}
if (-not $haveSaved) {
    # bech32 addresses are case-insensitive: lower-case the input, then match lower case only
    $w = ($Wallet + '').Trim().ToLowerInvariant()
    for ($i = 0; $i -lt 5 -and $w -cnotmatch '^tc1[a-z0-9]{20,100}$'; $i++) {
        if ($w) { Warn (T 'wallet_hint') }
        $w = ((Read-Host (T 'wallet_q')) + '').Trim().ToLowerInvariant()
    }
    if ($w -cnotmatch '^tc1[a-z0-9]{20,100}$') { Fail (T 'bad_wallet') }
    $pw = ''
    for ($i = 0; $i -lt 5 -and $pw -notmatch '^[A-Za-z0-9_-]{6,128}$'; $i++) {
        if ($pw) { Warn (T 'pw_hint') }
        $sec = Read-Host (T 'pw_q') -AsSecureString
        $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
        $pw = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b)
        if ($pw -match '^[A-Za-z0-9_-]{6,128}$') {
            $sec2 = Read-Host (T 'pw_again') -AsSecureString
            $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec2)
            $pw2 = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b)
            if ($pw2 -cne $pw) { Warn (T 'pw_differ'); $pw = '' }
        }
    }
    if ($pw -notmatch '^[A-Za-z0-9_-]{6,128}$') { Fail (T 'bad_pw') }
    $defWorker = (($env:COMPUTERNAME + '') -replace '[^A-Za-z0-9._-]', '')
    if ($defWorker.Length -gt 64) { $defWorker = $defWorker.Substring(0, 64) }
    if (-not $defWorker) { $defWorker = 'rig' }
    $wk = $Worker
    for ($i = 0; $i -lt 5 -and $wk -notmatch '^[A-Za-z0-9._-]{1,64}$'; $i++) {
        $wk = ((Read-Host ((T 'worker_q') -f $defWorker)) + '').Trim()
        if (-not $wk) { $wk = $defWorker }
    }
    if ($wk -notmatch '^[A-Za-z0-9._-]{1,64}$') { Fail (T 'bad_worker') }
    # The pool is preconfigured; ordinary miners connect directly. Proxy is an advanced -Proxy option only.
    $px = $Proxy
    if (-not $px) { $px = 'none' }
    if ($px -notmatch '^(none|direct|off|\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?|socks5://\S+|http://\S+)$') { Fail ((T 'bad_proxy') -f $px) }
    $env:TNM_WALLET = $w
    $env:TNM_PASSWORD = $pw
    $wslenv = 'TNM_WALLET/u:TNM_PASSWORD/u'
    if ($env:WSLENV) { $wslenv = $wslenv + ':' + $env:WSLENV }
    $env:WSLENV = $wslenv
    $frontArgs = @('-w', $wk, '--proxy', $px)
    if ($px -eq 'none') { Say (T 'direct') } else { Say (T 'via_proxy') }
}

New-DesktopShortcut $false
# 7. First start: the miner installs itself (model download, GPU test, calibration), then mines
if ($NoStart) {
    Say ''
    Write-Host (T 'installed_nostart') -ForegroundColor Green
    if (-not $haveSaved) { Warn (T 'not_saved') }
    Show-Help
    exit 0
}
Step 7 (T 'step7')
Say (T 'dl_time')
Show-Help
Say ''
$rc = Start-Mining $frontArgs ([bool]$Background)
$env:TNM_WALLET = $null
$env:TNM_PASSWORD = $null
exit $rc
