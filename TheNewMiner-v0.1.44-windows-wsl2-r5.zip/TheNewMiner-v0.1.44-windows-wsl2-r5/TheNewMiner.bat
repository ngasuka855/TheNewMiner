@echo off
rem TheNewMiner for Windows (WSL2) - one click. r3 hotfix: the window never ends in a bare "Done".
rem   TheNewMiner.bat [setup|stop|logs|status|background|uninstall] [options]
rem Double-click: install the first time, then mine; later: mine at once.
rem If the miner is not running when the window would end, it says why, shows the last log lines and offers a restart.
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0files\thenewminer-wsl.ps1" goto noextract
set "TNM_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "TNM_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%TNM_PS%" set "TNM_PS=powershell.exe"
set "TNM_WSL=%SystemRoot%\System32\wsl.exe"
if exist "%SystemRoot%\Sysnative\wsl.exe" set "TNM_WSL=%SystemRoot%\Sysnative\wsl.exe"
if not exist "%TNM_WSL%" set "TNM_WSL=wsl.exe"
set "TNM_ACT=%~1"
if not defined TNM_ACT set "TNM_ACT=auto"
if "%TNM_ACT:~0,1%"=="-" set "TNM_ACT=auto"
set "TNM_CP="
for /f "tokens=*" %%a in ('chcp') do for %%b in (%%a) do set "TNM_CP=%%b"
if defined TNM_CP set "TNM_CP=%TNM_CP:.=%"
chcp 65001 >nul

:run
"%TNM_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\thenewminer-wsl.ps1" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="3010" goto reboot
for %%x in (stop logs status uninstall) do if /i "%TNM_ACT%"=="%%x" goto plainend
call :isrunning
if "%TNM_RUNNING%"=="1" goto running
goto notrunning

:running
echo ============================================================
echo  TheNewMiner is MINING (in the background).
echo  Showing the live log now. Ctrl+C leaves the log; mining goes on.
echo  Stop mining: TheNewMiner.bat stop
echo ============================================================
"%TNM_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\thenewminer-wsl.ps1" logs
goto end

:notrunning
echo ============================================================
echo  TheNewMiner is NOT mining.   Exit code: %RC%
if "%RC%"=="0" echo  The miner stopped without an error code.
if "%RC%"=="1" echo  The miner reported an error. The reason is in the last log lines below.
if "%RC%"=="130" echo  Stopped with Ctrl+C.
if "%RC%"=="137" echo  The miner was killed, most likely OUT OF MEMORY. Close other programs and try again.
if "%RC%"=="-1" echo  WSL stopped unexpectedly.
if "%RC%"=="4294967295" echo  WSL stopped unexpectedly.
echo  Last log lines (send a screenshot of this window if you need help):
echo ------------------------------------------------------------
"%TNM_WSL%" -d TheNewMiner -u root -e bash -c "D=$(readlink -f ~/thenewminer/current 2>/dev/null); echo install: $D; for f in install.log thenewminer.log; do echo; echo === $f; tail -n 25 $D/.miner/$f 2>/dev/null || echo none; done; echo; echo === out-of-memory; dmesg 2>/dev/null | grep -i -E 'out of memory|oom-kill|killed process' | tail -n 5; echo; echo === memory; free -m"
if exist "%USERPROFILE%\.wslconfig" (
  echo.
  echo === .wslconfig
  type "%USERPROFILE%\.wslconfig"
)
echo ------------------------------------------------------------
echo.
choice /c RQ /n /m "Press R to start again, or Q to close: "
if errorlevel 2 goto end
goto run

:reboot
if defined TNM_CP chcp %TNM_CP% >nul
echo Restart Windows, then double-click TheNewMiner.bat again (it resumes automatically).
pause
exit /b %RC%

:plainend
if defined TNM_CP chcp %TNM_CP% >nul
echo Finished, exit code %RC%.
pause
exit /b %RC%

:end
if defined TNM_CP chcp %TNM_CP% >nul
exit /b %RC%

:isrunning
set "TNM_RUNNING=0"
"%TNM_WSL%" -d TheNewMiner -u root -e sh -c "pgrep -f 'thenew(miner|pool)-miner' >/dev/null" >nul 2>&1
if not errorlevel 1 set "TNM_RUNNING=1"
exit /b 0

:noextract
echo.
echo Please extract the zip first: right-click the zip, choose "Extract All",
echo then double-click TheNewMiner.bat in the extracted folder.
echo.
pause
exit /b 1
