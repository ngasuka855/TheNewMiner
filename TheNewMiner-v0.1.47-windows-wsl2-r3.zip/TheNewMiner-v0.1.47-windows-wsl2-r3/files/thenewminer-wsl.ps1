﻿<#
TheNewMiner on Windows through WSL2 - setup and daily use. Windows PowerShell 5.1 (every Windows 10 / 11) or newer.
TheNewMiner.bat passes every argument here unchanged:

  TheNewMiner.bat [ACTION] [-Package FILE|URL] [-Sha256 HEX] [-Wallet W] [-Worker NAME] [-Proxy SPEC]
                  [-DataDir DIR] [-Background] [-NoStart] [-Yes]
Everything on screen is English (v0.1.47 r2). The pool account (wallet, pool password, worker) is asked FIRST, in
step 1, in ONE dialog (a console prompt only when the dialog cannot open: SSH, no desktop); after it nothing else is
asked. An install that has its settings (an upgrade, every later double-click) asks nothing.
  ACTION = auto (default: install if needed, then mine) | setup | start | background | logs | stop | status | uninstall

The miner is our LINUX package, unchanged, inside a dedicated WSL2 distribution "TheNewMiner" (registered from the
Ubuntu 24.04 image, so a user's own Ubuntu is never touched): ~/thenewminer/<package> on WSL's own disk, never /mnt/c.
tnm-wsl.sh (beside this file) is the part that runs inside WSL. No proxy is built in. Elevation (UAC) is asked only to
turn WSL on.
r3 (v0.1.47): an install an earlier kit (or a hand install) made in ANOTHER distro (Ubuntu-24.04, Ubuntu, ...; never
docker-desktop*) is found and upgraded IN PLACE there (settings and model kept, no dialog, no Ubuntu download). When
`wsl --install` cannot download Ubuntu (a network error, e.g. GitHub unreachable), the same Ubuntu 24.04 WSL image is
downloaded from a public mirror in China (TUNA, USTC, Aliyun), checked against a pinned sha256 and registered with
`wsl --import`. Whether a distro exists is read from the registry (Lxss) and a `wsl -d NAME -e true` probe, never only
from the text of `wsl -l -q`.

Where things live (none of it inside the kit folder, so the kit can be moved or deleted; an upgrade is simply the new
zip unpacked anywhere and double-clicked):
  - the distro's disk + the model: a data folder chosen ONCE at the first install (shown with its free space, Enter
    accepts); later launches find it through the WSL registration (HKCU\...\Lxss, DistributionName, BasePath);
  - %LOCALAPPDATA%\TheNewMiner: per-user, locked to the user / SYSTEM / Administrators: the copy of tnm-wsl.sh and the
    staging copy of the package (its sha256 is checked again inside WSL right before unpacking).
The Linux package is the one bundled in files\ (its .sha256 is mandatory). -Package installs another one, only with a
sha256 (-Sha256, or a .sha256 / SHA256SUMS beside it). Newer vs older is decided by the version and revision in the
file name (TheNewMiner-vX.Y.Z-linux-x86_64-sealed[-rN].tar.xz), never by file dates.
#>
[CmdletBinding(PositionalBinding = $false)]
param(
    [Parameter(Position = 0)]
    [string]$Action = 'auto',
    [string]$Package = '',
    [string]$Sha256 = '',
    [string]$Wallet = '',
    [string]$Worker = '',
    [string]$Proxy = '',
    [string]$DataDir = '',
    [string]$Distro = 'TheNewMiner',
    [switch]$Background,
    [switch]$NoStart,
    [switch]$Yes,
    [switch]$NewInstall           # r3: skip the search for an earlier install in another distro (after a probe failed)
)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$env:WSL_UTF8 = '1'                      # wsl.exe's own messages in UTF-8 (older WSL ignores it: NULs are stripped)
$MinDriver = 580
$MinBuild = 19044                         # Windows 10 21H2: the oldest Windows whose WSL2 has the GPU
$NeedFreshGb = 20                         # a first install: Ubuntu + the 8.1 GiB model + the miner
$BaseDistro = 'Ubuntu-24.04'              # the distro image registered under the dedicated name $Distro
$KitRoot = Split-Path -Parent $PSScriptRoot   # the kit folder (this ps1 lives in files\)
$EntryBat = Join-Path $KitRoot 'TheNewMiner.bat'
$LocalBase = Join-Path $env:LOCALAPPDATA 'TheNewMiner'
$StageDir = Join-Path $LocalBase 'stage'
$InnerSrc = Join-Path $PSScriptRoot 'tnm-wsl.sh'
$InnerWin = Join-Path $LocalBase 'wsl\tnm-wsl.sh'
$DataMarker = '.thenewminer-data'         # written into a data folder we created: uninstall removes only such a folder
$OnWindows = ([Environment]::OSVersion.Platform -eq 'Win32NT')
$Script:InnerLinux = ''
$Script:HelpText = ''
$Script:Plan = New-Object System.Collections.Specialized.OrderedDictionary
# r3: -Distro given on the command line (the hidden background start passes it) skips the search for an install
$Script:DistroGiven = $PSBoundParameters.ContainsKey('Distro')
$Script:Legacy = $null                    # an install found in another distro (Resolve-Install), else $null
$Script:InnerEnv = @()                    # TNM_WSL_BASE=... / TNM_WSL_ADOPT=... for tnm-wsl.sh in that distro
$Script:KnownVer = ''                     # the installed version, once known (a failed upgrade names it)

function Say([string]$m) { Write-Host $m }
function Warn([string]$m) { Write-Host ((T 'warn_prefix') + $m) -ForegroundColor Yellow }
function Fail([string]$m, [int]$code = 1) {
    $head = (T 'fail_prefix')
    if ($Script:CurStep) { $head = (T 'fail_at') -f $Script:CurStep }
    Write-Host ''
    Write-Host ($head + $m) -ForegroundColor Red
    # r2: TheNewMiner.bat shows this file (the failed step and its fix) instead of an empty miner log
    if ($Action -eq 'setup' -or $Action -eq 'auto') {
        try {
            New-Item -ItemType Directory -Force -Path (Split-Path $Script:FailFile) | Out-Null
            [IO.File]::WriteAllText($Script:FailFile, ($head + $m + "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
            # r3: the installed version, so the .bat can say that this miner (if it still runs) was not changed
            if ($Script:KnownVer) { [IO.File]::WriteAllText($Script:FailVerFile, ($Script:KnownVer + ''), (New-Object System.Text.UTF8Encoding($false))) }
        } catch { }
    }
    exit $code
}
$Script:FailFile = Join-Path $env:LOCALAPPDATA 'TheNewMiner\last-setup-failure.txt'
$Script:FailVerFile = Join-Path $env:LOCALAPPDATA 'TheNewMiner\last-setup-failure-version.txt'
$Script:CurStep = ''
# r2: an unexpected error never ends the run silently: it is reported like any other failure (step, reason, file)
trap { Fail ((T 'unexpected') -f $_.InvocationInfo.ScriptLineNumber, ($_.Exception.Message -replace '\s+', ' ')) }
function Fmt([double]$x) { if ($x -lt 1) { return '<1' } return [string][math]::Ceiling($x) }

# Every line shown to people, by message id, in English (r2: one language). One entry per line
# (tools/test_windows_wsl.py reads this table: every id used, no CJK text anywhere in this file).
$Script:Msg = @{
    'warn_prefix' = 'Note: '
    'fail_prefix' = 'Failed: '
    'shortcut_made' = '  A "TheNewMiner" shortcut was put on the desktop.'
    'step_hdr' = '[{0}/{1}] {2} (about {3} min) - about {4} min left in total, done about {5} local time ({6} Hong Kong time)'
    'uac_hint' = '  (Windows will ask for administrator permission: click "Yes")'
    'no_inner' = 'Cannot find {0}: tnm-wsl.sh must be in the same folder as this file.'
    'no_wslpath' = 'Cannot find {1} inside {0} (wslpath).'
    'need_wsl' = 'WSL is not installed: double-click TheNewMiner.bat first.'
    'need_distro' = '{0} is not installed: double-click TheNewMiner.bat first.'
    'help_title' = 'How to use it from now on (in the folder of TheNewMiner.bat, or with the "TheNewMiner" desktop shortcut):'
    'help_start' = '  Mine in a window (closing it stops):            TheNewMiner.bat'
    'help_bg' = '  Mine without a window:                          TheNewMiner.bat background'
    'help_logs' = '  Watch the log (Ctrl+C leaves, mining goes on): TheNewMiner.bat logs'
    'help_stop' = '  Stop:                                           TheNewMiner.bat stop'
    'help_status' = '  Status and recent rates:                        TheNewMiner.bat status'
    'bg_started' = 'Mining in the background (no window; Windows does not sleep while it mines). Signing out or restarting stops it; start it again with TheNewMiner.bat background.'
    'bg_hint' = 'Log: TheNewMiner.bat logs     Stop: TheNewMiner.bat stop'
    'fg_started' = 'Mining started. Keep this window open (closing it stops mining); to stop, press Ctrl+C or run TheNewMiner.bat stop in another window.'
    'already_bg' = 'Already mining (maybe in the background). Log: TheNewMiner.bat logs'
    'already' = 'Already mining. Log: TheNewMiner.bat logs'
    'already_banner' = '⚠ Already mining - not starting a second one'
    'already_banner2' = 'Live log below (Ctrl+C leaves the log, mining goes on; to stop: TheNewMiner.bat stop)'
    'version' = 'Version: '
    'state_on' = 'Status: mining'
    'state_off' = 'Status: not mining'
    'inst_running' = 'v{0} is installed and already mining. Here is its log (Ctrl+C leaves, mining goes on):'
    'inst_start' = 'v{0} is installed, starting to mine (to change the settings: TheNewMiner.bat setup).'
    'title' = 'TheNewMiner Windows setup (WSL2)'
    'intro' = 'The miner is the Linux build; it runs in WSL2 (Ubuntu), which is built into Windows, with the same results as on Linux.'
    'step1' = 'Your pool account; Windows and the NVIDIA driver'
    'need64' = '64-bit Windows 10 or 11 is required.'
    'old_win' = 'This Windows is too old (build {0}); Windows 10 21H2 (19044) or later, or Windows 11, is required. Run Windows Update first.'
    'no_driver' = 'No NVIDIA driver found (nvidia-smi.exe). Install driver 580 or newer from https://www.nvidia.com/Download/index.aspx, restart Windows and try again.'
    'smi_broken' = 'nvidia-smi does not work: reinstall the NVIDIA driver (580 or newer), restart Windows and try again.'
    'gpu_line' = '  GPU: {0}, {1} MiB, driver {2}'
    'low_vram' = 'This card has only {0} MiB free right now (the desktop / browser use the rest). A 10-12 GB card needs 9472 MiB free for the fast mode: plug the display into the motherboard (integrated graphics), or close other programs while mining.'
    'old_driver' = 'NVIDIA driver {0} is too old: {1} or newer is needed. Update it from https://www.nvidia.com/Download/index.aspx, restart Windows and try again. Never install a driver inside WSL.'
    'low_data' = 'The drive of {0} has only {1} GB free: about {2} GB is needed for Ubuntu + the 8.1 GiB model + the miner. Pick another drive with TheNewMiner.bat setup -DataDir <path>.'
    'low_sys' = '{0}: has only {1} GB free: WSL itself needs about 1 GB.'
    'sys_line' = '  Windows build {0}, RAM {1} GB, {2} {3} GB free'
    'low_ram' = 'Only {0} GB of RAM: mining works, but the first install is slower.'
    'no_virt' = 'Virtualization (Intel VT-x / AMD SVM) seems to be off in the BIOS. WSL2 needs it: if Ubuntu fails to install below, turn it on in the BIOS and try again.'
    'step2' = 'Turning on WSL2'
    'wsl_enabling' = '  Turning on WSL (Windows Subsystem for Linux): a few minutes of download and install ...'
    'wsl_need_admin' = 'Turning on WSL needs administrator rights: double-click TheNewMiner.bat again and click "Yes" when asked.'
    'wsl_fail' = 'Could not turn on WSL (exit code {0}). Check the network and Windows Update, then try again.'
    'wsl_after_reboot' = 'Windows was restarted but WSL still does not work. Install "Windows Subsystem for Linux" from the Microsoft Store, or run wsl --install, then try again.'
    'need_reboot' = 'WSL is on but needs a restart. After the restart, setup continues from here by itself (or double-click TheNewMiner.bat again).'
    'wsl_updating' = '  Updating WSL (Ubuntu 24.04 needs WSL 2.4.4 or newer) ...'
    'wsl_update_admin' = 'Updating WSL needs administrator rights: double-click TheNewMiner.bat again and click "Yes" when asked.'
    'wslconfig' = '  WSL settings {0}: {1} (they take effect at the next WSL start)'
    'step3' = 'Installing {0} (about 300-600 MB download)'
    'data_prompt' = '  Press Enter to use it, or type another folder'
    'no_location' = '  This WSL does not support --location: the data goes to the default WSL location (your user folder on C:).'
    'reboot_again' = 'Please restart Windows, then double-click TheNewMiner.bat again.'
    'distro_fail' = '{0} could not be installed. The WSL message is above. Run wsl --update in a Command Prompt, then double-click TheNewMiner.bat again; if it happens again, send a screenshot of this window.'
    'distro_virt' = '{0} could not be installed or started because virtualization is off (0x80370102). Turn on Intel VT-x / AMD SVM ("Virtualization Technology" or "SVM Mode") in the BIOS, then double-click TheNewMiner.bat again.'
    'net_stopped' = 'Step 3/7 stopped: Windows could not download Ubuntu 24.04 (wsl --install could not reach its download server). This is a network problem, not virtualization. Nothing was installed or changed.'
    'net_next' = 'Next: the same Ubuntu 24.04 ({0}, {1} MB) is downloaded from a public mirror in China (Tsinghua TUNA, then USTC, then Aliyun) and checked against its pinned sha256 before it is used.'
    'mirror_try' = '  Downloading {0}'
    'mirror_progress' = '  {0}%  {1} / {2} MB'
    'mirror_why' = '  Not usable: {0}'
    'mirror_sha_bad' = 'the file does not match the pinned sha256 (it was deleted)'
    'mirror_size_bad' = 'the file has {0} bytes, not {1} (it was deleted)'
    'mirror_cached' = '  Using the Ubuntu 24.04 image downloaded before (sha256 OK): {0}'
    'mirror_ok' = '  sha256 OK ({0}): registering it as {1} (wsl --import) ...'
    'mirror_fail' = 'Windows could not download Ubuntu 24.04, and neither could TheNewMiner from the mirrors in China ({0}). This is a network problem, not virtualization. Nothing was installed. Check the internet connection (and any firewall, VPN or proxy), then double-click TheNewMiner.bat again.'
    'import_fail' = 'The downloaded Ubuntu 24.04 (sha256 OK) could not be registered (wsl --import). The WSL message is above. Run wsl --update in a Command Prompt, then double-click TheNewMiner.bat again.'
    'legacy_found' = 'Found your TheNewMiner install in distro {0} ({1}); upgrading it. Its settings and model are kept; nothing is asked and Ubuntu is not downloaded.'
    'legacy_where' = '  Install: {0}'
    'legacy_fail' = 'Found your TheNewMiner install in distro {0}, but it cannot be upgraded there: {1} Nothing was changed and no second copy was made.'
    'legacy_why_start' = 'WSL could not start it.'
    'legacy_why_path' = 'the folder {0} cannot be reached from inside it (wslpath; is automount turned off in its /etc/wsl.conf?).'
    'legacy_why_wsl1' = 'it is WSL 1 and the GPU needs WSL 2. Convert it in a Command Prompt with: wsl --set-version {0} 2 , then double-click TheNewMiner.bat again.'
    'ver_unknown' = 'version unknown'
    'probe_fail' = 'Could not look inside the WSL distribution(s) {0} (they did not start in time), so an earlier TheNewMiner install there could not be checked, and a second install is never made blindly. Start them once (wsl -d NAME in a Command Prompt) and double-click TheNewMiner.bat again; if none of your distributions has TheNewMiner, run TheNewMiner.bat setup -NewInstall.'
    'step3_have' = 'Using the WSL distribution {0} (already there: nothing to download)'
    'uninst_not_ours' = 'The WSL distribution {0} was not created by TheNewMiner, so it is never unregistered. Nothing was removed.'

    'legacy_why_data' = 'its disk folder {0} is missing.'
    'uninst_q_legacy' = '  This removes TheNewMiner from Windows (the folder {1} and the desktop shortcut) and stops the miner. Your WSL distribution "{0}" is yours and is NOT removed; the miner files stay in it ({2}). Continue? (type y to confirm / Enter = cancel)'
    'uninst_legacy_left' = '  The miner files are still inside {0} in {1}: remove them there if you no longer need them.'
    'distro_nostart' = '{0} could not be started. Open "{0}" once from the Start menu (it asks you to create a Linux user), then double-click TheNewMiner.bat again.'
    'restart_wsl_q' = '  The new WSL settings take effect after WSL restarts: this runs wsl --shutdown, which stops every WSL distribution (running now: {0}). Restart now? (y = restart / Enter = later)'
    'wsl_restarting' = '  Restarting WSL so that the settings take effect ...'
    'wsl_later' = '  The WSL settings take effect after the next WSL restart (wsl --shutdown or a Windows restart).'
    'wsl1_convert' = '  {0} is WSL 1, converting it to WSL 2 ...'
    'step4' = 'Inside WSL: the GPU, the packages needed, the clock'
    'no_gpu_wsl' = 'WSL cannot see the GPU: update the NVIDIA driver on Windows (580 or newer), run wsl --shutdown in a Command Prompt, then double-click TheNewMiner.bat again.'
    'still_wsl1' = '{0} is still WSL 1: run wsl --set-version {0} 2 in a Command Prompt and try again.'
    'check_fail' = 'The check inside WSL failed ({0}). The details are above.'
    'check_incomplete' = 'The check inside WSL did not finish. The details are above.'
    'linux_driver_warn' = 'A Linux NVIDIA driver is installed inside WSL and hides the GPU of the Windows driver; if errors follow, remove it as described above.'
    'step5' = 'The miner (Linux package): use the local package (or download it), check its sha256, unpack it into WSL'
    'no_pkg' = 'The bundled miner package (in files\) was not found. Unzip the complete zip again, or run TheNewMiner.bat setup -Package <file> -Sha256 <64 characters>.'
    'use_local' = '  Using the bundled package (no download): '
    'bad_name' = '{0} is not a TheNewMiner Linux package (TheNewMiner-vX.Y.Z-linux-x86_64-sealed.tar.xz).'
    'downloading' = '  Downloading {0}'
    'dl_fail' = 'Could not download {0} (curl exit code {1}).'
    'not_found' = 'Not found: {0}'
    'url_no_sha' = 'The downloaded package has no sha256 to check: give -Sha256 <64 characters>, or publish <URL>.sha256 next to it.'
    'sha_bad' = 'sha256 mismatch: this package is {0}, it should be {1}. It is damaged or not official: do not use it.'
    'sha_ok' = '  sha256 OK: {0}'
    'stopping_old' = '  Stopping the running miner (before switching versions) ...'
    'unpack_fail' = 'Unpacking failed ({0}).'
    'installed_at' = '  Installed inside WSL: '
    'step6' = 'The pool account and the proxy'
    'prev_settings' = '  Previous settings: wallet {0}, worker {1}, proxy {2}'
    'bad_worker' = 'Worker name: 1-64 letters, digits, . _ or -.'
    'bad_proxy' = 'Invalid proxy: {0}'
    'wallet_q' = '  Wallet address (tc1...)'
    'bad_wallet' = 'Invalid wallet address.'
    'pw_hint' = 'Pool password: 6-128 characters, any visible character (punctuation and non-English letters too), no spaces or control characters.'
    'pw_q' = '  Pool password (6-128 characters, no spaces)'
    'pw_again' = '  Pool password again'
    'pw_differ' = 'The two entries differ, try again.'
    'bad_pw' = 'Invalid pool password.'
    'worker_q' = '  Worker name (shown on the pool; Enter = {0})'
    'direct' = '  Connecting directly to the pool (no proxy).'
    'via_proxy' = '  Connecting through the proxy (remembered, no need to give it again).'
    'installed_nostart' = 'Installed (not mining yet).'
    'not_saved' = 'The wallet and password are not saved yet: double-click TheNewMiner.bat again for the first start.'
    'step7' = 'First start: download the model (8.1 GiB), test the GPU, calibrate, then mine'
    'dl_time' = '  The download time depends on the network: about 12 min at 100 Mbit/s, 3 min at 500 Mbit/s (the progress line shows the time left); the GPU test takes 1-2 min, calibration 1-3 min.'
    'data_where' = '  Data folder (the Ubuntu disk + the model): {0} ({1} GB free on that drive; about {2} GB is needed)'
    'data_not_kitdrive' = '  (the data does not go on the drive of this kit, {0}: {1})'
    'why_removable' = 'it is a removable drive'
    'why_notntfs' = 'it is not NTFS'
    'why_unc' = 'it is a network location'
    'why_space' = 'it has too little free space'
    'data_bad_path' = 'Type a full path, for example D:\TheNewMinerData.'
    'data_low_try' = '{0} has only {1} GB free, less than {2} GB: pick another drive.'
    'data_missing' = 'The TheNewMiner data folder {0} is missing (was its drive removed, or the folder deleted?). If the drive is back, just start again; otherwise run TheNewMiner.bat setup to create it again (the model is downloaded again).'
    'data_recreate_q' = '  {0} is gone. Create the TheNewMiner WSL again (the old registration is removed)? (y = recreate / Enter = cancel)'
    'cancelled' = 'Cancelled.'
    'datadir_ignored' = '-DataDir is not used: {0} is already installed in {1}. To move it, run TheNewMiner.bat uninstall, then TheNewMiner.bat setup -DataDir <path>.'
    'acl_warn' = '  (could not restrict the permissions of {0}; it is still used, but other Windows users may see it)'
    'low_sys_data' = '{0} has only {1} GB free: the default WSL location needs about {2} GB. Run wsl --update (then another drive can be chosen), or free some space.'
    'wslconfig_skip' = '  Other WSL distributions exist on this PC: {0} is left unchanged (their memory settings are not touched).'
    'none_word' = 'none'
    'clock_off' = 'The WSL clock is {0:N1} s off Windows. If the miner reports a clock error: in Windows Settings > Time & language click "Sync now", then run wsl --shutdown in a Command Prompt (it stops every WSL distribution) and start again.'
    'bundle_no_sha' = 'The bundled package has no .sha256: {0}. This zip is incomplete: download the complete zip again.'
    'pkg_no_sha' = 'There is no sha256 to check {0}: put {0}.sha256 (or a SHA256SUMS) next to it, or add -Sha256 <64 characters>.'
    'pkg_keep_newer' = '  The installed v{0} is newer than the bundled v{1}: the installed one is kept.'
    'pkg_same' = '  v{0} is already installed (the same package): nothing to unpack.'
    'low_upgrade' = '{0} has only {1} GB free: about {2} GB is needed. Free some space and try again.'
    'bad_action' = 'Unknown action: {0}. Use one of: setup, start, background, logs, stop, status, uninstall.'
    'help_uninstall' = '  Remove everything (miner, data, shortcut):     TheNewMiner.bat uninstall'
    'uninst_q' = '  This removes TheNewMiner: the WSL distribution "{0}" (miner, settings, model), the folder {1} and the desktop shortcut. Your wallet is not affected. Continue? (type y to confirm / Enter = cancel)'
    'uninst_unreg_fail' = 'wsl --unregister {0} failed (exit code {1}).'
    'uninst_left' = '  {0} holds files TheNewMiner did not create, so the folder was kept.'
    'uninst_done' = 'TheNewMiner was removed.'
    'wsl_update_failed' = 'WSL could not be updated (exit code {0}): going on with this WSL; some features (choosing the data folder) may not be available.'
    'moving_distro' = '  Moving the WSL disk to {0} ...'
    'move_failed' = 'The WSL disk could not be moved (exit code {0}): the data stays in the default WSL location (C:).'
    'distro_fail_old' = '{0} could not be installed: this WSL is too old and could not be updated. Connect to the internet, install "Windows Subsystem for Linux" from the Microsoft Store or run wsl --update, then double-click TheNewMiner.bat again.'
    'vram_small' = 'No NVIDIA card has 10 GB of video memory or more ({0}): TheNewMiner needs a card with 10 GB or more (for example an RTX 3080 10 GB).'
    'unknown_place' = '(unknown)'
    'cancel_btn' = 'Cancel'
    'confirm_q1' = 'Mine with these settings?'
    'confirm_title' = 'Confirm'
    'cred_cancel' = 'Cancelled: setup needs your wallet and pool password. Double-click TheNewMiner.bat again when you have them (pool website: {0}).'
    'cred_dialog_open' = '  A window has opened for your wallet, password and worker name (if you cannot see it, click "TheNewMiner" in the taskbar).'
    'cred_head' = 'Fill in the three fields and click OK; installing and mining then run by themselves.'
    'cred_kept' = '  Cancelled: the current settings are kept.'
    'cred_signup' = 'First time? Create your pool account first: {0}'
    'cred_title' = 'TheNewMiner - step 1: your pool account'
    'cred_using' = '  Account: wallet {0}, worker {1}'
    'dns_fail' = 'DNS does not work inside WSL (cannot resolve {0}). Fix: add dnsTunneling=true under [wsl2] in {1} (or networkingMode=mirrored on Windows 11 22H2 or newer), run wsl --shutdown, then double-click TheNewMiner.bat again. If Windows cannot open websites either, check the internet connection (and any firewall / VPN) first.'
    'dns_manual1' = 'DNS inside WSL does not work (cannot resolve {0}). Fix it once by hand:'
    'dns_manual2' = '  1. Open (or create) {0} in Notepad and add these two lines (if it already has [wsl2], add the second line under it):'
    'dns_manual3' = '     On Windows 11 22H2 or newer, networkingMode=mirrored instead of dnsTunneling=true also works.'
    'dns_manual4' = '  2. In a Command Prompt run wsl --shutdown (it stops every WSL distribution), then double-click TheNewMiner.bat again.'
    'dns_warn' = 'WSL cannot resolve {0} (not needed for this run: the model is here / the pool is reached through -Proxy IP).'
    'fail_at' = 'Failed at step {0}: '
    'ok_btn' = 'OK'
    'pw_empty' = 'Enter the pool password'
    'pw_guide' = 'Pool password = the password you set yourself on the pool website {0} under "Start mining" -> "Bind wallet" (not your wallet''s private key). No account yet? Bind your wallet on the website and set a password there first; it works at once.'
    'pw_label' = 'Pool password'
    'pw_ok' = '✓ entered'
    'pw_show' = 'Show the password'
    'sum_note' = '(The password is not shown. To change them later: TheNewMiner.bat setup)'
    'sum_wallet' = '  Wallet: {0}'
    'sum_worker' = '  Worker: {0}'
    'unexpected' = 'Unexpected error at line {0}: {1}. Double-click TheNewMiner.bat again; if it happens again, send a screenshot of this window.'
    'w_ok' = '✓ valid address (checksum OK)'
    'wallet_example' = 'Example (format only, do not use it): {0}'
    'wallet_label' = 'Wallet address (TensorCash, starts with tc1)'
    'wk_ok' = '✓ OK'
    'worker_label' = 'Worker name (tells your PCs apart on the pool; letters, digits, . _ -, at most 64)'
    'wp_case' = '✗ upper and lower case mixed: copy and paste it'
    'wp_chars' = '✗ has characters an address never has (space, b, i, o, 1 or punctuation): copy and paste it'
    'wp_checksum' = '✗ checksum wrong: a character is mistyped; copy and paste it'
    'wp_empty' = 'Paste your wallet address'
    'wp_example' = '✗ this is the example address: enter your own wallet'
    'wp_length' = '✗ wrong length (incomplete?): copy and paste the whole address'
    'wp_prefix' = '✗ a TensorCash wallet address starts with tc1'
    'wp_program' = '✗ not a valid tc1 address'
}
function T([string]$id) {
    $e = $Script:Msg[$id]
    if ($null -eq $e) { return $id }
    return $e
}

$Actions = @('auto', 'setup', 'start', 'background', 'logs', 'stop', 'status', 'uninstall')
# The pool password rule, in ONE place (audit R2, decided 2026-10-23; front.rs PASSWORD_LEN / valid_password is the
# same rule; the pw_hint / pw_q texts describe it; the pool page tsc.the-new.win says 6-128): 6-128 characters, any printable character (all ASCII punctuation,
# non-ASCII letters); refused: control characters (\p{Cc}, NUL among them) and whitespace (\s = Rust's is_whitespace
# set). A surrogate pair (a character beyond U+FFFF) counts as ONE character, as in Rust; a lone surrogate is refused.
# \\z, not $: .NET's $ also matches before a final newline, which would let "pw\\n" through.
$Script:PwRule = '^(?:[^\p{Cc}\s\uD800-\uDFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]){6,128}\z'
if (-not $Action) { $Action = 'auto' }            # TheNewMiner.bat "" ...
$Action = $Action.ToLowerInvariant()
if ($Actions -notcontains $Action) { Fail ((T 'bad_action') -f $Action) 2 }
# the failure file is about the run that wrote it: every new run starts without it
if (Test-Path -LiteralPath $Script:FailFile) { Remove-Item -LiteralPath $Script:FailFile -Force -ErrorAction SilentlyContinue }
if (Test-Path -LiteralPath $Script:FailVerFile) { Remove-Item -LiteralPath $Script:FailVerFile -Force -ErrorAction SilentlyContinue }

function Open-DriverPage { try { Start-Process 'https://www.nvidia.com/Download/index.aspx' } catch { } }
function Strip-Quotes([string]$s) {
    $s = ($s + '').Trim()
    while ($s.Length -ge 2 -and (($s.StartsWith('"') -and $s.EndsWith('"')) -or ($s.StartsWith("'") -and $s.EndsWith("'")))) {
        $s = $s.Substring(1, $s.Length - 2).Trim()
    }
    return $s
}
$DataDir = Strip-Quotes $DataDir

# ---------------------------------------------------------------- processes and quoting
# One argument for a Windows command line (the CommandLineToArgvW / MSVCRT rules wsl.exe and powershell.exe parse):
# quoted when it is empty or has a space, tab or quote; backslashes doubled before a quote and at the end.
function Quote-WinArg([string]$a) {
    if ($a.Length -gt 0 -and $a -notmatch '[\s"]') { return $a }
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $bs = 0
    foreach ($ch in $a.ToCharArray()) {
        if ($ch -eq [char]'\') { $bs++; continue }
        if ($ch -eq [char]'"') { [void]$sb.Append(('\' * (2 * $bs + 1)) + '"'); $bs = 0; continue }
        if ($bs -gt 0) { [void]$sb.Append('\' * $bs); $bs = 0 }
        [void]$sb.Append($ch)
    }
    if ($bs -gt 0) { [void]$sb.Append('\' * (2 * $bs)) }
    [void]$sb.Append('"')
    return $sb.ToString()
}
function Join-WinArgs([string[]]$argv) { return ((@($argv) | ForEach-Object { Quote-WinArg $_ }) -join ' ') }

# wsl.exe in THIS console (live output and progress lines, Ctrl+C reaches it), every argument quoted exactly.
# Returns its exit code (-1: it could not be started).
function Wsl-Run([string[]]$argv) {
    try {
        $p = Start-Process -FilePath 'wsl.exe' -ArgumentList (Join-WinArgs $argv) -NoNewWindow -PassThru -ErrorAction Stop
    } catch { return -1 }
    $null = $p.Handle                     # keeps the exit code readable after the wait (Windows PowerShell 5.1)
    $p.WaitForExit()
    return $p.ExitCode
}

# r3: wsl.exe's own output is UTF-16LE (with or without a BOM) unless WSL_UTF8 is honoured; what runs inside WSL writes
# UTF-8. The bytes decide: a BOM, else NULs at the odd positions = UTF-16LE, else UTF-8. NULs, BOMs and undecodable
# characters are dropped, so an ASCII name always comes out right whatever the encoding was.
function Decode-WslBytes([byte[]]$b) {
    if ($null -eq $b -or $b.Length -eq 0) { return '' }
    $enc = New-Object System.Text.UTF8Encoding($false)
    $skip = 0
    if ($b.Length -ge 2 -and $b[0] -eq 0xFF -and $b[1] -eq 0xFE) { $enc = [System.Text.Encoding]::Unicode; $skip = 2 }
    elseif ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) { $skip = 3 }
    else {
        $n = [math]::Min($b.Length, 4096)
        $n -= ($n % 2)
        $odd = 0; $even = 0
        for ($i = 0; $i -lt $n; $i += 2) {
            if ($b[$i] -eq 0) { $even++ }
            if ($b[$i + 1] -eq 0) { $odd++ }
        }
        if ($n -ge 2 -and (4 * $odd) -ge $n -and (4 * $even) -lt $odd) { $enc = [System.Text.Encoding]::Unicode }
    }
    $s = $enc.GetString($b, $skip, $b.Length - $skip)
    return ($s -replace "[`0﻿�]", '')
}

# wsl.exe with its output captured as text lines (Decode-WslBytes), the same exact quoting. Exit code in $Script:Rc
# (-2: killed after -TimeoutSec), its error output in $Script:WslErr.
function Wsl-Read([string[]]$argv, [int]$TimeoutSec = 0) {
    $Script:WslErr = ''
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'wsl.exe'
    $psi.Arguments = Join-WinArgs $argv
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    try { $p = [System.Diagnostics.Process]::Start($psi) } catch { $Script:Rc = -1; return @() }
    $ms = New-Object System.IO.MemoryStream
    $es = New-Object System.IO.MemoryStream
    $t1 = $p.StandardOutput.BaseStream.CopyToAsync($ms)
    $t2 = $p.StandardError.BaseStream.CopyToAsync($es)
    if ($TimeoutSec -gt 0) {
        if (-not $p.WaitForExit($TimeoutSec * 1000)) {
            try { $p.Kill() } catch { }
            $Script:Rc = -2
            return @()
        }
    }
    $p.WaitForExit()
    try { [void]$t1.Wait(15000); [void]$t2.Wait(15000) } catch { }
    $Script:Rc = $p.ExitCode
    $Script:WslErr = Decode-WslBytes $es.ToArray()
    $out = Decode-WslBytes $ms.ToArray()
    return @($out -split "`r?`n" | Where-Object { $_ -ne '' })
}

# r3: wsl.exe in this console with its output SHOWN as it comes AND kept ($Script:CapText): `wsl --install` exits 0
# even when its download failed, so only its words tell a network error from a virtualization one. Returns the exit code.
function Wsl-RunCapture([string[]]$argv) {
    $Script:CapText = ''
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'wsl.exe'
    $psi.Arguments = Join-WinArgs $argv
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    try { $p = [System.Diagnostics.Process]::Start($psi) } catch { return -1 }
    $es = New-Object System.IO.MemoryStream
    $t2 = $p.StandardError.BaseStream.CopyToAsync($es)
    $all = New-Object System.IO.MemoryStream
    $dec = (New-Object System.Text.UTF8Encoding($false)).GetDecoder()
    $buf = New-Object byte[] 4096
    $chars = New-Object char[] 8200
    $s = $p.StandardOutput.BaseStream
    while ($true) {
        # reads with a look at the process: a helper that inherited the pipe can never keep this loop waiting after
        # wsl.exe itself has ended (3 s grace for the last bytes)
        $t = $s.ReadAsync($buf, 0, $buf.Length)
        while (-not $t.Wait(500)) {
            if ($p.HasExited) { if (-not $t.Wait(3000)) { $t = $null }; break }
        }
        if ($null -eq $t) { break }
        $n = $t.Result
        if ($n -le 0) { break }
        $all.Write($buf, 0, $n)

        $nb = [byte[]]@($buf[0..($n - 1)] | Where-Object { $_ -ne 0 })      # UTF-16 ASCII shows too
        if ($nb.Length -eq 0) { continue }
        $c = $dec.GetChars($nb, 0, $nb.Length, $chars, 0)
        if ($c -gt 0) {
            $sb = New-Object System.Text.StringBuilder
            [void]$sb.Append($chars, 0, $c)
            Write-Host -NoNewline ($sb.ToString() -replace "[﻿�]", '')
        }

    }
    $p.WaitForExit()
    try { [void]$t2.Wait(15000) } catch { }
    $err = Decode-WslBytes $es.ToArray()
    if ($err.Trim()) { Write-Host $err }
    Write-Host ''
    $Script:CapText = (Decode-WslBytes $all.ToArray()) + "`n" + $err
    return $p.ExitCode
}

# r3: what a failed `wsl --install` (or a first start) said: network / virt / other. The exit code is never the answer.
function Install-Problem([string]$t) {
    if ($t -match '(?i)WININET_E_|0x80072e[ef][0-9a-f]') { return 'network' }
    if ($t -match '(?i)0x80370102|HCS_E_HYPERV') { return 'virt' }
    return 'other'
}

function Is-Admin {
    if ($env:TNM_TEST_ADMIN) { return $true }
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

# wsl.exe as Administrator (UAC prompt unless this already runs elevated). Returns its exit code.
function Wsl-Elevated([string[]]$argv) {
    if (Is-Admin) { return (Wsl-Run $argv) }
    Say (T 'uac_hint')
    try {
        $p = Start-Process -FilePath 'wsl.exe' -ArgumentList (Join-WinArgs $argv) -Verb RunAs -PassThru -ErrorAction Stop
        $null = $p.Handle
        $p.WaitForExit()
        return $p.ExitCode
    } catch {
        return -1
    }
}

function Wsl-Ready {
    if (-not (Test-Path -LiteralPath (Join-Path $env:ProgramFiles 'WSL\wsl.exe'))) { return $false }
    $null = Wsl-Read @('--version')
    return ($Script:Rc -eq 0)
}

# The names `wsl -l -q` lists: a notice line, a BOM or UTF-16 never count as a name (a WSL distro name is letters,
# digits, . _ -). Its exit code is not trusted either way. This list alone never decides that a distro is missing.
function Distros {
    $l = Wsl-Read @('-l', '-q')
    return @($l | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^[A-Za-z0-9._-]+$' })
}


# yes / no / unknown: does this wsl.exe know `--install --location` (its --help lists the option)?
function Location-Support {
    $h = (@(Wsl-Read @('--help')) -join "`n") + "`n" + $Script:WslErr
    $Script:HelpText = $h
    if (-not $h.Trim()) { return 'unknown' }
    if ($h -match '--location') { return 'yes' }
    return 'no'
}

# ---------------------------------------------------------------- places on Windows
function Desktop-Dir {
    if ($env:TNM_TEST_DESKTOP) { return $env:TNM_TEST_DESKTOP }
    try { return [Environment]::GetFolderPath('Desktop') } catch { return '' }
}
function Drive-Root([string]$p) {
    if ($p -match '^([A-Za-z]):') { return ($Matches[1].ToUpper() + ':\') }
    if ($p -match '^\\\\') { return '' }                      # \\server\share: no drive
    try { return [IO.Path]::GetPathRoot($p) } catch { return '' }
}
# The drives: Name (C:\), Type (Fixed / Removable / Network ...), Format (NTFS ...), FreeGb. TNM_TEST_DRIVES (JSON) in tests.
function Get-Drives {
    $out = @()
    if ($env:TNM_TEST_DRIVES) {
        foreach ($d in (ConvertFrom-Json $env:TNM_TEST_DRIVES)) {
            $out += [pscustomobject]@{ Name = [string]$d.Name; Type = [string]$d.Type; Format = [string]$d.Format; FreeGb = [double]$d.FreeGb }
        }
        return $out
    }
    foreach ($d in [IO.DriveInfo]::GetDrives()) {
        try {
            if (-not $d.IsReady) { continue }
            $out += [pscustomobject]@{ Name = $d.Name; Type = [string]$d.DriveType; Format = [string]$d.DriveFormat; FreeGb = [math]::Floor($d.AvailableFreeSpace / 1GB) }
        } catch { }
    }
    return $out
}
function Free-Gb([string]$p) {
    $root = Drive-Root $p
    if (-not $root) { return -1 }
    if ($env:TNM_TEST_DRIVES) { foreach ($d in (Get-Drives)) { if ($d.Name -eq $root) { return $d.FreeGb } } }
    try { return [math]::Floor((New-Object IO.DriveInfo $root).AvailableFreeSpace / 1GB) } catch { return -1 }
}
function Is-Under([string]$p, [string]$parent) {
    if (-not $p -or -not $parent) { return $false }
    $a = $p.TrimEnd('\', '/') + '\'
    $b = $parent.TrimEnd('\', '/') + '\'
    return $a.StartsWith($b, [StringComparison]::OrdinalIgnoreCase)
}
function Downloads-Dirs {
    $l = @()
    if ($env:TNM_TEST_DOWNLOADS) { $l += $env:TNM_TEST_DOWNLOADS }
    try {
        $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
        $v = (Get-ItemProperty -Path $k -Name '{374DE290-123F-4565-9164-39C4925E467B}' -ErrorAction Stop).'{374DE290-123F-4565-9164-39C4925E467B}'
        if ($v) { $l += [Environment]::ExpandEnvironmentVariables($v) }
    } catch { }
    if ($env:USERPROFILE) { $l += ($env:USERPROFILE.TrimEnd('\') + '\Downloads') }
    return $l
}
# Why the kit's own place is no place for a live virtual disk: onedrive / temp / downloads / removable / notntfs / unc,
# or '' when it is fine.
function Kit-Place([string]$kit) {
    foreach ($od in @($env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial)) { if (Is-Under $kit $od) { return 'onedrive' } }
    if ($kit -match '(?i)\\OneDrive( - [^\\]+)?(\\|$)') { return 'onedrive' }
    foreach ($t in @($env:TEMP, $env:TMP)) { if (Is-Under $kit $t) { return 'temp' } }
    if ($kit -match '(?i)\\(AppData\\Local\\Temp|Windows\\Temp)(\\|$)') { return 'temp' }
    foreach ($dl in (Downloads-Dirs)) { if (Is-Under $kit $dl) { return 'downloads' } }
    $root = Drive-Root $kit
    if (-not $root) { return 'unc' }
    $drv = @(Get-Drives | Where-Object { $_.Name -eq $root }) | Select-Object -First 1
    if (-not $drv) { return 'unc' }
    if ($drv.Type -ne 'Fixed') { return 'removable' }
    if ($drv.Format -ne 'NTFS') { return 'notntfs' }
    return ''
}
# The data folder of a first install, never inside the kit folder: <kit's drive>\TheNewMinerData when that drive is a
# fixed NTFS drive with room (wherever on it the kit sits: OneDrive, Temp or Downloads never hold the data), else the
# fixed NTFS non-system drive with the most free space, else %LOCALAPPDATA%\TheNewMiner\data.
function Choose-DataDir([string]$kit, [double]$need) {
    $sys = Drive-Root ($env:SystemDrive + '\')
    $kitRoot = Drive-Root $kit
    $ok = @(Get-Drives | Where-Object { $_.Type -eq 'Fixed' -and $_.Format -eq 'NTFS' -and $_.FreeGb -ge $need })
    $why = ''
    $k = @($ok | Where-Object { $_.Name -eq $kitRoot })
    if ($k.Count -gt 0) {
        return [pscustomobject]@{ Path = ($kitRoot + 'TheNewMinerData'); FreeGb = $k[0].FreeGb; Why = '' }
    }
    $place = Kit-Place $kit
    if ($place -eq 'removable' -or $place -eq 'notntfs' -or $place -eq 'unc') { $why = $place } else { $why = 'space' }
    $others = @($ok | Where-Object { $_.Name -ne $sys } | Sort-Object -Property FreeGb -Descending)
    if ($others.Count -gt 0) {
        return [pscustomobject]@{ Path = ($others[0].Name + 'TheNewMinerData'); FreeGb = $others[0].FreeGb; Why = $why }
    }
    $la = ($env:LOCALAPPDATA.TrimEnd('\') + '\TheNewMiner\data')
    return [pscustomobject]@{ Path = $la; FreeGb = (Free-Gb $la); Why = $why }
}
function Why-Text([string]$why) {
    switch ($why) {
        'removable' { return (T 'why_removable') }
        'notntfs' { return (T 'why_notntfs') }
        'unc' { return (T 'why_unc') }
        default { return (T 'why_space') }
    }
}
function Is-FullPath([string]$p) {
    if ($OnWindows) { return ($p -match '^[A-Za-z]:\\') }
    return [IO.Path]::IsPathRooted($p)
}
# A typed folder: a drive root or any folder that already exists (empty or not) gets a TheNewMinerData subfolder, so
# uninstall never removes the user's own folder or files put there later. A folder of ours (with the marker) is reused.
function Fit-DataDir([string]$p) {
    $p = $p.TrimEnd('\', '/')
    if ($p -match '^[A-Za-z]:$' -or -not $p) { return ($p + '\TheNewMinerData') }
    if ((Test-Path -LiteralPath $p) -and -not (Test-Path -LiteralPath (Join-Path $p $DataMarker))) {
        return (Join-Path $p 'TheNewMinerData')
    }
    return $p
}

# Only the user, SYSTEM and Administrators (by SID, any Windows language): the distro's disk, the staging copy and
# the script that runs as root in WSL are nobody else's to read or swap. Returns $false when it could not be done.
function Protect-Dir([string]$dir) {
    $sid = $env:TNM_TEST_SID
    if (-not $sid) { try { $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value } catch { $sid = '' } }
    if (-not $sid) { return $false }
    $icacls = 'icacls.exe'
    if ($env:SystemRoot -and (Test-Path -LiteralPath (Join-Path $env:SystemRoot 'System32\icacls.exe'))) { $icacls = Join-Path $env:SystemRoot 'System32\icacls.exe' }
    try {
        $null = & $icacls $dir.TrimEnd('\') '/inheritance:r' '/grant:r' ('*' + $sid + ':(OI)(CI)F') '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}
function Ensure-LocalBase {
    if (Test-Path -LiteralPath $LocalBase) { return }
    New-Item -ItemType Directory -Force -Path $LocalBase | Out-Null
    if (-not (Protect-Dir $LocalBase)) { Warn ((T 'acl_warn') -f $LocalBase) }
}

# The registered data folder of $Distro (HKCU\Software\Microsoft\Windows\CurrentVersion\Lxss\{guid}: DistributionName,
# BasePath), '' when it is not registered. TNM_TEST_LXSS (a JSON list) stands for the registry in tests.
function Lxss-Rows {
    $rows = @()
    if ($env:TNM_TEST_LXSS) {
        if (Test-Path -LiteralPath $env:TNM_TEST_LXSS) {
            foreach ($r in (Get-Content -Raw -LiteralPath $env:TNM_TEST_LXSS | ConvertFrom-Json)) { $rows += $r }
        }
    } else {
        $rows = @(Get-ChildItem -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss' -ErrorAction SilentlyContinue |
            ForEach-Object { Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue })
    }
    return $rows
}
function Get-DistroBase {
    foreach ($r in (Lxss-Rows)) {
        if ([string]$r.DistributionName -eq $Distro -and $r.BasePath) { return (([string]$r.BasePath) -replace '^\\\\\?\\', '') }
    }
    return ''
}
# r3 (v0.1.47 r2 missed an installed distro): a distro exists when the registry (HKCU\...\Lxss DistributionName) names
# it, or `wsl -l -q` lists it, or `wsl -d NAME -e true` exits with exactly 0 (a missing one gives -1,
# WSL_E_DISTRO_NOT_FOUND). Names compare without case, as WSL does.
function Distro-Exists([string]$name) {
    foreach ($r in (Lxss-Rows)) { if ([string]$r.DistributionName -eq $name) { return $true } }
    if ((Distros) -contains $name) { return $true }
    $null = Wsl-Read @('-d', $name, '-u', 'root', '-e', 'true') 120
    return ($Script:Rc -eq 0)
}
# Every distro this user has (the registry and the list), each name once.
function All-Distros {
    $seen = New-Object System.Collections.Generic.List[string]
    foreach ($n in (@(Lxss-Rows | ForEach-Object { [string]$_.DistributionName }) + @(Distros))) {
        if (-not $n -or $n -notmatch '^[A-Za-z0-9._-]+$') { continue }
        if (-not ($seen -contains $n)) { $seen.Add($n) }
    }
    return @($seen)
}

# r3: an earlier TheNewMiner install in ANOTHER distro (kits before the dedicated "TheNewMiner" distro used
# Ubuntu-24.04; a hand install unpacks the Linux package anywhere). One quick look per distro, as root:
#   kit    <root>/current -> the install in use (a kit's base: /root/thenewminer, /home/<user>/thenewminer)
#   kitdir <root>/TheNewMiner-v*-linux-x86_64*/ with ./thenewminer and .miner/ but no current (an older kit layout)
#   pkg    <root> itself holds ./thenewminer and .miner/ (the Linux package unpacked by hand: thenewminer/, TheNewMiner-v*/)
# A line per find: TNM_FOUND=kind|settings yes/no|root|install dir|version. TNM_WSL_ROOTFS (tests only) prefixes the paths.
# One line (joined with spaces: no newline has to survive the Windows command line), every part ends in ; or a keyword.
$Script:ProbeSh = (@(
    'R=${TNM_WSL_ROOTFS:-};',
    'ver() { v=$(sed -n "s/^version=//p" "$1/.tnm-kit" "$1/.miner/installed" 2>/dev/null | head -n 1);',
    'if [ -z "$v" ]; then v=$(printf "%s" "${1##*/}" | sed -n "s/^TheNewMiner-v\([0-9][0-9.]*\)-linux.*/\1/p"); fi;',
    'if [ -z "$v" ]; then v=$(grep -aom1 "v[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*" "$1/.miner/installed" 2>/dev/null | head -n 1 | tr -d v); fi;',
    'printf "%s" "$v"; };',
    'cfg() { if [ -f "$1/.miner/mining.json" ]; then printf yes; else printf no; fi; };',
    'for d in "$R"/root/thenewminer* "$R"/home/*/thenewminer* "$R"/root/TheNewMiner* "$R"/home/*/TheNewMiner*; do',
    'if [ ! -d "$d" -o -L "$d" ]; then continue; fi;',
    'if [ -L "$d/current" -a -d "$d/current/.miner" ]; then p=$(readlink -f "$d/current"); echo "TNM_FOUND=kit|$(cfg "$p")|$d|$p|$(ver "$p")"; continue; fi;',
    'for p in "$d" "$d"/TheNewMiner-v*-linux-x86_64*; do',
    'if [ ! -x "$p/thenewminer" -o ! -d "$p/.miner" ]; then continue; fi;',
    'k=kitdir; if [ "$p" = "$d" ]; then k=pkg; fi;',
    'echo "TNM_FOUND=$k|$(cfg "$p")|$d|$p|$(ver "$p")";',
    'done;',
    'done;',
    'exit 0'
) -join ' ')

# Distros that are never started or looked into: container engines' own VMs (Docker, Rancher, Podman).
function Skip-Distro([string]$n) { return ($n -like 'docker-desktop*' -or $n -like 'rancher-desktop*' -or $n -like 'podman-machine*' -or $n -like 'podman-*') }
$Script:ProbeFailed = @()
function Probe-Distro([string]$name, [int]$order) {
    $found = @()
    $lines = @(Wsl-Read @('-d', $name, '-u', 'root', '-e', 'sh', '-c', $Script:ProbeSh) 120)
    if ($Script:Rc -ne 0) { $Script:ProbeFailed += $name; return @() }
    foreach ($x in $lines) {
        if ($x -notlike 'TNM_FOUND=*') { continue }
        $f = $x.Substring(10).Split('|')
        if ($f.Count -lt 5 -or $f[2] -notmatch '^/' -or $f[2] -match '[''"%!^&]' -or $f[3] -match '[''"%!^&]') { continue }
        $v = [version]'0.0.0'
        [void][version]::TryParse(($f[4] + ''), [ref]$v)
        $found += [pscustomobject]@{ Distro = $name; Kind = $f[0]; Cfg = ($f[1] -eq 'yes'); Root = $f[2]; Dir = $f[3]
            Version = ($f[4] + ''); Key = $v; Order = $order }
    }
    return $found
}
# Where TheNewMiner.bat looks (its "mining?" check and the last log lines): the distro and the kit base inside it.
function Save-Where([string]$base) {
    try {
        Ensure-LocalBase
        [IO.File]::WriteAllText((Join-Path $LocalBase 'distro.txt'), $Distro)
        [IO.File]::WriteAllText((Join-Path $LocalBase 'base.txt'), $base)
    } catch { }
}
# Our own distro when it exists (r1 / r2 / r3 installs); otherwise the best install found in another distro (settings
# first, then a kit layout, then the newest version): $Distro becomes that distro and tnm-wsl.sh is pointed at it.
# docker-desktop* is never started or looked into. Nothing found: a fresh install into the dedicated distro.
function Resolve-Install {
    if ($Script:DistroGiven) {
        foreach ($e in (($env:TNM_INNER_ENV + '') -split "`n")) { if ($e -match '^TNM_WSL_(BASE|ADOPT)=/[^''"%!^&]*$') { $Script:InnerEnv += $e } }
        return
    }
    if (-not (Wsl-Ready)) { return }
    if (Distro-Exists $Distro) { Save-Where '/root/thenewminer'; return }
    if ($NewInstall) { return }
    $all = @()
    # the distro found last time first (no other distro is started for a daily start / stop / logs)
    $cached = ''
    try { $cached = ([IO.File]::ReadAllText((Join-Path $LocalBase 'distro.txt'))).Trim() } catch { }
    if ($cached -match '^[A-Za-z0-9._-]+$' -and $cached -ne $Distro -and -not (Skip-Distro $cached) -and ((All-Distros) -contains $cached)) {
        $all += @(Probe-Distro $cached 0)
    }
    if ($all.Count -eq 0) {
        $Script:ProbeFailed = @()
        $i = 0
        foreach ($n in (All-Distros)) {
            $i++
            if ($n -eq $Distro -or (Skip-Distro $n)) { continue }
            $all += @(Probe-Distro $n $i)
        }
    }
    if ($all.Count -eq 0) {
        # a distro that could not be looked into may hold the install: never a blind second install
        if ($Script:ProbeFailed.Count -gt 0 -and ($Action -eq 'auto' -or $Action -eq 'setup')) {
            $Script:CurStep = ''
            Fail ((T 'probe_fail') -f ($Script:ProbeFailed -join ', '))
        }
        return
    }
    $best = @($all | Sort-Object -Property @{ Expression = { $_.Cfg }; Descending = $true },
        @{ Expression = { $_.Kind -ne 'pkg' }; Descending = $true }, @{ Expression = { $_.Key }; Descending = $true },
        @{ Expression = { $_.Order }; Descending = $false }, @{ Expression = { $_.Dir }; Descending = $false })[0]
    $base = $best.Root
    $adopt = ''
    if ($best.Kind -eq 'kitdir') { $adopt = $best.Dir }
    if ($best.Kind -eq 'pkg') { $base = ($best.Root -replace '/[^/]+$', '') + '/thenewminer-kit'; $adopt = $best.Dir }
    $Script:Distro = $best.Distro
    $Script:InnerEnv = @('TNM_WSL_BASE=' + $base)
    if ($adopt) { $Script:InnerEnv += ('TNM_WSL_ADOPT=' + $adopt) }
    $Script:Legacy = [pscustomobject]@{ Distro = $best.Distro; Dir = $best.Dir; Base = $base; Version = $best.Version; Cfg = $best.Cfg }
    if ($best.Version) { $Script:KnownVer = $best.Version }
    Save-Where $base
}
function Data-Missing {
    $bp = Get-DistroBase
    return ($bp -and -not (Test-Path -LiteralPath $bp))
}

# Package names: TheNewMiner-vX.Y.Z-linux-x86_64[-sealed|-plain][-rN].tar.xz. Key = version, then revision (none = 1).
$PkgRe = '^TheNewMiner-v\d+\.\d+\.\d+-linux-x86_64(-sealed|-plain)?(-r\d+)?\.tar\.xz$'
function Pkg-Version([string]$s) { if ($s -match 'v(\d+\.\d+\.\d+)') { return $Matches[1] } return '' }
function Pkg-Rev([string]$s) { if ($s -match '-r(\d+)(\.tar\.xz)?$') { return [int]$Matches[1] } return 1 }
# >0 when version/revision a is newer than b
function Compare-Key([string]$va, [int]$ra, [string]$vb, [int]$rb) {
    $c = ([version]$va).CompareTo([version]$vb)
    if ($c -ne 0) { return $c }
    return $ra.CompareTo($rb)
}
# The package bundled in this kit (files\ = $PSScriptRoot) - ONLY there, never the current folder or Downloads. Several:
# the highest version / revision.
function Find-BundledPackage {
    $all = @(Get-ChildItem -LiteralPath $PSScriptRoot -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $PkgRe })
    if ($all.Count -eq 0) { return $null }
    $best = $all[0]
    foreach ($f in $all) {
        if ((Compare-Key (Pkg-Version $f.Name) (Pkg-Rev $f.Name) (Pkg-Version $best.Name) (Pkg-Rev $best.Name)) -gt 0) { $best = $f }
    }
    return $best.FullName
}
# The sha256 of a local package: -Sha256, else <file>.sha256, else its line in a SHA256SUMS beside it; '' when none.
function Local-Sha([string]$file) {
    if ($Sha256) { return $Sha256 }
    $name = [IO.Path]::GetFileName($file)
    if (Test-Path -LiteralPath ($file + '.sha256')) {
        $w = (((Get-Content -LiteralPath ($file + '.sha256') -TotalCount 1) + '').Trim() -split '\s+')[0]
        if ($w -match '^[0-9a-fA-F]{64}$') { return $w }
    }
    $sums = Join-Path (Split-Path -Parent $file) 'SHA256SUMS'
    if (Test-Path -LiteralPath $sums) {
        foreach ($ln in (Get-Content -LiteralPath $sums)) {
            $p = @(($ln + '').Trim() -split '\s+')
            if ($p.Count -ge 2 -and ($p[-1] -replace '^\*', '') -eq $name -and $p[0] -match '^[0-9a-fA-F]{64}$') { return $p[0] }
        }
    }
    return ''
}

# A desktop shortcut to this kit's TheNewMiner.bat (re-pointed silently when a newer kit runs from another folder).
function Shortcut-Path { $d = Desktop-Dir; if (-not $d) { return '' } return (Join-Path $d 'TheNewMiner.lnk') }
function New-DesktopShortcut([bool]$quiet) {
    try {
        if (-not (Test-Path -LiteralPath $EntryBat)) { return }
        $lnk = Shortcut-Path
        if (-not $lnk) { return }
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($lnk)
        if ($quiet -and $sc.TargetPath -eq $EntryBat) { return }
        $sc.TargetPath = $EntryBat
        $sc.WorkingDirectory = (Split-Path $EntryBat)
        $sc.Description = 'TheNewMiner'
        $sc.Save()
        if (-not $quiet) { Say (T 'shortcut_made') }
    } catch { }
}
# When a reboot is needed to finish turning WSL on, resume setup automatically at the next sign-in (one time). Every
# exit 3010 goes through Exit-Reboot, so the RunOnce entry is always there.
$RunOnceKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
function Set-ResumeAfterReboot {
    if (-not (Test-Path -LiteralPath $EntryBat)) { return }
    $v = '"' + $EntryBat + '"'
    if ($env:TNM_TEST_RUNONCE) { [IO.File]::WriteAllText($env:TNM_TEST_RUNONCE, $v); return }
    try {
        if (-not (Test-Path -LiteralPath $RunOnceKey)) { New-Item -Path $RunOnceKey -Force | Out-Null }
        New-ItemProperty -LiteralPath $RunOnceKey -Name 'TheNewMiner' -Value $v -PropertyType String -Force | Out-Null
    } catch { }
}
function Exit-Reboot([string]$text) {
    Set-ResumeAfterReboot
    Say ''
    Write-Host $text -ForegroundColor Yellow
    exit 3010
}

# [n/N] title (about X min) - everything left about Y min, done about HH:mm. Minutes come from $Script:Plan, which the
# steps lower as soon as they know a part is already done.
function Step([int]$n, [string]$title) {
    $keys = @($Script:Plan.Keys)
    $left = 0.0
    for ($i = $n - 1; $i -lt $keys.Count; $i++) { $left += [double]$Script:Plan[$keys[$i]] }
    $mine = [double]$Script:Plan[$keys[$n - 1]]
    $Script:CurStep = ('{0}/{1} ({2})' -f $n, $keys.Count, $title)
    $finish = (Get-Date).AddMinutes($left).ToString('HH:mm')
    $hkt = [DateTime]::UtcNow.AddMinutes($left).AddHours(8).ToString('HH:mm')
    Write-Host ''
    Write-Host ((T 'step_hdr') -f $n, $keys.Count, $title, (Fmt $mine), (Fmt $left), $finish, $hkt) -ForegroundColor Cyan
}

# A Linux path from wslpath: the first line that is one (a wsl.exe notice on stdout is skipped).
function Linux-Path([string]$win) {
    $l = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'wslpath', '-u', $win)
    return (@($l | Where-Object { $_ -like '/*' }) | Select-Object -First 1)
}

function Inner-Args([string[]]$rest) {
    $pre = @('-d', $Distro, '-u', 'root', '-e')
    if ($Script:InnerEnv.Count -gt 0) { $pre += @('/usr/bin/env') + $Script:InnerEnv }       # an install in another distro
    return $pre + @('/bin/bash', $Script:InnerLinux) + $rest
}

# Copy tnm-wsl.sh to %LOCALAPPDATA%\TheNewMiner\wsl\ (locked to this user) with LF line endings (a git checkout on
# Windows may have made them CRLF) and learn its path inside WSL.
function Try-PrepareInner {
    if (-not (Test-Path -LiteralPath $InnerSrc)) { return $false }
    Ensure-LocalBase
    New-Item -ItemType Directory -Force -Path (Split-Path $InnerWin) | Out-Null
    $text = [IO.File]::ReadAllText($InnerSrc) -replace "`r`n", "`n"
    [IO.File]::WriteAllText($InnerWin, $text, (New-Object System.Text.UTF8Encoding($false)))
    $p = Linux-Path $InnerWin
    if (-not $p) { return $false }
    $Script:InnerLinux = $p.Trim()
    return $true
}
function Prepare-Inner {
    if (-not (Test-Path -LiteralPath $InnerSrc)) { Fail ((T 'no_inner') -f $InnerSrc) }
    if (-not (Try-PrepareInner)) { Fail ((T 'no_wslpath') -f $Distro, $InnerWin) }
}

function Inner-Read([string[]]$rest) { return (Wsl-Read (Inner-Args $rest)) }
function Inner-Run([string[]]$rest) { return (Wsl-Run (Inner-Args $rest)) }
function Tnm-Value($lines, [string]$key) {
    foreach ($l in $lines) { if ($l -like "$key=*") { return $l.Substring($key.Length + 1) } }
    return $null
}

# v0.1.45: a second double-click (or start/background) that finds the miner running says so in a banner nobody can
# miss, in the window's language, before the live log - it never starts a second miner.
function Show-AlreadyMining {
    $rule = '=' * 66
    Write-Host ''
    Write-Host $rule -ForegroundColor Yellow
    Write-Host ('  ' + (T 'already_banner') + '  ') -ForegroundColor Black -BackgroundColor Yellow
    Write-Host ('  ' + (T 'already_banner2')) -ForegroundColor Yellow
    Write-Host $rule -ForegroundColor Yellow
    Write-Host ''
}

function Is-Running {
    $r = Inner-Read @('running')
    return (($r | Select-Object -Last 1) -eq 'yes')
}

# How far WSL's clock is from Windows' (ms). WSL2 can drift after the PC sleeps; the pool binding stops a miner whose
# clock is 30 s off. The VM's clock is shared by every distro on the PC, so it is never set from here: only reported.
function Clock-Skew {
    $t0 = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $l = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'date', '+%s%3N')
    $t1 = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $v = 0L
    $first = @($l | Where-Object { $_ -match '^\s*\d+\s*$' }) | Select-Object -First 1
    if (-not [int64]::TryParse(($first + '').Trim(), [ref]$v)) { return $null }
    return [int64]($v - ($t0 + $t1) / 2)
}
function Check-Clock {
    $s = Clock-Skew
    if ($null -eq $s -or [math]::Abs($s) -le 2000) { return }
    Warn ((T 'clock_off') -f ($s / 1000.0))
}

# Keep Windows from sleeping while this window mines (until this window closes).
function Keep-Awake {
    try {
        Add-Type -Namespace TNM -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);' -ErrorAction Stop
        [void][TNM.Power]::SetThreadExecutionState([uint32]2147483649)   # ES_CONTINUOUS | ES_SYSTEM_REQUIRED
    } catch { }
}

function Need-Installed {
    if (-not (Wsl-Ready)) { Fail (T 'need_wsl') }
    if (-not (Distro-Exists $Distro)) { Fail ((T 'need_distro') -f $Distro) }
    if (Data-Missing) { Fail ((T 'data_missing') -f (Get-DistroBase)) }
    Prepare-Inner
}

function Show-Help {
    Say ''
    Say (T 'help_title')
    Say (T 'help_start')
    Say (T 'help_bg')
    Say (T 'help_logs')
    Say (T 'help_stop')
    Say (T 'help_status')
    Say (T 'help_uninstall')
}

function Start-Mining([string[]]$frontArgs, [bool]$hidden) {
    Check-Clock
    if ($hidden) {
        $env:TNM_FRONT_ARGS = ($frontArgs -join ' ')       # worker / proxy: no spaces (validated)
        $env:TNM_INNER_ENV = ($Script:InnerEnv -join "`n")  # r3: an install in another distro (checked again there)
        $me = 'powershell.exe'
        try { $me = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName } catch { }
        $cmd = Join-WinArgs @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PSCommandPath, '-Action', 'start', '-Distro', $Distro)
        Start-Process -FilePath $me -ArgumentList $cmd -WindowStyle Hidden | Out-Null
        $env:TNM_FRONT_ARGS = $null
        $env:TNM_INNER_ENV = $null
        Say (T 'bg_started')
        Say (T 'bg_hint')
        return 0
    }
    Keep-Awake
    Say (T 'fg_started')
    return (Inner-Run (@('run') + $frontArgs))
}

# ---------------------------------------------------------------- the pool account (v0.1.47 r2: step 1, one dialog)
# The wallet check is the front's (front.rs valid_wallet, tools/testdata/bech32_vectors.json): segwit bech32 / bech32m
# with hrp tc, lower case, never the example address. The worker and password rules are the front's too.
$Script:PoolSite = 'https://tsc.the-new.win/#/home'
$Script:ExampleWallet = 'tc1qces6ejzrp6tlva6gq4w7k58mp3d3w5hj3epmr3'   # checksum-valid, nobody's address, refused
$Script:B32 = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l'
function B32-Polymod([int[]]$values) {
    $gen = @(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
    [long]$chk = 1
    foreach ($v in $values) {
        $top = $chk -shr 25
        $chk = (($chk -band 0x1ffffff) -shl 5) -bxor $v
        for ($i = 0; $i -lt 5; $i++) { if ((($top -shr $i) -band 1) -ne 0) { $chk = $chk -bxor $gen[$i] } }
    }
    return $chk
}
function Wallet-Problem([string]$a) {
    if (-not $a) { return 'empty' }
    if (-not $a.StartsWith('tc1', [StringComparison]::OrdinalIgnoreCase)) { return 'prefix' }
    if ($a -cne $a.ToLowerInvariant()) { return 'case' }
    $data = $a.Substring(3)
    foreach ($ch in $data.ToCharArray()) { if ($Script:B32.IndexOf($ch) -lt 0) { return 'chars' } }
    if ($a.Length -lt 14 -or $a.Length -gt 90) { return 'length' }
    $v = New-Object System.Collections.Generic.List[int]
    foreach ($ch in [char[]]'tc') { $v.Add([int]$ch -shr 5) }
    $v.Add(0)
    foreach ($ch in [char[]]'tc') { $v.Add([int]$ch -band 31) }
    $d = @($data.ToCharArray() | ForEach-Object { $Script:B32.IndexOf($_) })
    foreach ($x in $d) { $v.Add($x) }
    $const = B32-Polymod $v.ToArray()
    $bech32m = 0x2bc830a3
    if ($const -ne 1 -and $const -ne $bech32m) { return 'checksum' }
    $ver = $d[0]
    if ($ver -gt 16) { return 'program' }
    if ($ver -eq 0 -and $const -ne 1) { return 'checksum' }
    if ($ver -ne 0 -and $const -ne $bech32m) { return 'checksum' }
    # the program: 5-bit groups to bytes, no padding (fewer than 5 leftover bits, all zero)
    $acc = 0; $bits = 0; $n = 0
    for ($i = 1; $i -lt $d.Count - 6; $i++) {
        $acc = (($acc -shl 5) -bor $d[$i]) -band 0xfff
        $bits += 5
        while ($bits -ge 8) { $bits -= 8; $n++ }
    }
    if ($bits -ge 5 -or ((($acc -shl (8 - $bits)) -band 0xff) -ne 0)) { return 'program' }
    if ($ver -eq 0 -and $n -ne 20 -and $n -ne 32) { return 'program' }
    if ($n -lt 2 -or $n -gt 40) { return 'program' }
    if ($a -ceq $Script:ExampleWallet) { return 'example' }
    return ''
}
function Normalize-Wallet([string]$a) {
    $a = ($a + '').Trim()
    if ($a -ceq $a.ToUpperInvariant()) { $a = $a.ToLowerInvariant() }
    return $a
}
function Worker-Ok([string]$w) { return ($w -cmatch '^[A-Za-z0-9._-]{1,64}\z') }
function Password-Ok([string]$p) { return ($p -match $Script:PwRule) }
function Default-Worker {
    $w = (($env:COMPUTERNAME + '') -replace '[^A-Za-z0-9._-]', '')
    if ($w.Length -gt 64) { $w = $w.Substring(0, 64) }
    if (-not $w) { $w = 'rig' }
    return $w
}
function Mask-Wallet([string]$w) {
    if ($w.Length -le 16) { return $w }
    return ($w.Substring(0, 8) + '...' + $w.Substring($w.Length - 6))
}
function Wallet-Text([string]$problem) {
    switch ($problem) {
        '' { return (T 'w_ok') }
        'empty' { return (T 'wp_empty') }
        'prefix' { return (T 'wp_prefix') }
        'case' { return (T 'wp_case') }
        'chars' { return (T 'wp_chars') }
        'length' { return (T 'wp_length') }
        'checksum' { return (T 'wp_checksum') }
        'example' { return (T 'wp_example') }
        default { return (T 'wp_program') }
    }
}

# The dialog: TopMost, brought to the front. OK stays grey until every field is valid; OK then asks Yes / No on a
# summary without the password. Returns the account, or $null for Cancel. Throws when there is no desktop or Windows
# Forms cannot load: the caller then asks in the console.
function Show-AccountDialog($pre) {
    if ($env:TNM_TEST_DIALOG) {
        # tools/test_windows_wsl.py (no Windows Forms on Linux): the answer comes from this JSON file and every dialog
        # shown is counted in <file>.shown, so the tests prove ONE dialog and no console question after it
        [IO.File]::AppendAllText($env:TNM_TEST_DIALOG + '.shown', ($pre.Wallet + '|' + $pre.Worker + "`n"))
        Say (T 'cred_dialog_open')
        $j = Get-Content -Raw -LiteralPath $env:TNM_TEST_DIALOG | ConvertFrom-Json
        if ($j.cancel) { return $null }
        return [pscustomobject]@{ Wallet = (Normalize-Wallet ([string]$j.wallet)); Password = [string]$j.password; Worker = [string]$j.worker }
    }
    # no desktop to show it on (SSH, a service): the caller asks in the console instead
    $session = 1
    try { $session = [Diagnostics.Process]::GetCurrentProcess().SessionId } catch { }
    if (-not $OnWindows -or $env:SSH_CONNECTION -or $env:SSH_CLIENT -or -not [Environment]::UserInteractive -or $session -eq 0) { throw 'no desktop' }
    $d = New-AccountForm $pre
    Say (T 'cred_dialog_open')
    [void]$d.Form.ShowDialog()
    $d.Form.Dispose()
    return $Script:DialogResult
}
# The form itself (tools/windows/ci builds it on a real Windows and types into it). Its controls are in $Script:Dlg:
# the event handlers run later, from ShowDialog, so they reach the controls there, never through local variables.
function New-AccountForm($pre) {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
    Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $fontName = 'Segoe UI'
    $font = New-Object System.Drawing.Font($fontName, 11)
    $bold = New-Object System.Drawing.Font($fontName, 13, [System.Drawing.FontStyle]::Bold)
    $small = New-Object System.Drawing.Font($fontName, 9.5)
    $W = 620
    $form = New-Object System.Windows.Forms.Form
    $form.Text = (T 'cred_title')
    $form.Font = $font
    $form.TopMost = $true
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.AutoSize = $true
    $form.AutoSizeMode = 'GrowAndShrink'
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.FlowDirection = 'TopDown'
    $flow.WrapContents = $false
    $flow.AutoSize = $true
    $flow.AutoSizeMode = 'GrowAndShrink'
    $flow.Padding = New-Object System.Windows.Forms.Padding(18)
    $form.Controls.Add($flow)
    function New-Label([string]$text, $f, $color) {
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $text
        $l.AutoSize = $true
        $l.MaximumSize = New-Object System.Drawing.Size($W, 0)
        if ($f) { $l.Font = $f }
        if ($color) { $l.ForeColor = $color }
        $l.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
        $flow.Controls.Add($l)
        return $l
    }
    function New-Link([string]$text) {
        $l = New-Object System.Windows.Forms.LinkLabel
        $l.Text = $text
        $l.AutoSize = $true
        $l.MaximumSize = New-Object System.Drawing.Size($W, 0)
        $at = $text.IndexOf($Script:PoolSite)
        if ($at -ge 0) { $l.LinkArea = New-Object System.Windows.Forms.LinkArea($at, $Script:PoolSite.Length) }
        $l.Add_LinkClicked({ try { Start-Process $Script:PoolSite } catch { } })
        $l.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
        $flow.Controls.Add($l)
        return $l
    }
    function New-Box([string]$text) {
        $b = New-Object System.Windows.Forms.TextBox
        $b.Width = $W
        $b.Text = $text
        $b.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
        $flow.Controls.Add($b)
        return $b
    }
    $gray = [System.Drawing.Color]::DimGray
    [void](New-Label (T 'cred_head') $bold $null)
    [void](New-Link ((T 'cred_signup') -f $Script:PoolSite))
    [void](New-Label ' ' $small $null)
    [void](New-Label (T 'wallet_label') $bold $null)
    $tbW = New-Box ($pre.Wallet + '')
    $stW = New-Label ' ' $small $null
    [void](New-Label ((T 'wallet_example') -f $Script:ExampleWallet) $small $gray)
    [void](New-Label ' ' $small $null)
    [void](New-Label (T 'pw_label') $bold $null)
    $tbP = New-Box ($pre.Password + '')
    $tbP.UseSystemPasswordChar = $true
    $show = New-Object System.Windows.Forms.CheckBox
    $show.Text = (T 'pw_show')
    $show.AutoSize = $true
    $show.Font = $small
    $show.Add_CheckedChanged({ $Script:Dlg.P.UseSystemPasswordChar = -not $Script:Dlg.Show.Checked })
    if ($pre.Password) { $show.Visible = $false }          # a saved password is never shown, only replaced
    $flow.Controls.Add($show)
    $stP = New-Label ' ' $small $null
    [void](New-Link ((T 'pw_guide') -f $Script:PoolSite))
    [void](New-Label ' ' $small $null)
    [void](New-Label (T 'worker_label') $bold $null)
    $tbK = New-Box ($pre.Worker + '')
    $stK = New-Label ' ' $small $null
    $btns = New-Object System.Windows.Forms.FlowLayoutPanel
    $btns.FlowDirection = 'RightToLeft'
    $btns.Width = $W
    $btns.AutoSize = $true
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = (T 'ok_btn')
    $ok.AutoSize = $true
    $ok.Padding = New-Object System.Windows.Forms.Padding(14, 4, 14, 4)
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = (T 'cancel_btn')
    $cancel.AutoSize = $true
    $cancel.Padding = New-Object System.Windows.Forms.Padding(10, 4, 10, 4)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $btns.Controls.Add($ok)
    $btns.Controls.Add($cancel)
    $flow.Controls.Add($btns)
    $form.AcceptButton = $ok
    $form.CancelButton = $cancel
    $Script:Dlg = @{ Form = $form; W = $tbW; P = $tbP; K = $tbK; SW = $stW; SP = $stP; SK = $stK; Ok = $ok; Show = $show }
    $Script:DialogResult = $null
    $check = {
        $d = $Script:Dlg
        $red = [System.Drawing.Color]::Firebrick
        $green = [System.Drawing.Color]::ForestGreen
        $wp = Wallet-Problem (Normalize-Wallet $d.W.Text)
        $d.SW.Text = (Wallet-Text $wp)
        if ($wp) { $d.SW.ForeColor = $red } else { $d.SW.ForeColor = $green }
        $pOk = Password-Ok $d.P.Text
        if (-not $d.P.Text) { $d.SP.Text = (T 'pw_empty') } elseif ($pOk) { $d.SP.Text = (T 'pw_ok') } else { $d.SP.Text = (T 'pw_hint') }
        if ($pOk) { $d.SP.ForeColor = $green } else { $d.SP.ForeColor = $red }
        $kOk = Worker-Ok $d.K.Text.Trim()
        if ($kOk) { $d.SK.Text = (T 'wk_ok'); $d.SK.ForeColor = $green } else { $d.SK.Text = (T 'bad_worker'); $d.SK.ForeColor = $red }
        $d.Ok.Enabled = ((-not $wp) -and $pOk -and $kOk)
    }
    $tbW.Add_TextChanged($check)
    $tbP.Add_TextChanged($check)
    $tbK.Add_TextChanged($check)
    & $check
    $ok.Add_Click({
        $d = $Script:Dlg
        $w = Normalize-Wallet $d.W.Text
        $k = $d.K.Text.Trim()
        $msg = (T 'confirm_q1') + "`r`n`r`n" + ((T 'sum_wallet') -f (Mask-Wallet $w)) + "`r`n" + ((T 'sum_worker') -f $k) + "`r`n`r`n" + (T 'sum_note')
        $r = [System.Windows.Forms.MessageBox]::Show($d.Form, $msg, (T 'confirm_title'), [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
            $Script:DialogResult = [pscustomobject]@{ Wallet = $w; Password = $d.P.Text; Worker = $k }
            $d.Form.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $d.Form.Close()
        }
    })
    $form.Add_Shown({
        $d = $Script:Dlg
        $d.Form.TopMost = $true
        $d.Form.Activate()
        $d.Form.BringToFront()
        if ($d.W.Text) { [void]$d.P.Focus() } else { [void]$d.W.Focus() }
    })
    return $Script:Dlg
}

# A console answer: hidden when typed (-Secret); a plain line read from the pipe when the input is redirected (Windows
# PowerShell 5.1's Read-Host does not read a redirected input reliably).
function Read-Line([string]$prompt, [switch]$Secret) {
    if ([Console]::IsInputRedirected) { Write-Host ($prompt + ': ') -NoNewline; return ([Console]::In.ReadLine() + '') }
    if ($Secret) { return (Secure-Plain (Read-Host $prompt -AsSecureString)) }
    return ((Read-Host $prompt) + '')
}
function Secure-Plain($sec) {
    $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}
# The console, only when the dialog cannot open (SSH, no desktop): the v0.1.46 questions, with the same checks.
function Read-AccountConsole($pre) {
    $w = Normalize-Wallet $pre.Wallet
    for ($i = 0; $i -lt 5 -and (Wallet-Problem $w); $i++) {
        if ($w) { Warn (Wallet-Text (Wallet-Problem $w)) }
        $w = Normalize-Wallet (Read-Line (T 'wallet_q'))
    }
    if (Wallet-Problem $w) { Fail (T 'bad_wallet') }
    $pw = ''
    for ($i = 0; $i -lt 5 -and -not (Password-Ok $pw); $i++) {
        if ($pw) { Warn (T 'pw_hint') }
        $pw = Read-Line (T 'pw_q') -Secret
        if (Password-Ok $pw) {
            $pw2 = Read-Line (T 'pw_again') -Secret
            if ($pw2 -cne $pw) { Warn (T 'pw_differ'); $pw = '' }
        }
    }
    if (-not (Password-Ok $pw)) { Fail (T 'bad_pw') }
    $def = $pre.Worker
    if (-not (Worker-Ok $def)) { $def = Default-Worker }
    $wk = ''
    for ($i = 0; $i -lt 5 -and -not (Worker-Ok $wk); $i++) {
        $wk = (Read-Line ((T 'worker_q') -f $def)).Trim()
        if (-not $wk) { $wk = $def }
    }
    if (-not (Worker-Ok $wk)) { Fail (T 'bad_worker') }
    return [pscustomobject]@{ Wallet = $w; Password = $pw; Worker = $wk }
}

# Step 1: the account, before anything long. An install that has its settings keeps them without a question on a
# double-click (an upgrade) or with -Yes; TheNewMiner.bat setup opens the dialog to change them (Cancel keeps them).
# Sets $Script:Acct (the new account, $null = keep the install's) and $Script:Asked (dialog / console / '').
$Script:Acct = $null
$Script:Asked = ''
function Get-Account {
    $s = @()
    if ((Wsl-Ready) -and (Distro-Exists $Distro) -and -not (Data-Missing) -and (Try-PrepareInner)) { $s = Inner-Read @('settings') }
    $have = ((Tnm-Value $s 'TNM_SET') -ne 'none' -and (Tnm-Value $s 'TNM_SET_WALLET'))
    $pre = [pscustomobject]@{ Wallet = $Wallet; Worker = $Worker }
    if ($have) {
        Say ((T 'prev_settings') -f (Tnm-Value $s 'TNM_SET_WALLET'), (Tnm-Value $s 'TNM_SET_WORKER'), (Tnm-Value $s 'TNM_SET_PROXY'))
        if (-not $Wallet -and ($Yes -or $Action -eq 'auto')) { return }
        if (-not $pre.Worker) { $pre.Worker = Tnm-Value $s 'TNM_SET_WORKER' }
    }
    if (-not (Worker-Ok $pre.Worker)) { $pre.Worker = Default-Worker }
    $a = $null
    try { $a = Show-AccountDialog $pre; $Script:Asked = 'dialog' } catch { $Script:Asked = 'console' }
    if ($Script:Asked -eq 'console') { $a = Read-AccountConsole $pre }
    if (-not $a) {
        if ($have) { Say (T 'cred_kept'); return }
        Fail ((T 'cred_cancel') -f $Script:PoolSite)
    }
    Say ((T 'cred_using') -f (Mask-Wallet $a.Wallet), $a.Worker)
    $Script:Acct = $a
}

# ---------------------------------------------------------------- where the install is (r3)
Resolve-Install

# ---------------------------------------------------------------- uninstall
if ($Action -eq 'uninstall' -and $Script:Legacy) {
    # the install lives in the user's own distro: that distro is never unregistered
    if (-not $Yes) {
        $a = (Read-Line ((T 'uninst_q_legacy') -f $Distro, $LocalBase, $Script:Legacy.Base)).Trim()
        if ($a -notmatch '^[yY]') { Say (T 'cancelled'); exit 0 }
    }
    if (Try-PrepareInner) { if (Is-Running) { Say (T 'stopping_old'); [void](Inner-Run @('stop')) } }
    $lnk = Shortcut-Path
    if ($lnk -and (Test-Path -LiteralPath $lnk)) { Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue }
    if ($env:TNM_TEST_RUNONCE) { Remove-Item -LiteralPath $env:TNM_TEST_RUNONCE -Force -ErrorAction SilentlyContinue }
    else { try { Remove-ItemProperty -LiteralPath $RunOnceKey -Name 'TheNewMiner' -ErrorAction Stop } catch { } }
    if (Test-Path -LiteralPath $LocalBase) { Remove-Item -LiteralPath $LocalBase -Recurse -Force -ErrorAction SilentlyContinue }
    Say ((T 'uninst_legacy_left') -f $Distro, $Script:Legacy.Base)
    Say (T 'uninst_done')
    exit 0
}
if ($Action -eq 'uninstall') {
    $ready = Wsl-Ready
    $registered = $ready -and (Distro-Exists $Distro)
    $bp = Get-DistroBase
    # r3: only our own distro is ever unregistered (the dedicated name, or a disk folder we made)
    if ($registered -and $Distro -ne 'TheNewMiner' -and -not ($bp -and (Test-Path -LiteralPath (Join-Path $bp $DataMarker)))) {
        Fail ((T 'uninst_not_ours') -f $Distro)
    }
    $where = $bp
    if (-not $where) { $where = (T 'unknown_place') }
    if (-not $Yes) {
        $a = (Read-Line ((T 'uninst_q') -f $Distro, $where)).Trim()
        if ($a -notmatch '^[yY]') { Say (T 'cancelled'); exit 0 }
    }
    if ($registered) {
        if (-not (Data-Missing)) {
            Prepare-Inner
            if (Is-Running) { Say (T 'stopping_old'); [void](Inner-Run @('stop')) }
        }
        $unregRc = Wsl-Run @('--unregister', $Distro)
        if ($unregRc -ne 0 -and (Distro-Exists $Distro)) { Fail ((T 'uninst_unreg_fail') -f $Distro, $unregRc) }
    }
    if ($bp -and (Test-Path -LiteralPath $bp)) {
        if (Test-Path -LiteralPath (Join-Path $bp $DataMarker)) {
            Remove-Item -LiteralPath $bp -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            $vhd = Join-Path $bp 'ext4.vhdx'
            if (Test-Path -LiteralPath $vhd) { Remove-Item -LiteralPath $vhd -Force -ErrorAction SilentlyContinue }
            if (@(Get-ChildItem -LiteralPath $bp -Force -ErrorAction SilentlyContinue).Count -eq 0) { Remove-Item -LiteralPath $bp -Force -ErrorAction SilentlyContinue }
            else { Say ((T 'uninst_left') -f $bp) }
        }
    }
    $lnk = Shortcut-Path
    if ($lnk -and (Test-Path -LiteralPath $lnk)) { Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue }
    if ($env:TNM_TEST_RUNONCE) { Remove-Item -LiteralPath $env:TNM_TEST_RUNONCE -Force -ErrorAction SilentlyContinue }
    else { try { Remove-ItemProperty -LiteralPath $RunOnceKey -Name 'TheNewMiner' -ErrorAction Stop } catch { } }
    if (Test-Path -LiteralPath $LocalBase) { Remove-Item -LiteralPath $LocalBase -Recurse -Force -ErrorAction SilentlyContinue }
    if ($env:ProgramData) {
        $old = Join-Path $env:ProgramData 'TheNewMiner'          # where kits before r3 staged the package
        if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say (T 'uninst_done')
    exit 0
}

# ---------------------------------------------------------------- daily use
if ($Action -ne 'setup' -and $Action -ne 'auto') {
    Need-Installed
    switch ($Action) {
        'start' {
            if (Is-Running) { Show-AlreadyMining; Say (T 'already_bg'); exit 0 }
            $fa = @()
            if ($env:TNM_FRONT_ARGS) { $fa = @($env:TNM_FRONT_ARGS -split ' ' | Where-Object { $_ }) }
            exit (Start-Mining $fa $false)
        }
        'background' {
            if (Is-Running) { Show-AlreadyMining; Say (T 'already'); exit 0 }
            exit (Start-Mining @() $true)
        }
        'logs' { exit (Inner-Run @('logs')) }
        'stop' { exit (Inner-Run @('stop')) }
        'status' {
            $r = Inner-Read @('status')
            $r | Where-Object { $_ -notlike 'TNM_*' } | ForEach-Object { Say $_ }
            Say ((T 'version') + (Tnm-Value $r 'TNM_VERSION'))
            if ((Tnm-Value $r 'TNM_RUNNING') -eq 'yes') { Say (T 'state_on') } else { Say (T 'state_off') }
            exit 0
        }
    }
}

# ---------------------------------------------------------------- auto: already installed -> just mine (fast)
if ($Action -eq 'auto') {
    # Fast path (a few quick wsl calls, no preflight / UAC / sha re-check / prompts / download): the distro is
    # registered (wherever this kit now sits), the miner is installed with its config, and the bundled package is not
    # newer -> just start mining.
    if ((Wsl-Ready) -and (Distro-Exists $Distro)) {
        if (Data-Missing) { Fail ((T 'data_missing') -f (Get-DistroBase)) }
        if ($Script:Legacy) { if (-not (Try-PrepareInner)) { Fail ((T 'legacy_fail') -f $Distro, ((T 'legacy_why_path') -f $InnerWin)) } }
        else { Prepare-Inner }
        $m = Inner-Read @('installed')
        $instVer = Tnm-Value $m 'TNM_INSTALLED_VERSION'
        if ($instVer) { $Script:KnownVer = $instVer }

        $instRev = 1
        [void][int]::TryParse(((Tnm-Value $m 'TNM_INSTALLED_REV') + ''), [ref]$instRev)
        if ($instRev -lt 1) { $instRev = 1 }
        $haveCfg = (Tnm-Value $m 'TNM_HAVE_CONFIG') -eq 'yes'
        $pkg = $Package; if (-not $pkg) { $pkg = Find-BundledPackage }
        $newer = $false
        if ($pkg -and $instVer) {
            $pn = [IO.Path]::GetFileName((($pkg -split '[?#]')[0]))
            if (Pkg-Version $pn) { $newer = ((Compare-Key (Pkg-Version $pn) (Pkg-Rev $pn) $instVer $instRev) -gt 0) }
        }
        if ($instVer -and $haveCfg -and -not $newer) {
            New-DesktopShortcut $true
            if (Is-Running) { Show-AlreadyMining; Say ((T 'inst_running') -f $instVer); exit (Inner-Run @('logs')) }
            Say ((T 'inst_start') -f $instVer)
            exit (Start-Mining @() $false)
        }
    }
    # not installed, config missing, or a newer bundle -> full setup below (an upgrade keeps the saved config, no prompts)
}

# ---------------------------------------------------------------- setup helpers (r3)
# 1 / 2 / '' : the WSL version of a distro, from `wsl -l -v` ("* NAME  STATE  VERSION").
function Distro-WslVersion([string]$name) {
    foreach ($line in (Wsl-Read @('-l', '-v'))) {
        if ($line -match ('(^|[\s*])' + [regex]::Escape($name) + '\s+\S+\s+(\d)\s*$')) { return $Matches[2] }
    }
    return ''
}
# An install found in another distro is upgraded THERE or not at all: when that distro cannot be used, stop and say why.
function Legacy-Ready {
    $null = Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'true') 180
    if ($Script:Rc -ne 0) { Fail ((T 'legacy_fail') -f $Distro, (T 'legacy_why_start')) }
    if ((Distro-WslVersion $Distro) -eq '1') { Fail ((T 'legacy_fail') -f $Distro, ((T 'legacy_why_wsl1') -f $Distro)) }
    if (-not (Try-PrepareInner)) { Fail ((T 'legacy_fail') -f $Distro, ((T 'legacy_why_path') -f $InnerWin)) }
}
# The Ubuntu 24.04 WSL image of the mirror fallback, pinned: Ubuntu's own file ubuntu-24.04.5-wsl-amd64.wsl (the last
# 24.04 point release; the mirrors keep the final point release of an LTS, e.g. 22.04.5), byte-identical on the three
# mirrors and on releases.ubuntu.com (checked 2026-10-28: 388975696 bytes, the sha256 below, a gzip tar = what
# `wsl --import` reads). Never used without that size and sha256. TNM_TEST_UBUNTU_* replace it in the tests only.
$Script:UbuntuName = 'ubuntu-24.04.5-wsl-amd64.wsl'
$Script:UbuntuBytes = 388975696
$Script:UbuntuSha = 'bb415d824822c4b878125729af451a5d18fb13d1cf5cbed9a7393ad64ac6039e'
$Script:UbuntuUrls = @(
    'https://mirrors.tuna.tsinghua.edu.cn/ubuntu-releases/24.04/ubuntu-24.04.5-wsl-amd64.wsl',
    'https://mirrors.ustc.edu.cn/ubuntu-releases/24.04/ubuntu-24.04.5-wsl-amd64.wsl',
    'https://mirrors.aliyun.com/ubuntu-releases/24.04/ubuntu-24.04.5-wsl-amd64.wsl'
)
if ($env:TNM_TEST_UBUNTU_URLS) {
    $Script:UbuntuUrls = @($env:TNM_TEST_UBUNTU_URLS -split '\|' | Where-Object { $_ })
    $Script:UbuntuBytes = [int64]$env:TNM_TEST_UBUNTU_BYTES
    $Script:UbuntuSha = $env:TNM_TEST_UBUNTU_SHA
}
# URL -> file with a percent line; '' when it worked, else the reason.
function Download-File([string]$url, [string]$out) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
    $resp = $null; $in = $null; $fs = $null
    try {
        $req = [Net.WebRequest]::Create($url)
        $req.Timeout = 30000
        try { $req.ReadWriteTimeout = 120000 } catch { }
        try { if ($req.Proxy) { $req.Proxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials } } catch { }   # an authenticating proxy
        $resp = $req.GetResponse()
        $total = [int64]$resp.ContentLength
        if ($total -le 0) { $total = $Script:UbuntuBytes }
        $in = $resp.GetResponseStream()
        $fs = [IO.File]::Create($out)
        $buf = New-Object byte[] 1048576
        $done = 0L
        $last = -1
        while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
            $fs.Write($buf, 0, $n)
            $done += $n
            $pct = [int][math]::Floor(100.0 * $done / [math]::Max($total, 1))
            if ($pct -ne $last) {
                $last = $pct
                Write-Host -NoNewline ("`r" + ((T 'mirror_progress') -f $pct, [math]::Floor($done / 1MB), [math]::Floor($total / 1MB)))
            }
        }
        Write-Host ''
        return ''
    } catch {
        Write-Host ''
        $m = ($_.Exception.Message -replace '\s+', ' ').Trim()
        if (-not $m) { $m = 'download failed' }
        return $m
    } finally {
        foreach ($x in @($fs, $in, $resp)) { if ($x) { try { $x.Close() } catch { } } }
    }
}
# A data folder we made that holds nothing but our marker is removed again (a stopped step 3 leaves nothing behind).
function Remove-OurEmptyData([string]$dir) {
    if (-not $dir -or -not (Test-Path -LiteralPath $dir)) { return }
    $items = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue)
    if ($items.Count -eq 1 -and $items[0].Name -eq $DataMarker) { Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue }
}
# `wsl --install` hit a network error (GitHub / Microsoft unreachable): the pinned image from a mirror, then
# `wsl --import $Distro <dir> <file> --version 2`. Everything later runs as root (-u root): no first-run user needed.
function Import-FromMirror([string]$dir) {
    Write-Host ''
    Write-Host (T 'net_stopped') -ForegroundColor Yellow
    Say ((T 'net_next') -f $Script:UbuntuName, [math]::Round($Script:UbuntuBytes / 1MB))
    Ensure-LocalBase
    $dl = Join-Path $LocalBase 'ubuntu'
    New-Item -ItemType Directory -Force -Path $dl | Out-Null
    $file = Join-Path $dl ($Script:UbuntuName -replace '\.wsl$', '.tar.gz')
    $ok = $false
    if (Test-Path -LiteralPath $file) {
        if ((Get-Item -LiteralPath $file).Length -eq $Script:UbuntuBytes -and
            (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash.ToLower() -eq $Script:UbuntuSha) {
            $ok = $true
            Say ((T 'mirror_cached') -f $file)
        } else { Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue }
    }
    $why = @()
    foreach ($u in $Script:UbuntuUrls) {
        if ($ok) { break }
        $h = $u
        try { $h = ([uri]$u).Host; if (-not $h) { $h = $u } } catch { }
        Say ((T 'mirror_try') -f $u)
        $part = $file + '.part'
        $err = Download-File $u $part
        if (-not $err) {
            $len = (Get-Item -LiteralPath $part).Length
            if ($len -ne $Script:UbuntuBytes) { $err = (T 'mirror_size_bad') -f $len, $Script:UbuntuBytes }
            elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $part).Hash.ToLower() -ne $Script:UbuntuSha) { $err = (T 'mirror_sha_bad') }
        }
        if ($err) {
            Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
            Say ((T 'mirror_why') -f $err)
            $why += ($h + ': ' + $err)
            continue
        }
        Move-Item -LiteralPath $part -Destination $file -Force
        $ok = $true
    }
    if (-not $ok) { Remove-OurEmptyData $dir; Fail ((T 'mirror_fail') -f ($why -join '; ')) }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    [IO.File]::WriteAllText((Join-Path $dir $DataMarker), "TheNewMiner: the disk of its WSL distribution. Remove it with TheNewMiner.bat uninstall.`r`n")
    if (-not (Protect-Dir $dir)) { Warn ((T 'acl_warn') -f $dir) }
    Say ((T 'mirror_ok') -f $Script:UbuntuSha.Substring(0, 16), $Distro)
    [void](Wsl-RunCapture @('--import', $Distro, $dir, $file, '--version', '2'))
    if (-not (Distro-Exists $Distro)) {
        if ((Install-Problem $Script:CapText) -eq 'virt') { Fail ((T 'distro_virt') -f $Distro) }
        if ($enabledNow) { Exit-Reboot (T 'reboot_again') }   # WSL was turned on just now: it may need the restart first
        Fail (T 'import_fail')                       # the verified image stays for the next try

    }
    Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
}

# ---------------------------------------------------------------- setup
$Script:Plan.Add('windows', 0.2)
$Script:Plan.Add('wsl', 3)
$Script:Plan.Add('ubuntu', 6)
$Script:Plan.Add('inside', 2)
$Script:Plan.Add('package', 1)
$Script:Plan.Add('settings', 1)
$Script:Plan.Add('first', 20)
Say (T 'title')
Say (T 'intro')

# 1. The pool account FIRST (v0.1.47 r2: nothing long has run yet), then Windows and the NVIDIA driver
Step 1 (T 'step1')
if ($Script:Legacy) {
    $lv = (T 'ver_unknown')
    if ($Script:Legacy.Version) { $lv = 'v' + $Script:Legacy.Version }
    Write-Host ((T 'legacy_found') -f $Distro, $lv) -ForegroundColor Green
    Say ((T 'legacy_where') -f $Script:Legacy.Dir)
    Legacy-Ready
}
Get-Account
if (-not [Environment]::Is64BitOperatingSystem) { Fail (T 'need64') }
$build = [Environment]::OSVersion.Version.Build
if ($env:TNM_TEST_WINBUILD) { $build = [int]$env:TNM_TEST_WINBUILD }   # tools/test_windows_wsl.py (pwsh on Linux)
if ($build -lt $MinBuild) { Fail ((T 'old_win') -f $build) }
$smi = $null
$c = Get-Command 'nvidia-smi.exe' -ErrorAction SilentlyContinue
if ($c) { $smi = $c.Source }
foreach ($p in @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe")) {
    if (-not $smi -and (Test-Path -LiteralPath $p)) { $smi = $p }
}
if (-not $smi) { Open-DriverPage; Fail (T 'no_driver') }
$rows = @(& $smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv,noheader,nounits 2>$null | Where-Object { $_ -match ',' })
if ($LASTEXITCODE -ne 0 -or $rows.Count -eq 0) { Fail (T 'smi_broken') }
$drv = ''
$bigGpu = $false
$smallest = ''
foreach ($r in $rows) {
    $f = @($r.Split(',') | ForEach-Object { $_.Trim() })
    if ($f.Count -lt 4) { continue }
    $drv = $f[1]
    Say ((T 'gpu_line') -f $f[0], $f[2], $f[1])
    $total = 0; $used = 0
    [void][int]::TryParse(($f[2] -replace '[^0-9]', ''), [ref]$total)
    [void][int]::TryParse(($f[3] -replace '[^0-9]', ''), [ref]$used)
    # a "10 GB" card reports 10240 MiB (some boards a little less): 9728 MiB and up counts as 10 GB
    if ($total -ge 9728) { $bigGpu = $true } else { $smallest = $f[0] + ', ' + $total + ' MiB' }
    if ($total -ge 9728 -and $total -le 12288 -and ($total - $used) -lt 9472) {
        Warn ((T 'low_vram') -f ($total - $used))
    }
}
if (-not $bigGpu) { Fail ((T 'vram_small') -f $smallest) }
$major = 0
[void][int]::TryParse((($drv -replace '[^0-9.]', '').Split('.')[0]), [ref]$major)
if ($major -lt $MinDriver) { Open-DriverPage; Fail ((T 'old_driver') -f $drv, $MinDriver) }
$wslReadyAtStart = Wsl-Ready
$registered = $wslReadyAtStart -and (Distro-Exists $Distro)
$sysRoot = Drive-Root $env:LOCALAPPDATA
$sysFreeGb = Free-Gb $env:LOCALAPPDATA
$ramGb = 0
try { $ramGb = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch { }
Say ((T 'sys_line') -f $build, $ramGb, $sysRoot, $sysFreeGb)
if (-not $wslReadyAtStart -and $sysFreeGb -ge 0 -and $sysFreeGb -lt 1) { Fail ((T 'low_sys') -f $sysRoot, $sysFreeGb) }
# A first install needs ~20 GB on its data drive; an existing distro is checked later for what the upgrade needs.
$Script:Pick = $null
function Get-Pick {
    if ($DataDir) { return [pscustomobject]@{ Path = (Fit-DataDir $DataDir); FreeGb = (Free-Gb $DataDir); Why = '' } }
    return (Choose-DataDir $KitRoot $NeedFreshGb)
}
if (-not $registered) {
    $Script:Pick = Get-Pick
    if ($Script:Pick.FreeGb -ge 0 -and $Script:Pick.FreeGb -lt $NeedFreshGb -and ($Yes -or $DataDir)) {
        Fail ((T 'low_data') -f $Script:Pick.Path, $Script:Pick.FreeGb, $NeedFreshGb)
    }
}
if ($ramGb -gt 0 -and $ramGb -lt 12) { Warn ((T 'low_ram') -f $ramGb) }
try {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $cs = Get-CimInstance Win32_ComputerSystem
    if (-not ($cpu.VirtualizationFirmwareEnabled -or $cs.HypervisorPresent)) {
        Warn (T 'no_virt')
    }
} catch { }

# 2. WSL2
if ($wslReadyAtStart) { $Script:Plan['wsl'] = 0.2 }
Step 2 (T 'step2')
$enabledNow = $false
Ensure-LocalBase
$rebootMark = Join-Path $LocalBase 'wsl-reboot.txt'
$bootTime = ''
try { $bootTime = [string](Get-CimInstance Win32_OperatingSystem).LastBootUpTime } catch { }
if (-not (Wsl-Ready)) {
    Say (T 'wsl_enabling')
    # (r3 review: never a variable named "rc" at script scope - it IS Script:Rc, which every Wsl-Read overwrites)
    $enRc = Wsl-Elevated @('--install', '--no-distribution')
    if ($enRc -eq -1) { Fail (T 'wsl_need_admin') }
    if (-not (Wsl-Ready) -and @(0, 3010, 1641) -notcontains $enRc) { $enRc = Wsl-Elevated @('--update') }
    $enabledNow = $true
    if (-not (Wsl-Ready)) {
        if (@(0, 3010, 1641) -notcontains $enRc) { Fail ((T 'wsl_fail') -f $enRc) }
        if ((Test-Path -LiteralPath $rebootMark) -and ([IO.File]::ReadAllText($rebootMark).Trim() -ne $bootTime)) {
            Fail (T 'wsl_after_reboot')
        }
        [IO.File]::WriteAllText($rebootMark, $bootTime)
        Exit-Reboot (T 'need_reboot')
    }
}
if (Test-Path -LiteralPath $rebootMark) { Remove-Item -LiteralPath $rebootMark -Force }
# WSL older than 2.4.4 lacks `--install --name / --location`: update it first, then look at the version again. When
# the update is impossible (offline, blocked by policy, UAC declined) setup goes on with what this WSL can do (step 3).
function Wsl-Version {
    $v = (@(Wsl-Read @('--version')) | Select-Object -First 1) + ''
    if ($v -match '(\d+)\.(\d+)\.(\d+)') { return [version]$Matches[0] }
    return $null
}
$wv = Wsl-Version
if ($wv) { Say ('  WSL ' + $wv) }
if (-not $wv -or $wv -lt [version]'2.4.4') {
    Say (T 'wsl_updating')
    $updRc = Wsl-Elevated @('--update')
    $wv = Wsl-Version
    if ($wv) { Say ('  WSL ' + $wv) }
    if (-not $wv -or $wv -lt [version]'2.4.4') {
        if ($updRc -eq -1) { Warn (T 'wsl_update_admin') } else { Warn ((T 'wsl_update_failed') -f $updRc) }
    }
}
$null = Wsl-Read @('--set-default-version', '2')

# 3. The dedicated distro and its data folder
$registered = Distro-Exists $Distro
if ($registered -and (Data-Missing) -and ($Script:Legacy -or $Distro -ne 'TheNewMiner')) {
    Fail ((T 'legacy_fail') -f $Distro, ((T 'legacy_why_data') -f (Get-DistroBase)))   # never unregister a user's distro
}
if ($registered -and (Data-Missing)) {
    # its disk is gone (drive removed, folder deleted): recreate only when the user says so
    $a = 'y'
    if (-not $Yes) { $a = (Read-Line ((T 'data_recreate_q') -f (Get-DistroBase))).Trim() }
    if ($a -notmatch '^[yY]') { Say (T 'cancelled'); exit 1 }
    [void](Wsl-Run @('--unregister', $Distro))
    $registered = Distro-Exists $Distro
    if (-not $Script:Pick) { $Script:Pick = Get-Pick }
}
if ($registered) { $Script:Plan['ubuntu'] = 0.3 }
if ($registered) { Step 3 ((T 'step3_have') -f $Distro) } else { Step 3 ((T 'step3') -f $Distro) }
$firstInstall = $false
if ($registered) {
    if ($DataDir) { Warn ((T 'datadir_ignored') -f $Distro, (Get-DistroBase)) }
} else {
    if (-not $Script:Pick) { $Script:Pick = Get-Pick }
    $loc = Location-Support
    $target = $Script:Pick.Path
    if ($Script:Pick.Why -and (Drive-Root $KitRoot)) { Say ((T 'data_not_kitdrive') -f (Drive-Root $KitRoot), (Why-Text $Script:Pick.Why)) }
    # Shown once, with its free space; Enter accepts, or another folder is typed (quotes stripped, space re-checked).
    for ($try = 0; $try -lt 6 -and $loc -ne 'no'; $try++) {
        $free = Free-Gb $target
        Say ((T 'data_where') -f $target, $free, $NeedFreshGb)
        if ($Yes -or $DataDir -or $Script:Asked -eq 'dialog') { break }     # r2: no console question after the dialog
        $ans = Strip-Quotes (Read-Line (T 'data_prompt'))
        if (-not $ans) {
            if ($free -lt 0 -or $free -ge $NeedFreshGb) { break }
            Warn ((T 'data_low_try') -f $target, $free, $NeedFreshGb)
            continue
        }
        if (-not (Is-FullPath $ans)) { Warn (T 'data_bad_path'); continue }
        $target = Fit-DataDir $ans
    }
    $free = Free-Gb $target
    if ($loc -ne 'no' -and $free -ge 0 -and $free -lt $NeedFreshGb) { Fail ((T 'low_data') -f $target, $free, $NeedFreshGb) }
    if ($loc -eq 'no') {
        # an old wsl.exe without --location: the distro goes to WSL's default place on the system drive
        Say (T 'no_location')
        if ($sysFreeGb -ge 0 -and $sysFreeGb -lt $NeedFreshGb) { Fail ((T 'low_sys_data') -f $sysRoot, $sysFreeGb, $NeedFreshGb) }
        $instRc = Wsl-RunCapture @('--install', $BaseDistro, '--name', $Distro, '--no-launch')
        if ((Distro-Exists $Distro) -and $Script:HelpText -match '--move') {
            # this WSL can move a distro afterwards: put it into the chosen data folder after all
            New-Item -ItemType Directory -Force -Path $target | Out-Null
            [IO.File]::WriteAllText((Join-Path $target $DataMarker), "TheNewMiner: the disk of its WSL distribution. Remove it with TheNewMiner.bat uninstall.`r`n")
            if (-not (Protect-Dir $target)) { Warn ((T 'acl_warn') -f $target) }
            Say ((T 'moving_distro') -f $target)
            $mrc = Wsl-Run @('--manage', $Distro, '--move', $target)
            if ($mrc -ne 0) { Warn ((T 'move_failed') -f $mrc) }
        }
    } else {
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        [IO.File]::WriteAllText((Join-Path $target $DataMarker), "TheNewMiner: the disk of its WSL distribution. Remove it with TheNewMiner.bat uninstall.`r`n")
        if (-not (Protect-Dir $target)) { Warn ((T 'acl_warn') -f $target) }
        $instRc = Wsl-RunCapture @('--install', $BaseDistro, '--name', $Distro, '--no-launch', '--location', $target)
    }
    if (-not (Distro-Exists $Distro)) {
        # r3: `wsl --install` exits 0 even when its download failed: its own words decide (never its exit code)
        $kind = Install-Problem $Script:CapText
        if ($enabledNow -and $kind -ne 'network') { Exit-Reboot (T 'reboot_again') }
        if ($kind -eq 'network') { Import-FromMirror $target }
        elseif ($kind -eq 'virt') { Remove-OurEmptyData $target; Fail ((T 'distro_virt') -f $Distro) }
        elseif ($loc -eq 'no') { Fail ((T 'distro_fail_old') -f $Distro) }
        else { Remove-OurEmptyData $target; Fail ((T 'distro_fail') -f $Distro) }
    }
    $firstInstall = $true
    Save-Where '/root/thenewminer'
}
$probe = @(Wsl-Read @('-d', $Distro, '-u', 'root', '-e', 'true'))
if ($Script:Rc -ne 0) {
    if ($enabledNow) { Exit-Reboot (T 'reboot_again') }
    if ((Install-Problem (($probe -join "`n") + "`n" + $Script:WslErr)) -eq 'virt') { Fail ((T 'distro_virt') -f $Distro) }
    Fail ((T 'distro_nostart') -f $Distro)
}

# .wslconfig: memory and swap for the model, written only where the user set nothing and only when TheNewMiner is the
# only distro (the file is global: other distros' memory is never changed). The model (8.1 GiB) is read once through
# the page cache into the GPU; the miner then needs about 1-2 GB. Default WSL memory is half the RAM. r3: written after
# step 3, so a step 3 that stops has changed nothing.
$cfg = Join-Path $env:USERPROFILE '.wslconfig'
$cfgChanged = $false
$otherDistros = @(All-Distros | Where-Object { $_ -ne $Distro })
if ($otherDistros.Count -gt 0) {
    Say ((T 'wslconfig_skip') -f $cfg)
} else {
    $cfgText = ''
    if (Test-Path -LiteralPath $cfg) { $cfgText = [IO.File]::ReadAllText($cfg) }
    $add = @()
    if ($cfgText -notmatch '(?im)^\s*memory\s*=' -and $ramGb -ge 10 -and $ramGb -lt 12) { $add += 'memory=6GB' }
    if ($cfgText -notmatch '(?im)^\s*swap\s*=') { $add += 'swap=8GB' }
    if ($add.Count -gt 0) {
        if ($cfgText) { Copy-Item -LiteralPath $cfg -Destination ($cfg + '.bak-thenewminer') -Force }
        $lines = New-Object System.Collections.Generic.List[string]
        foreach ($ln in ($cfgText -split "`r?`n")) { $lines.Add($ln) }
        $at = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*\[wsl2\]\s*$') { $at = $i; break } }
        if ($at -ge 0) {
            $lines.InsertRange($at + 1, [string[]]$add)
        } else {
            if ($cfgText.Trim()) { $lines.Add('') }
            $lines.Add('[wsl2]')
            $lines.AddRange([string[]]$add)
        }
        $new = ($lines -join "`r`n").Trim() + "`r`n"
        [IO.File]::WriteAllText($cfg, $new, (New-Object System.Text.UTF8Encoding($false)))
        $cfgChanged = $true
        Say ((T 'wslconfig') -f $cfg, ($add -join ', '))
    }
}
if ($cfgChanged) {
    # memory / swap apply from WSL's next start. wsl --shutdown stops EVERY distro, so it only runs on the first
    # install and only when the user says yes - never silently, not even with -Yes.
    $go = $false
    if ($firstInstall -and $Script:Asked -ne 'dialog') {               # r2: no console question after the dialog
        $running = @(Wsl-Read @('-l', '--running', '-q') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        $list = $running -join ', '
        if (-not $list) { $list = (T 'none_word') }
        $a = (Read-Line ((T 'restart_wsl_q') -f $list)).Trim()
        $go = ($a -match '^[yY]')
    }
    if ($go) { Say (T 'wsl_restarting'); $null = Wsl-Read @('--shutdown') }
    else { Say (T 'wsl_later') }
}
if ((Distro-WslVersion $Distro) -eq '1') {
    if ($Script:Legacy) { Fail ((T 'legacy_fail') -f $Distro, ((T 'legacy_why_wsl1') -f $Distro)) }   # never convert the user's own distro
    Say ((T 'wsl1_convert') -f $Distro)
    [void](Wsl-Run @('--set-version', $Distro, '2'))
}

# 4. Inside WSL: the GPU, the packages the installer needs, the clock
Step 4 (T 'step4')
Prepare-Inner
# v0.1.47 r2: DNS inside WSL. An outside tester's WSL could not resolve any name, so the package install, the pool and
# the model download all failed late. Checked here; nothing is changed automatically: the fix is printed.
$dnsBad = @(Inner-Read @('dns', 'tsc-wss.the-new.win', 'modelscope.cn') | Where-Object { $_ -like 'TNM_DNS_FAIL=*' } | ForEach-Object { $_.Substring(13) })
$haveModel = (Tnm-Value (Inner-Read @('installed')) 'TNM_HAVE_MODEL') -eq 'yes'
$byIp = [bool]($Proxy -match '^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?$')        # -Proxy IP: the pool is reached by its address
$dnsNeeded = @($dnsBad | Where-Object { ($_ -eq 'modelscope.cn' -and -not $haveModel) -or ($_ -ne 'modelscope.cn' -and -not $byIp) })
if ($dnsNeeded.Count -gt 0) {
    $cfg = Join-Path $env:USERPROFILE '.wslconfig'
    Write-Host ''
    Write-Host ((T 'dns_manual1') -f ($dnsNeeded -join ', ')) -ForegroundColor Yellow
    Write-Host ((T 'dns_manual2') -f $cfg) -ForegroundColor Yellow
    Write-Host '       [wsl2]' -ForegroundColor White
    Write-Host '       dnsTunneling=true' -ForegroundColor White
    Write-Host (T 'dns_manual3') -ForegroundColor Yellow
    Write-Host (T 'dns_manual4') -ForegroundColor Yellow
    Fail ((T 'dns_fail') -f ($dnsNeeded -join ', '), $cfg)
}
if ($dnsBad.Count -gt 0) { Warn ((T 'dns_warn') -f ($dnsBad -join ', ')) }
$chkWin = Join-Path (Split-Path $InnerWin) 'check.txt'
if (Test-Path -LiteralPath $chkWin) { Remove-Item -LiteralPath $chkWin -Force }
$chkLinux = ($Script:InnerLinux -replace '/[^/]*$', '') + '/check.txt'
[void](Inner-Run @('check', $chkLinux))             # live output: the package installation shows its progress
$chk = @()
if (Test-Path -LiteralPath $chkWin) { $chk = @(Get-Content -LiteralPath $chkWin) }
$why = Tnm-Value $chk 'TNM_FAIL'
if ($why -eq 'nvidia-smi' -or $why -eq 'libcuda') { Fail (T 'no_gpu_wsl') }
if ($why -eq 'wsl1') { Fail ((T 'still_wsl1') -f $Distro) }
if ($why) { Fail ((T 'check_fail') -f $why) }
if ((Tnm-Value $chk 'TNM_OK') -ne 'check') { Fail (T 'check_incomplete') }
if (Tnm-Value $chk 'TNM_WARN') { Warn (T 'linux_driver_warn') }
Check-Clock

# 5. The miner (our Linux package): the one bundled in files\ (its .sha256 is mandatory), or -Package with a sha256.
Step 5 (T 'step5')
$m = Inner-Read @('installed')
$instVer = Tnm-Value $m 'TNM_INSTALLED_VERSION'
$instRev = 1
[void][int]::TryParse(((Tnm-Value $m 'TNM_INSTALLED_REV') + ''), [ref]$instRev)
if ($instRev -lt 1) { $instRev = 1 }
$instSha = (Tnm-Value $m 'TNM_INSTALLED_SHA') + ''
$haveModel = (Tnm-Value $m 'TNM_HAVE_MODEL') -eq 'yes'
if ($instVer) { $Script:KnownVer = $instVer }
# r3: an earlier install's model (its own store, ~/.thenewminer/models of root or a user, an install's .miner) is
# proven by its size and sha256 and linked into the store: an upgrade never downloads the 8.1 GiB again.
if ((Tnm-Value $m 'TNM_STORE_MODEL') -ne 'yes' -and ($instVer -or $Script:Legacy)) {
    [void](Inner-Run @('modelreuse'))
    $haveModel = (Tnm-Value (Inner-Read @('installed')) 'TNM_HAVE_MODEL') -eq 'yes'
}

$src = $Package
$want = ''
if ($src) {
    $want = $Sha256
} else {
    $src = Find-BundledPackage
    if (-not $src) { Fail (T 'no_pkg') }
    $want = Local-Sha $src
    if (-not $want) { Fail ((T 'bundle_no_sha') -f $src) }
    Say ((T 'use_local') + $src)
}
$name = [IO.Path]::GetFileName((($src -split '[?#]')[0]))
if ($name -notmatch $PkgRe) { Fail ((T 'bad_name') -f $name) }
$skipPkg = $false
if (-not $Package -and $instVer) {
    $cmp = Compare-Key (Pkg-Version $name) (Pkg-Rev $name) $instVer $instRev
    if ($cmp -lt 0) { Say ((T 'pkg_keep_newer') -f $instVer, (Pkg-Version $name)); $skipPkg = $true }
    elseif ($cmp -eq 0 -and $instSha -and $instSha -eq $want.ToLower()) { Say ((T 'pkg_same') -f $instVer); $skipPkg = $true }
}
if (-not $skipPkg) {
    Ensure-LocalBase
    New-Item -ItemType Directory -Force -Path $StageDir | Out-Null
    $dest = Join-Path $StageDir $name
    $isUrl = $src -match '^https?://'
    if ($isUrl) {
        Say ((T 'downloading') -f $src)
        & curl.exe -fL --retry 3 --connect-timeout 30 -o ($dest + '.part') $src
        if ($LASTEXITCODE -ne 0) { Fail ((T 'dl_fail') -f $src, $LASTEXITCODE) }
        Move-Item -LiteralPath ($dest + '.part') -Destination $dest -Force
        if (-not $want) {
            $t = & curl.exe -fsL --retry 3 --connect-timeout 30 ($src + '.sha256')
            if ($LASTEXITCODE -eq 0 -and $t) { $want = ((($t | Select-Object -First 1) + '').Trim() -split '\s+')[0] }
        }
        if ($want -notmatch '^[0-9a-fA-F]{64}$') { Remove-Item -LiteralPath $dest -Force; Fail (T 'url_no_sha') }
    } else {
        if (-not (Test-Path -LiteralPath $src)) { Fail ((T 'not_found') -f $src) }
        if (-not $want) { $want = Local-Sha $src }
        if ($want -notmatch '^[0-9a-fA-F]{64}$') { Fail ((T 'pkg_no_sha') -f $name) }
        # room: the staging copy here, then (inside the distro's growing disk) the copy, the unpacked files, the model
        $size = (Get-Item -LiteralPath $src).Length
        $stageNeed = [math]::Ceiling($size / 1GB + 0.5)
        if ($sysFreeGb -ge 0 -and $sysFreeGb -lt $stageNeed) { Fail ((T 'low_upgrade') -f $sysRoot, $sysFreeGb, $stageNeed) }
        Copy-Item -LiteralPath $src -Destination $dest -Force
    }
    if (-not $firstInstall) {
        $bp = Get-DistroBase
        $dataPath = $bp
        if (-not $dataPath) { $dataPath = $env:LOCALAPPDATA }
        $need = [math]::Ceiling(6 * (Get-Item -LiteralPath $dest).Length / 1GB + 1)
        if (-not $haveModel) { $need += 10 }
        $dfree = Free-Gb $dataPath
        if ($dfree -ge 0 -and $dfree -lt $need) { Remove-Item -LiteralPath $dest -Force; Fail ((T 'low_upgrade') -f $dataPath, $dfree, $need) }
    }
    # the staged copy is checked here, and again inside WSL right before it is unpacked
    $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $dest).Hash.ToLower()
    if ($got -ne $want.ToLower()) {
        Remove-Item -LiteralPath $dest -Force
        Fail ((T 'sha_bad') -f $got, $want.ToLower())
    }
    Say ((T 'sha_ok') -f $got)
    if (Is-Running) {
        Say (T 'stopping_old')
        [void](Inner-Run @('stop'))
    }
    $destLinux = Linux-Path $dest
    if (-not $destLinux) { Fail ((T 'no_wslpath') -f $Distro, $dest) }
    $dirName = $name -replace '\.tar\.xz$', ''
    $u = Inner-Read @('unpack', $destLinux, $dirName, $got)
    Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue
    $u | Where-Object { $_ -notlike 'TNM_*' } | ForEach-Object { Say ('  ' + $_) }
    $why = Tnm-Value $u 'TNM_FAIL'
    if ($why) { Fail ((T 'unpack_fail') -f $why) }
    Say ((T 'installed_at') + (Tnm-Value $u 'TNM_DIR'))
    if ($env:ProgramData) {
        $old = Join-Path $env:ProgramData 'TheNewMiner\pkg'      # kits before r3 staged the package in this shared folder
        if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# 6. The account from step 1 (or the install's own settings) and the proxy
Step 6 (T 'step6')
$frontArgs = @()
$haveSaved = (-not $Script:Acct)
$pxRe = '^(none|direct|off|\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?|socks5://\S+|http://\S+)$'
if ($haveSaved) {
    if ($PSBoundParameters.ContainsKey('Worker') -and $Worker) {
        if (-not (Worker-Ok $Worker)) { Fail (T 'bad_worker') }
        $frontArgs += @('-w', $Worker)
    }
    if ($PSBoundParameters.ContainsKey('Proxy')) {
        $px = $Proxy
        if (-not $px) { $px = 'none' }
        if ($px -notmatch $pxRe) { Fail ((T 'bad_proxy') -f $px) }
        $frontArgs += @('--proxy', $px)
    }
} else {
    # The pool is preconfigured; ordinary miners connect directly. Proxy is an advanced -Proxy option only.
    $px = $Proxy
    if (-not $px) { $px = 'none' }
    if ($px -notmatch $pxRe) { Fail ((T 'bad_proxy') -f $px) }
    # the account reaches the miner through the environment (WSLENV), never argv
    $env:TNM_WALLET = $Script:Acct.Wallet
    $env:TNM_PASSWORD = $Script:Acct.Password
    $wslenv = 'TNM_WALLET/u:TNM_PASSWORD/u'
    if ($env:WSLENV) { $wslenv = $wslenv + ':' + $env:WSLENV }
    $env:WSLENV = $wslenv
    $frontArgs = @('-w', $Script:Acct.Worker, '--proxy', $px)
    if ($px -eq 'none') { Say (T 'direct') } else { Say (T 'via_proxy') }
}

New-DesktopShortcut $false
# 7. First start: the miner installs itself (model download, GPU test, calibration), then mines
if ($NoStart) {
    Say ''
    Write-Host (T 'installed_nostart') -ForegroundColor Green
    if (-not $haveSaved) { Warn (T 'not_saved') }
    Show-Help
    exit 0
}
Step 7 (T 'step7')
Say (T 'dl_time')
Show-Help
Say ''
# v0.1.45 (audit bug B): new settings (wallet, password, worker or proxy) cannot reach a miner that is already
# running - its front holds the package lock and the new front would stop at it before saving anything. Stop it first.
if (((-not $haveSaved) -or $frontArgs.Count -gt 0) -and (Is-Running)) {
    Say (T 'stopping_old')
    [void](Inner-Run @('stop'))
}
$runRc = Start-Mining $frontArgs ([bool]$Background)
$env:TNM_WALLET = $null
$env:TNM_PASSWORD = $null
exit $runRc
