#!/bin/bash
# TheNewMiner on Windows through WSL2: the part that runs INSIDE the dedicated "TheNewMiner" WSL distribution, as root.
# files\thenewminer-wsl.ps1 (started by TheNewMiner.bat) copies this file to %LOCALAPPDATA%\TheNewMiner\wsl\ (a per-user
# folder only that user, SYSTEM and Administrators can write) with LF line endings and runs it with
# `wsl -d TheNewMiner -u root -e /bin/bash <this> COMMAND ...`. The miner itself is the unchanged Linux package, unpacked
# into ~/thenewminer/<package name> (WSL's own ext4 disk, never /mnt/c); ~/thenewminer/current points at the one in use,
# and the model lives in ~/thenewminer/models for every version (TNP_MODEL_DIR). Machine-readable lines start with
# "TNM_" (the PowerShell side reads them); the rest is for people.
#   check [FILE]          WSL2 kernel, nvidia-smi (linked from /usr/lib/wsl/lib when it is not on the PATH), libcuda,
#                         no Linux NVIDIA driver inside WSL, the packages the installer needs, memory and disk
#   unpack SRC NAME SHA   SRC (a .tar.xz the Windows side verified) copied into WSL, its sha256 checked AGAIN there
#                         (refused without one), unpacked into ~/thenewminer/NAME; settings carried over from the install
#                         in use; the model moved to ~/thenewminer/models; older versions pruned (the new one and the
#                         previous one are kept); ~/thenewminer/current -> it; writes the install marker
#   installed             the kit's marker (<install>/.tnm-kit): version, revision, bundle sha256, config / model
#                         present (fast routing)
#   settings              the remembered settings of the install in use (wallet shortened, worker, proxy)
#   dns HOST...           TNM_DNS_OK=HOST / TNM_DNS_FAIL=HOST: getent ahosts (what the miner resolves with) per HOST
#   running               yes / no: a thenewminer of the install in use runs (by cwd, or a miner by process name)
#   logmark               the install in use and the line count of its log (operator test)
#   run [ARGS]            ./thenewminer ARGS in the install in use (exec: Ctrl+C and --stop reach it directly)
#   logs | stop           ./thenewminer --logs | --stop there
#   status                running or not, the version, the last rate lines
#   modelreuse            r3: an earlier install's model (by its exact size, then its sha256) linked into the store
# r3: an install that an earlier kit or a hand install made in another distro is used where it is: the Windows side
# passes TNM_WSL_BASE (its kit base, e.g. /home/<user>/thenewminer) and, for an install without ~/thenewminer/current
# (a hand-unpacked package, an older kit layout), TNM_WSL_ADOPT=<its directory>: it then counts as the install in use
# until the first unpack makes current point at the new version (settings carried over from it, the directory kept).
# Test hooks (tools/test_windows_wsl.py): TNM_WSL_BASE (default ~/thenewminer), TNM_WSL_LIB (default /usr/lib/wsl/lib),
# TNM_WSL_KERNEL (default uname -r), TNM_WSL_LINKDIR (default /usr/local/bin), TNM_WSL_PROC (default /proc),
# TNM_WSL_AVAIL_KB (default: df of the base), TNM_WSL_MODEL_SHA / TNM_WSL_MODEL_BYTES (default: the product's model),
# TNM_WSL_ROOTFS (default: none; a prefix for the places modelreuse looks).
set -u
BASE=${TNM_WSL_BASE:-$HOME/thenewminer}
CUR=$BASE/current
LIB=${TNM_WSL_LIB:-/usr/lib/wsl/lib}
PROC=${TNM_WSL_PROC:-/proc}
# One model store for every version (the miner's TNP_MODEL_DIR): an upgrade never downloads the 8.1 GiB again.
STORE=$BASE/models
MODEL_NAME=Qwen3-8B-Q8_0-full-v2.gguf
# the product's model identity (ops/minerctl.py MODEL_SHA / MODEL_BYTES): an earlier install's file is reused only
# when it is exactly this
MODEL_SHA=${TNM_WSL_MODEL_SHA:-408b955510e196121c1c375201744783b5c9a43c7956d73fc78df54c66e883d6}
MODEL_BYTES=${TNM_WSL_MODEL_BYTES:-8709518112}

export TNP_MODEL_DIR=$STORE
say() { printf '%s\n' "$*"; }
OUT=""                                   # check FILE: its TNM_ lines go to FILE instead (the Windows side reads them)
kv() { if [ -n "$OUT" ]; then printf '%s\n' "$*" >> "$OUT"; else say "$*"; fi; }
strip() { sed 's/\x1b\[[0-9;]*m//g' "$@"; }

# msg ID [ARG...]: a line for people, in English (v0.1.47 r2: one language). One entry per line -
# tools/test_windows_wsl.py reads this table (every id used, no CJK text). The texts are printf formats (%s only).
msg() {
  _id=$1; shift
  _f=''
  case "$_id" in
    kernel_wsl2) _f='WSL2 kernel %s' ;;
    wsl1) _f='this distro runs as WSL 1 (kernel %s): the GPU needs WSL 2' ;;
    not_wsl_kernel) _f='kernel %s (not a WSL kernel: this helper is meant for WSL2)' ;;
    smi_linked) _f='linked %s -> %s (it was not on the PATH)' ;;
    smi_broken) _f='nvidia-smi does not work inside WSL: update the NVIDIA driver on Windows (580 or newer) and run wsl --shutdown.' ;;
    gpu_in_wsl) _f='GPU in WSL: %s' ;;
    no_libcuda) _f='%s is missing: the Windows NVIDIA driver gives WSL its CUDA there' ;;
    linux_driver) _f='a Linux NVIDIA driver package is installed inside WSL: it hides the GPU of the Windows driver (remove it: apt-get purge "nvidia-*" "libnvidia-*")' ;;
    installing_pkgs) _f='installing the packages the miner needs: %s (about 1-3 minutes)' ;;
    carried) _f='settings carried over from %s' ;;
    models_moved) _f='the model was moved to %s (shared by every version: an upgrade never downloads it again)' ;;
    pruned) _f='removed the old version %s' ;;
    sha_again_bad) _f='the sha256 checked again inside WSL does not match (%s): the package changed on the way and is not used' ;;
    no_space) _f='not enough space on the WSL disk: about %s MB is needed, %s MB is free' ;;
    not_installed) _f='not installed: run TheNewMiner.bat first' ;;
    model_checking) _f='checking the model of the earlier install (sha256 of 8.1 GiB, about a minute): %s' ;;
    model_reused) _f='the model of the earlier install is used (not downloaded again): %s' ;;
    model_other) _f='not the right model (another sha256): %s' ;;
  esac
  [ -n "$_f" ] || _f=$_id
  # shellcheck disable=SC2059
  printf "$_f\n" "$@"
}

# DIR: the pids of the thenewminer front / miner processes whose working directory is DIR.
pids_in() {
  local d p c
  d=$(readlink -f "$1" 2>/dev/null) || return 0
  [ -n "$d" ] || return 0
  for p in "$PROC"/[0-9]*; do
    [ "$(readlink "$p/cwd" 2>/dev/null)" = "$d" ] || continue
    c=$(tr '\0' '\n' < "$p/cmdline" 2>/dev/null | head -1)
    case "${c##*/}" in thenewminer|thenewminer-miner) echo "${p##*/}" ;; esac
  done
}

installed_dir() {
  if [ -e "$CUR" ]; then readlink -f "$CUR" 2>/dev/null; return 0; fi
  if [ -n "${TNM_WSL_ADOPT:-}" ] && [ -x "$TNM_WSL_ADOPT/thenewminer" ]; then readlink -f "$TNM_WSL_ADOPT"; fi
  return 0
}

# The kit's own install marker: <install>/.tnm-kit. <install>/.miner/installed is the FRONT's marker (its first line is
# the release stamp; ops/install.sh removes and rewrites it) and is never written here. Kits r3 / r4 wrote theirs
# there (version= / revision= / bundle_sha256= lines), so that file is still read as a fallback.
KIT_MARKER=.tnm-kit
kit_value() {   # DIR KEY
  local v=""
  [ -f "$1/$KIT_MARKER" ] && v=$(sed -n "s/^$2=//p" "$1/$KIT_MARKER" | head -1)
  [ -n "$v" ] || { [ -f "$1/.miner/installed" ] && v=$(sed -n "s/^$2=//p" "$1/.miner/installed" | head -1); }
  printf '%s' "$v"
}

# A miner of ours runs: by its process name anywhere (the sealed package runs its front and miner from a RAM folder,
# not from the install folder), like `pgrep -f 'thenew(miner|pool)-miner'`. TNM_WSL_PROC (tests) is scanned the same way.
miner_by_name() {
  local p c
  if [ "$PROC" = /proc ] && command -v pgrep >/dev/null 2>&1; then
    pgrep -f 'thenew(miner|pool)-miner' >/dev/null 2>&1
    return
  fi
  for p in "$PROC"/[0-9]*; do
    c=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null) || continue
    case "$c" in *thenewminer-miner*|*thenewpool-miner*) return 0 ;; esac
  done
  return 1
}
miner_running() { [ -n "$1" ] && [ -n "$(pids_in "$1")" ] && return 0; miner_by_name; }

# The version and the revision in a package / install name: TheNewMiner-v0.1.44-linux-x86_64-sealed-r2 -> 0.1.44, 2
# (no -rN = revision 1).
name_version() { printf '%s' "$1" | sed -n 's/^TheNewMiner-v\([0-9][0-9.]*\)-linux-x86_64.*/\1/p'; }
name_rev() {
  local r
  r=$(printf '%s' "$1" | sed -n 's/.*-r\([0-9][0-9]*\)$/\1/p')
  printf '%s' "${r:-1}"
}

# The model store used to be ~/.thenewminer/models (the miner's default): move what is there into $STORE once (the
# same ext4 disk: a rename, instant) and leave a symlink, so an install whose .miner/model.gguf points at the old
# place still finds it.
# The same for a models directory an earlier kit's install kept in its own .miner (<install>/.miner/models): moved into
# the store, and the directory becomes a symlink to it, so neither that install nor the next version downloads again.
migrate_models() {
  local old s t moved=""
  mkdir -p "$STORE"
  for old in "$HOME/.thenewminer/models" "$BASE"/TheNewMiner-v*-linux-x86_64*/.miner/models; do
    [ -d "$old" ] && [ ! -L "$old" ] || continue
    for s in "$old"/* "$old"/.[!.]*; do
      [ -e "$s" ] || [ -L "$s" ] || continue
      t=$STORE/${s##*/}
      if [ ! -e "$t" ] && [ ! -L "$t" ]; then mv "$s" "$t" && moved=1; fi
    done
    if rmdir "$old" 2>/dev/null; then ln -s "$STORE" "$old"; fi
  done
  [ -z "$moved" ] || msg models_moved "$STORE"
}

# yes when the model is in the store every version uses (TNP_MODEL_DIR): only then is nothing left to reuse.
store_model() {
  local f
  [ -e "$STORE/$MODEL_NAME" ] && return 0
  for f in "$STORE"/*/"$MODEL_NAME"; do [ -e "$f" ] && return 0; done
  return 1
}
# yes when the model is on this disk already (an upgrade then needs no room for it).
have_model() {
  local f
  [ -n "$1" ] && [ -e "$1/.miner/model.gguf" ] && return 0
  [ -e "$STORE/$MODEL_NAME" ] && return 0
  for f in "$STORE"/*/"$MODEL_NAME"; do [ -e "$f" ] && return 0; done
  return 1
}

# Keep the install in use ($1) and the previous one ($2; when that is the same, the newest other version); remove the
# other versions that do not run. A model kept as a plain file inside one (older packages) is moved to the store first.
prune() {
  local keep1=$1 keep2=${2:-} d
  miner_by_name && return 0         # a miner runs (maybe from a RAM folder): remove nothing now
  if [ -z "$keep2" ] || [ "$keep2" = "$keep1" ]; then
    keep2=$(for d in "$BASE"/TheNewMiner-v*-linux-x86_64*; do
              [ -d "$d" ] && [ ! -L "$d" ] && [ "$d" != "$keep1" ] && printf '%s\n' "$d"
            done | sort -V | tail -1)
  fi
  for d in "$BASE"/TheNewMiner-v*-linux-x86_64*; do
    [ -d "$d" ] && [ ! -L "$d" ] || continue
    if [ "$d" = "$keep1" ] || [ "$d" = "$keep2" ]; then continue; fi
    [ -z "$(pids_in "$d")" ] || continue
    if [ -f "$d/.miner/model.gguf" ] && [ ! -L "$d/.miner/model.gguf" ] && [ ! -e "$STORE/$MODEL_NAME" ]; then
      mv "$d/.miner/model.gguf" "$STORE/$MODEL_NAME"
    fi
    rm -rf "$d" && msg pruned "${d##*/}"
  done
}

case "${1:-}" in
check)
  OUT=${2:-}; [ -z "$OUT" ] || : > "$OUT"
  k=${TNM_WSL_KERNEL:-$(uname -r)}
  case "$k" in
    *microsoft-standard*|*WSL2*) msg kernel_wsl2 "$k" ;;
    *Microsoft*) msg wsl1 "$k"; kv "TNM_FAIL=wsl1"; exit 2 ;;
    *) msg not_wsl_kernel "$k" ;;
  esac
  if ! command -v nvidia-smi >/dev/null 2>&1 && [ -x "$LIB/nvidia-smi" ]; then
    ln -sf "$LIB/nvidia-smi" "${TNM_WSL_LINKDIR:-/usr/local/bin}/nvidia-smi" \
      && msg smi_linked "${TNM_WSL_LINKDIR:-/usr/local/bin}/nvidia-smi" "$LIB/nvidia-smi"
  fi
  if ! out=$(nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv,noheader 2>&1); then
    say "$out"
    msg smi_broken
    kv "TNM_FAIL=nvidia-smi"; exit 3
  fi
  msg gpu_in_wsl "$out"
  [ -e "$LIB/libcuda.so.1" ] || { msg no_libcuda "$LIB/libcuda.so.1"; kv "TNM_FAIL=libcuda"; exit 3; }
  if dpkg-query -W -f='${Status} ${Package}\n' 2>/dev/null \
       | grep -qE '^install ok installed (nvidia-driver-|libnvidia-compute-|nvidia-utils-)'; then
    msg linux_driver
    kv "TNM_WARN=linux-nvidia-driver"
  fi
  need=()
  for p in python3 curl ca-certificates libgmp10 xz-utils; do dpkg -s "$p" >/dev/null 2>&1 || need+=("$p"); done
  if [ ${#need[@]} -gt 0 ]; then
    msg installing_pkgs "${need[*]}"
    export DEBIAN_FRONTEND=noninteractive
    # a first boot's unattended-upgrades may hold the dpkg lock for a while: wait up to 5 minutes for it
    apt-get -o DPkg::Lock::Timeout=300 update -q && apt-get -o DPkg::Lock::Timeout=300 install -y -q "${need[@]}" \
      || { kv "TNM_FAIL=apt"; exit 4; }
  fi
  kv "TNM_MEM_KIB=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  mkdir -p "$BASE"
  kv "TNM_DISK_GB=$(df -BG --output=avail "$BASE" 2>/dev/null | tail -1 | tr -dc 0-9)"
  kv "TNM_OK=check"
  ;;
unpack)
  src=${2:?unpack SRC NAME SHA}; name=${3:?unpack SRC NAME SHA}
  want=$(printf '%s' "${4:-}" | tr 'A-F' 'a-f')
  # The name (the install directory under ~/thenewminer) is the package file's name without .tar.xz: a plain
  # release (TheNewMiner-v...-linux-x86_64), the sealed / plain-engine variant (-sealed / -plain), each maybe -rN.
  case "$name" in
    TheNewMiner-v*-linux-x86_64 | TheNewMiner-v*-linux-x86_64-sealed | TheNewMiner-v*-linux-x86_64-plain) ;;
    TheNewMiner-v*-linux-x86_64-r[0-9]* | TheNewMiner-v*-linux-x86_64-sealed-r[0-9]* | TheNewMiner-v*-linux-x86_64-plain-r[0-9]*) ;;
    *) say "TNM_FAIL=name $name"; exit 6 ;;
  esac
  printf '%s' "$want" | grep -Eq '^[0-9a-f]{64}$' || { say "TNM_FAIL=no-sha"; exit 9; }
  mkdir -p "$BASE"; dir=$BASE/$name
  if [ -n "$(pids_in "$dir")" ]; then say "TNM_FAIL=running $dir"; exit 5; fi
  [ -f "$src" ] || { say "TNM_FAIL=missing $src"; exit 6; }
  # room for the copy, the unpacked files and the old version kept beside them (the unpacked size is a few times the .tar.xz)
  size_kb=$(( $(stat -c %s "$src") / 1024 + 1 ))
  need_kb=$(( size_kb * 6 + 262144 ))
  avail_kb=${TNM_WSL_AVAIL_KB:-$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2 {print $4}')}
  if [ -n "$avail_kb" ] && [ "$avail_kb" -lt "$need_kb" ]; then
    msg no_space $(( need_kb / 1024 )) $(( avail_kb / 1024 )); say "TNM_FAIL=disk"; exit 8
  fi
  # Copy the package into WSL's own disk first and check THAT copy: what is unpacked is exactly what was verified.
  stage=$(mktemp -d "$BASE/.stage.XXXXXX"); chmod 700 "$stage"
  if ! cp "$src" "$stage/pkg.tar.xz"; then rm -rf "$stage"; say "TNM_FAIL=copy"; exit 6; fi
  got=$(sha256sum "$stage/pkg.tar.xz" | awk '{print $1}')
  if [ "$got" != "$want" ]; then rm -rf "$stage"; msg sha_again_bad "$got"; say "TNM_FAIL=sha $got"; exit 9; fi
  tmp=$(mktemp -d "$BASE/.unpack.XXXXXX")
  if ! tar -xJf "$stage/pkg.tar.xz" -C "$tmp"; then rm -rf "$tmp" "$stage"; say "TNM_FAIL=tar"; exit 6; fi
  rm -rf "$stage"
  # The package's top directory may be the versioned name or simply "thenewminer" (the sealed release). Take the
  # one directory that holds the ./thenewminer program, whatever it is called.
  top=""
  for c in "$tmp"/*/; do
    if [ -x "$c/thenewminer" ]; then top=${c%/}; break; fi
  done
  if [ -z "$top" ]; then rm -rf "$tmp"; say "TNM_FAIL=layout (no */thenewminer in the package)"; exit 6; fi
  if [ -d "$dir" ]; then
    cp -a "$top/." "$dir/"           # the same version again: new program files, its .miner (install, settings) kept
  else
    mv "$top" "$dir"
  fi
  rm -rf "$tmp"
  prev=$(installed_dir || true)
  if [ -n "$prev" ] && [ "$prev" != "$dir" ] && [ -f "$prev/.miner/mining.json" ] && [ ! -f "$dir/.miner/mining.json" ]; then
    mkdir -p "$dir/.miner"
    cp -p "$prev/.miner/mining.json" "$dir/.miner/"
    [ -f "$prev/.miner/thenewminer.json" ] && cp -p "$prev/.miner/thenewminer.json" "$dir/.miner/"
    msg carried "${prev##*/}"
  fi
  ln -sfn "$dir" "$CUR"
  migrate_models
  prune "$dir" "$prev"
  # the kit's marker (never the front's .miner/installed): the version, the revision (-rN, 1 without) and the bundle
  # sha256 (verified twice above). Routing on later launches reads this; it never re-verifies an installed bundle.
  ver=$(name_version "$name")
  { printf 'version=%s\n' "$ver"; printf 'revision=%s\n' "$(name_rev "$name")"; printf 'bundle_sha256=%s\n' "$want"; } > "$dir/$KIT_MARKER"
  say "TNM_DIR=$dir"
  ;;
installed)
  migrate_models
  d=$(installed_dir)
  if [ -z "$d" ]; then
    say "TNM_INSTALLED_VERSION="; say "TNM_INSTALLED_REV="; say "TNM_INSTALLED_SHA="; say "TNM_HAVE_CONFIG=no"
    if have_model ""; then say "TNM_HAVE_MODEL=yes"; else say "TNM_HAVE_MODEL=no"; fi
    if store_model; then say "TNM_STORE_MODEL=yes"; else say "TNM_STORE_MODEL=no"; fi
    exit 0
  fi
  ver=$(kit_value "$d" version); rev=$(kit_value "$d" revision); sha=$(kit_value "$d" bundle_sha256)
  [ -n "$ver" ] || ver=$(name_version "${d##*/}")
  [ -n "$ver" ] || ver=$(grep -aom1 'v[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*' "$d/.miner/installed" 2>/dev/null | head -n 1 | tr -d v)
  [ -n "$rev" ] || rev=$(name_rev "${d##*/}")
  say "TNM_INSTALLED_VERSION=$ver"
  say "TNM_INSTALLED_REV=$rev"
  say "TNM_INSTALLED_SHA=$sha"
  if [ -x "$d/thenewminer" ] && [ -f "$d/.miner/mining.json" ]; then say "TNM_HAVE_CONFIG=yes"; else say "TNM_HAVE_CONFIG=no"; fi
  if have_model "$d"; then say "TNM_HAVE_MODEL=yes"; else say "TNM_HAVE_MODEL=no"; fi
  if store_model; then say "TNM_STORE_MODEL=yes"; else say "TNM_STORE_MODEL=no"; fi

  ;;
settings)
  d=$(installed_dir)
  if [ -n "$d" ] && [ -f "$d/.miner/mining.json" ]; then
    python3 - "$d/.miner/mining.json" "$d/.miner/thenewminer.json" <<'PY'
import json, sys
m = json.load(open(sys.argv[1]))
w = m.get('WALLET_ADDRESS', '')
print('TNM_SET_WALLET=' + (w[:8] + '...' + w[-6:] if len(w) > 16 else w))
print('TNM_SET_WORKER=' + m.get('WORKER_NAME', ''))
try:
    p = json.load(open(sys.argv[2])).get('proxy') or 'direct'
except (OSError, ValueError):
    p = 'direct'
print('TNM_SET_PROXY=' + p)
PY
  else
    say "TNM_SET=none"
  fi
  ;;
dns)
  # v0.1.47 r2: TNM_DNS_OK=HOST / TNM_DNS_FAIL=HOST per HOST (getent ahosts = getaddrinfo, what the miner uses)
  shift
  for h in "$@"; do
    if timeout 15 getent ahosts "$h" >/dev/null 2>&1; then say "TNM_DNS_OK=$h"; else say "TNM_DNS_FAIL=$h"; fi
  done
  ;;
modelreuse)
  # r3: the model an earlier install (another kit's store, ~/.thenewminer/models of root or a user, an install's .miner)
  # already has on this disk: exact size first (no hashing of anything else), then its sha256, then a hard link into
  # the store (same disk: instant, the old place keeps working; a symbolic link when that is impossible)
  want=$STORE/${MODEL_SHA:0:16}/$MODEL_NAME
  if [ -f "$want" ] && [ "$(stat -L -c %s "$want")" = "$MODEL_BYTES" ]; then say "TNM_MODEL=store"; exit 0; fi
  R=${TNM_WSL_ROOTFS:-}
  for f in "$STORE/$MODEL_NAME" "$STORE"/*/"$MODEL_NAME" \
           "$R"/root/.thenewminer/models/"$MODEL_NAME" "$R"/root/.thenewminer/models/*/"$MODEL_NAME" \
           "$R"/home/*/.thenewminer/models/"$MODEL_NAME" "$R"/home/*/.thenewminer/models/*/"$MODEL_NAME" \
           "$R"/root/*/models/"$MODEL_NAME" "$R"/root/*/models/*/"$MODEL_NAME" "$R"/home/*/*/models/*/"$MODEL_NAME" \
           "$R"/root/*/.miner/model.gguf "$R"/root/*/*/.miner/model.gguf "$R"/home/*/*/.miner/model.gguf \
           "$R"/home/*/*/*/.miner/model.gguf "$R"/root/*/.miner/models/*/"$MODEL_NAME" \
           "$R"/root/*/*/.miner/models/*/"$MODEL_NAME" "$R"/home/*/*/.miner/models/*/"$MODEL_NAME" \
           ${TNM_WSL_ADOPT:+"$TNM_WSL_ADOPT/.miner/model.gguf"}; do
    [ -f "$f" ] || continue
    [ "$(stat -L -c %s "$f" 2>/dev/null)" = "$MODEL_BYTES" ] || continue
    real=$(readlink -f "$f")
    msg model_checking "$real"
    if [ "$(sha256sum < "$real" | awk '{print $1}')" != "$MODEL_SHA" ]; then msg model_other "$real"; continue; fi
    mkdir -p "${want%/*}"
    ln "$real" "$want" 2>/dev/null || ln -sfn "$real" "$want" || continue
    msg model_reused "$real"
    say "TNM_MODEL=reused $real"
    exit 0
  done
  say "TNM_MODEL=none"
  ;;
logmark)
  # the install in use and its log's line count now (a test reads only the lines written after this)
  d=$(installed_dir)
  say "TNM_LOGDIR=${d:-none}"
  n=0; [ -n "$d" ] && n=$(grep -c '' "$d/.miner/thenewminer.log" 2>/dev/null); say "TNM_LOGLINES=${n:-0}"
  ;;
running)
  d=$(installed_dir)
  if miner_running "$d"; then say yes; else say no; fi
  ;;
run)
  shift
  migrate_models
  d=$(installed_dir)
  [ -n "$d" ] && [ -x "$d/thenewminer" ] || { msg not_installed; say "TNM_FAIL=not-installed"; exit 7; }
  cd "$d" && exec ./thenewminer "$@"
  ;;
logs|stop)
  d=$(installed_dir)
  [ -n "$d" ] && [ -x "$d/thenewminer" ] || { msg not_installed; say "TNM_FAIL=not-installed"; exit 7; }
  cd "$d" && exec ./thenewminer "--$1"
  ;;
status)
  d=$(installed_dir)
  [ -n "$d" ] || { say "TNM_RUNNING=no"; msg not_installed; exit 0; }
  if miner_running "$d"; then say "TNM_RUNNING=yes"; else say "TNM_RUNNING=no"; fi
  say "TNM_VERSION=${d##*/}"
  tail -n 2000 "$d/.miner/thenewminer.log" 2>/dev/null | strip | grep -a 'N/s' | tail -3
  ;;
*)
  say "usage: $0 check | unpack SRC NAME SHA | installed | settings | dns HOST... | modelreuse | logmark | running | run [ARGS] | logs | stop | status"; exit 2

  ;;
esac
