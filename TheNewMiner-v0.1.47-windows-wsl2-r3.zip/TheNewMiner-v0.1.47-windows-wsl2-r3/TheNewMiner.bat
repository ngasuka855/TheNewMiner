@echo off
rem TheNewMiner for Windows (WSL2) - one click. r3 hotfix: the window never ends in a bare "Done".
rem   TheNewMiner.bat [setup|stop|logs|status|background|uninstall] [options]
rem Double-click: install the first time, then mine; later: mine at once.
rem If the miner is not running when the window would end, it says why, shows the last log lines and offers a restart.
rem v0.1.47 r3: a setup that stopped is shown FIRST (never "MINING" after it); "mining" only when wsl.exe exits with
rem exactly 0 (its -1, a missing distro, is not "running"); the distro and the install base come from what the setup
rem found (%LOCALAPPDATA%\TheNewMiner\distro.txt, base.txt): an install in another distro is checked where it is.
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%~dp0files\thenewminer-wsl.ps1" goto noextract
set "TNM_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "TNM_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%TNM_PS%" set "TNM_PS=powershell.exe"
set "TNM_WSL=%SystemRoot%\System32\wsl.exe"
if exist "%SystemRoot%\Sysnative\wsl.exe" set "TNM_WSL=%SystemRoot%\Sysnative\wsl.exe"
if not exist "%TNM_WSL%" set "TNM_WSL=wsl.exe"
set "TNM_ACT=%~1"
if not defined TNM_ACT set "TNM_ACT=auto"
if "%TNM_ACT:~0,1%"=="-" set "TNM_ACT=auto"
set "TNM_CP="
rem v0.1.47 r2: chcp reads NUL - with a redirected input (SSH without a terminal) it would eat the answers to the
rem console questions (tools/windows/ci stdin probe, 2026-10-28)
for /f "tokens=*" %%a in ('chcp ^<nul') do for %%b in (%%a) do set "TNM_CP=%%b"
if defined TNM_CP set "TNM_CP=%TNM_CP:.=%"
chcp 65001 >nul <nul

:run
"%TNM_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\thenewminer-wsl.ps1" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="3010" goto reboot
for %%x in (stop logs status uninstall) do if /i "%TNM_ACT%"=="%%x" goto plainend
call :where
set "TNM_FAILF=%LOCALAPPDATA%\TheNewMiner\last-setup-failure.txt"
if exist "%TNM_FAILF%" goto setupfail
call :isrunning
if "%TNM_RUNNING%"=="1" goto running
rem v0.1.45 (audit R4): "background" (or a setup with -Background) returns at once, before WSL, the launcher and the
rem front exist. Wait up to 120 s while it starts: never say NOT mining about a start that is still under way.
rem Only after a background start (review A11): a foreground run that ended is not starting.
if not "%RC%"=="0" goto notrunning
set "TNM_BG=0"
if /i "%TNM_ACT%"=="background" set "TNM_BG=1"
for %%a in (%*) do if /i "%%~a"=="-Background" set "TNM_BG=1"
if "%TNM_BG%"=="0" goto notrunning
set "TNM_WAITED=0"
echo Starting TheNewMiner (checking the model, loading it onto the GPU; a first start also installs) ...
:waitstart
call :wait5
set /a TNM_WAITED+=5
call :isrunning
if "%TNM_RUNNING%"=="1" goto running
call :isstarting
if "%TNM_STARTING%"=="1" goto stillstarting
if %TNM_WAITED% GEQ 30 goto notrunning
goto waitstart
:stillstarting
if %TNM_WAITED% GEQ 120 goto startinglog
echo   starting ... %TNM_WAITED% s
goto waitstart

:running
echo ============================================================
echo  TheNewMiner is MINING (in the background).
echo  Showing the live log now. Ctrl+C leaves the log; mining goes on.
echo  Stop mining: TheNewMiner.bat stop
echo ============================================================
"%TNM_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\thenewminer-wsl.ps1" logs
goto end

:startinglog
echo ============================================================
echo  TheNewMiner is STARTING (still installing or loading after 2 minutes;
echo  a first start downloads the 8.1 GiB model). It goes on in the background.
echo  Showing the live log now. Ctrl+C leaves the log; the start goes on.
echo  Later: TheNewMiner.bat status    Stop: TheNewMiner.bat stop
echo ============================================================
"%TNM_PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\thenewminer-wsl.ps1" logs
goto end

:notrunning
echo ============================================================
echo  TheNewMiner is NOT mining.   Exit code: %RC%
if "%RC%"=="0" echo  The miner stopped without an error code.
if "%RC%"=="1" echo  The miner reported an error. The reason is in the last log lines below.
if "%RC%"=="130" echo  Stopped with Ctrl+C.
if "%RC%"=="137" echo  The miner was killed, most likely OUT OF MEMORY. Close other programs and try again.
if "%RC%"=="77" echo  The POOL REJECTED the wallet / password (or has not approved the account yet).
if "%RC%"=="77" echo  Check them, then run: TheNewMiner.bat setup
if "%RC%"=="-1" echo  WSL stopped unexpectedly.
if "%RC%"=="4294967295" echo  WSL stopped unexpectedly.
echo  Last log lines (send a screenshot of this window if you need help):
echo ------------------------------------------------------------
"%TNM_WSL%" -d %TNM_DISTRO% -u root -e bash -c "D=$(readlink -f '%TNM_BASE%'/current 2>/dev/null); echo install: $D; if [ %RC% = 0 ] && grep -qs 'pool rejected' $D/.miner/thenewminer.stopped; then echo; echo '*** The POOL REJECTED the wallet / password (or has not approved the account yet). Check them: TheNewMiner.bat setup ***'; fi; for f in install.log thenewminer.log; do echo; echo === $f; tail -n 25 $D/.miner/$f 2>/dev/null || echo none; done; echo; echo === out-of-memory; dmesg 2>/dev/null | grep -i -E 'out of memory|oom-kill|killed process' | tail -n 5; echo; echo === memory; free -m"
goto notrunning2

:setupfail
rem v0.1.47 r2: a setup that stopped leaves its step and its fix in this file. r3: shown before anything else, and a
rem miner that still runs (the install the failed upgrade left alone) is named as such, never as "MINING".
echo ============================================================
echo  TheNewMiner SETUP STOPPED. Nothing new was started.
echo  The step that stopped and how to fix it (send a screenshot of this window if you need help):
echo ------------------------------------------------------------
type "%TNM_FAILF%"
call :isrunning
if not "%TNM_RUNNING%"=="1" goto notrunning2
set "TNM_IVER="
if exist "%LOCALAPPDATA%\TheNewMiner\last-setup-failure-version.txt" set /p TNM_IVER=<"%LOCALAPPDATA%\TheNewMiner\last-setup-failure-version.txt"
echo.
if defined TNM_IVER echo  Your installed miner (v%TNM_IVER%) is still mining; it was not changed.
if not defined TNM_IVER echo  Your installed miner is still mining; it was not changed.

:notrunning2
if exist "%USERPROFILE%\.wslconfig" (
  echo.
  echo === .wslconfig
  type "%USERPROFILE%\.wslconfig"
)
echo ------------------------------------------------------------
echo.
choice /c RQ /n /m "Press R to start again, or Q to close: "
if errorlevel 2 goto end
goto run

:reboot
if defined TNM_CP chcp %TNM_CP% >nul
echo Restart Windows, then double-click TheNewMiner.bat again (it resumes automatically).
pause
exit /b %RC%

:plainend
if defined TNM_CP chcp %TNM_CP% >nul
echo Finished, exit code %RC%.
pause
exit /b %RC%

:end
if defined TNM_CP chcp %TNM_CP% >nul
exit /b %RC%

rem Where the install is: the distro and its kit base the setup found (an install in another distro is used in place).
:where
set "TNM_DISTRO=TheNewMiner"
set "TNM_BASE=/root/thenewminer"
if exist "%LOCALAPPDATA%\TheNewMiner\distro.txt" set /p TNM_DISTRO=<"%LOCALAPPDATA%\TheNewMiner\distro.txt"
if exist "%LOCALAPPDATA%\TheNewMiner\base.txt" set /p TNM_BASE=<"%LOCALAPPDATA%\TheNewMiner\base.txt"
exit /b 0

rem r3: running only when wsl.exe exits with exactly 0 - "if not errorlevel 1" also took wsl.exe's -1 (no such distro).
:isrunning
set "TNM_RUNNING=0"
"%TNM_WSL%" -d %TNM_DISTRO% -u root -e sh -c "pgrep -f 'thenew(miner|pool)-miner' >/dev/null" >nul 2>&1
if "%ERRORLEVEL%"=="0" set "TNM_RUNNING=1"
exit /b 0

rem The launcher or the front of the package runs (installing, checking or loading the model) - no miner process yet.
:isstarting
set "TNM_STARTING=0"
"%TNM_WSL%" -d %TNM_DISTRO% -u root -e sh -c "pgrep -af '(^|/)thenew(miner|pool)( |$)' | grep -vqE -- '--(logs?|status|stop)( |$)'" >nul 2>&1
if "%ERRORLEVEL%"=="0" set "TNM_STARTING=1"
exit /b 0


:wait5
timeout /t 5 /nobreak >nul 2>&1
if errorlevel 1 "%TNM_PS%" -NoProfile -Command "Start-Sleep -Seconds 5" >nul 2>&1
exit /b 0

:noextract
echo.
echo Please extract the zip first: right-click the zip, choose "Extract All",
echo then double-click TheNewMiner.bat in the extracted folder.
echo.
pause
exit /b 1
