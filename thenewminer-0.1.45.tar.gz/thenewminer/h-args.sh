#!/usr/bin/env bash
# Split the flight sheet's "extra config arguments" into an argv the way a shell would, without ever
# evaluating it: quotes group words but cannot run commands (the usual HiveOS h-args.sh rule).
# Result: the bash array TNP_ARGS.
tnp_parse_args() {
    command -v python3 >/dev/null 2>&1 || { echo "python3 is required to read the flight sheet arguments" >&2; return 1; }
    local -a parsed=()
    mapfile -d '' -t parsed < <(printf '%s' "${1-}" | python3 -c '
import shlex, sys
raw = sys.stdin.buffer.read(65537)
if len(raw) > 65536 or b"\0" in raw:
    sys.exit("thenewminer arguments exceed 64 KiB or contain NUL")
# bytes in, bytes out (UTF-8, surrogateescape): a UTF-8 password survives byte-exact whatever the locale says
text = raw.decode("utf-8", "surrogateescape")
try:
    words = shlex.split(text, comments=False, posix=True)
except ValueError as e:
    sys.exit("thenewminer arguments: bad quoting (%s)" % e)
sys.stdout.buffer.write(b"tnp-argv-v1\0" + b"".join(w.encode("utf-8", "surrogateescape") + b"\0" for w in words))
')
    [[ "${parsed[0]-}" == tnp-argv-v1 ]] || return 1
    TNP_ARGS=("${parsed[@]:1}")
}

# The inverse: an argv written back as one safely quoted line.
tnp_format_args() {
    printf '%s\0' "$@" | python3 -c '
import shlex, sys
# shlex.quote per word (shlex.join is Python 3.8+; older HiveOS images ship 3.6), bytes-exact as above
words = [w.decode("utf-8", "surrogateescape") for w in sys.stdin.buffer.read().split(b"\0")[:-1]]
sys.stdout.buffer.write(" ".join(shlex.quote(w) for w in words).encode("utf-8", "surrogateescape") + b"\n")'
}
