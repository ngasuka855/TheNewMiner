﻿TheNewMiner Windows 版(WSL2)— 一键使用
==========================================

TheNewMiner 在 Windows 内置的 WSL2(Linux 子系统)中运行 Linux 版矿工,计算结果与 Linux 完全一致。
整个矿工都在这个 zip 里,无需另外下载;只有 WSL/Ubuntu 和 AI 模型会在安装时获取。

使用
1. 把整个 zip 解压(右键 > 全部解压缩)到任意位置:任意文件夹、任意磁盘,带空格或中文的路径都没问题。
   不要在 zip 预览窗口中直接打开。
2. 双击 TheNewMiner.bat。
   - 第一次:检查 Windows / 驱动 / 硬盘,开启 WSL(弹一次管理员确认;可能需要重启一次,之后会自动继续),
     显示数据存放位置(按 Enter 确认),安装内置的矿工,询问钱包 / 密码 / 矿工名,下载模型,然后开始挖矿。
   - 之后每次:直接用保存的设置开始挖矿 —— 不再询问、不重装、不重新下载。
3. 提示时输入:钱包地址(<你的钱包地址>,tc1...)、矿池密码(<你的矿池密码>,输入两次)、
   矿工名(直接按 Enter = 电脑名)。矿池 tsc-wss.the-new.win 已经预设在程序里,直接连接,无需代理。

安装后桌面会有一个“TheNewMiner”快捷方式,下次一点即开始。

Windows 安全提示
- SmartScreen 可能显示“Windows 已保护你的电脑”/“未知发布者”,因为这个 kit 没有代码签名。
  点击“更多信息”,再点击“仍要运行”。
- Microsoft Defender 或其他杀毒软件常常把任何加密货币矿工标记为“可能不需要的应用”,
  即使是你自己选择运行的正当程序也一样。如果文件被隔离:打开“Windows 安全中心 > 病毒和威胁防护 > 保护历史记录”,
  选择 TheNewMiner 这一项,点击“允许”(或者把 kit 文件夹加入“排除项”)。
  只对从官方发布页下载、并且 sha256 校验正确的 zip 这样做。

日常命令(在这个文件夹中打开命令提示符)
  TheNewMiner.bat              需要则安装,然后开始挖矿(已安装则直接挖矿)
  TheNewMiner.bat background   后台挖矿(无窗口)
  TheNewMiner.bat logs         查看矿工(Ctrl+C 退出,矿工继续挖)
  TheNewMiner.bat stop         停止
  TheNewMiner.bat status       查看状态和最近速度
  TheNewMiner.bat setup        重新输入钱包 / 密码 / 矿工名
  TheNewMiner.bat uninstall    卸载矿工、数据文件夹和快捷方式(会先询问)

文件位置
- 矿工及其数据(包括约 8.1 GiB 模型)放在一个专用的 WSL 发行版“TheNewMiner”中。它的磁盘位于第一次安装时
  选定的数据文件夹,不在这个 kit 文件夹里:默认是 kit 所在磁盘根目录的 TheNewMinerData(例如 D:\TheNewMinerData);
  如果该磁盘是可移动磁盘或空间不足,则选择另一个固定磁盘。那里需要约 20 GB 可用空间。
  高级:TheNewMiner.bat setup -DataDir <文件夹>。
- 模型在第一次启动时下载,之后所有新版本都会继续使用。

升级
把新版本解压到任意位置,双击它的 TheNewMiner.bat。它会自动找到已安装的矿工,保留你的设置和模型,
无需任何询问即可安装新版本。之后旧的 kit 文件夹可以删除。如果数据文件夹被删除或磁盘被移除,
TheNewMiner.bat setup 会重新创建。

语言
界面文字跟随你的 Windows 显示语言(繁體 / 简体 / English)。手动指定:TheNewMiner.bat setup -Lang zh-Hans(或 zh-Hant、en)。

要求
64 位 Windows 10 21H2(19044)或更新版本,或者 Windows 11。NVIDIA 30/40/50 系显卡,驱动 580 或更新
(在 Windows 安装,不要在 WSL 中安装)。数据磁盘约 20 GB 可用空间。BIOS 已开启虚拟化。

高级
- TheNewMiner.bat setup -Package <文件> -Sha256 <64 个字符>:安装指定的包,代替内置的包
  (文件旁边有 .sha256 或 SHA256SUMS 也可以;没有校验值的包会被拒绝)。
- 代理(可选):TheNewMiner.bat setup -Proxy IP[:PORT] | socks5://主机:端口 | http://主机:端口
