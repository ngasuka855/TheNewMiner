﻿TheNewMiner for Windows (WSL2) - one click
==========================================

TheNewMiner runs the Linux miner inside WSL2, the Linux subsystem built into Windows. Results are bit-for-bit the
same as on Linux. Everything is in this one zip: the miner is never downloaded separately. Only WSL/Ubuntu and the
AI model are fetched at install time.

USE IT
1. Unzip the whole zip (right-click > Extract All) anywhere you like: any folder, any drive, a path with spaces or
   Chinese characters all work. Do not run it from inside the zip view.
2. Double-click TheNewMiner.bat.
   - First time: it checks Windows / driver / disk, turns WSL on (one administrator prompt; a restart may be needed
     once, and setup then resumes by itself), shows where the data will go (Enter accepts), installs the bundled
     miner, asks for your wallet / password / worker, downloads the model, then starts mining.
   - Every time after: it goes straight to mining with your saved settings - no prompts, no reinstall, no download.
3. Enter when asked: wallet (<your-wallet-address>, tc1...), pool password (<your-pool-password>, typed twice),
   worker name (Enter = the computer name). The pool tsc-wss.the-new.win is built in, so you connect directly.

A desktop shortcut "TheNewMiner" is created so you can start it again with one click.

WINDOWS SECURITY PROMPTS
- SmartScreen may say "Windows protected your PC" / "unknown publisher" because the kit is not code-signed.
  Click "More info", then "Run anyway".
- Microsoft Defender or other antivirus programs often flag any cryptocurrency miner as a "potentially unwanted
  application", even a legitimate one you chose to run. If it quarantines a file, open Windows Security > Virus &
  threat protection > Protection history, choose the TheNewMiner item and "Allow" (or add the kit folder under
  Exclusions). Only do this for a zip you downloaded from the official release page and whose sha256 matches.

DAILY COMMANDS (in this folder, in a Command Prompt)
  TheNewMiner.bat              install if needed, then mine (or just mine if installed)
  TheNewMiner.bat background   mine without a window
  TheNewMiner.bat logs         watch the miner (Ctrl+C leaves; mining goes on)
  TheNewMiner.bat stop         stop mining
  TheNewMiner.bat status       whether it runs, and the last rates
  TheNewMiner.bat setup        re-enter wallet / password / worker
  TheNewMiner.bat uninstall    remove the miner, its data folder, the shortcut (asks first)

WHERE THINGS GO
- The miner and its data (including the ~8.1 GiB model) live in a dedicated WSL distribution "TheNewMiner". Its
  disk is in a data folder chosen once at the first install, NOT inside this kit folder: by default
  TheNewMinerData at the root of this kit's drive (for example D:\TheNewMinerData), or another fixed drive when this
  one is removable or too full. About 20 GB free is needed there. Advanced: TheNewMiner.bat setup -DataDir <folder>.
- The model is downloaded on the first start and reused by every later version.

UPGRADE
Unzip the new version anywhere and double-click its TheNewMiner.bat. It finds the installed miner by itself, keeps
your settings and the model, and installs the new version without questions. The old kit folder may be deleted
afterwards. If the data folder was deleted or its drive removed, TheNewMiner.bat setup creates it again.

LANGUAGE
On-screen text follows your Windows display language (Traditional Chinese / Simplified Chinese / English).
Override: TheNewMiner.bat setup -Lang en (or zh-Hant, zh-Hans).

REQUIREMENTS
64-bit Windows 10 21H2 (19044) or later, or Windows 11. NVIDIA 30/40/50-series card, driver 580 or newer
(installed on Windows, never inside WSL). About 20 GB free on the data drive. Virtualization turned on in the BIOS.

ADVANCED
- TheNewMiner.bat setup -Package <file> -Sha256 <64 characters> installs a specific package instead of the bundled
  one (a .sha256 or SHA256SUMS next to the file also works; a package without a checksum is refused).
- Proxy (optional): TheNewMiner.bat setup -Proxy IP[:PORT] | socks5://host:port | http://host:port
