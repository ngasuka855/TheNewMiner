#!/bin/bash
# TheNewMiner on Windows through WSL2: the part that runs INSIDE the dedicated "TheNewMiner" WSL distribution, as root.
# files\thenewminer-wsl.ps1 (started by TheNewMiner.bat) copies this file to %LOCALAPPDATA%\TheNewMiner\wsl\ (a per-user
# folder only that user, SYSTEM and Administrators can write) with LF line endings and runs it with
# `wsl -d TheNewMiner -u root -e /bin/bash <this> COMMAND ...`. The miner itself is the unchanged Linux package, unpacked
# into ~/thenewminer/<package name> (WSL's own ext4 disk, never /mnt/c); ~/thenewminer/current points at the one in use,
# and the model lives in ~/thenewminer/models for every version (TNP_MODEL_DIR). Machine-readable lines start with
# "TNM_" (the PowerShell side reads them); the rest is for people.
#   check [FILE]          WSL2 kernel, nvidia-smi (linked from /usr/lib/wsl/lib when it is not on the PATH), libcuda,
#                         no Linux NVIDIA driver inside WSL, the packages the installer needs, memory and disk
#   unpack SRC NAME SHA   SRC (a .tar.xz the Windows side verified) copied into WSL, its sha256 checked AGAIN there
#                         (refused without one), unpacked into ~/thenewminer/NAME; settings carried over from the install
#                         in use; the model moved to ~/thenewminer/models; older versions pruned (the new one and the
#                         previous one are kept); ~/thenewminer/current -> it; writes the install marker
#   installed             the kit's marker (<install>/.tnm-kit): version, revision, bundle sha256, config / model
#                         present (fast routing)
#   settings              the remembered settings of the install in use (wallet shortened, worker, proxy)
#   running               yes / no: a thenewminer of the install in use runs (by cwd, or a miner by process name)
#   logmark               the install in use and the line count of its log (operator test)
#   run [ARGS]            ./thenewminer ARGS in the install in use (exec: Ctrl+C and --stop reach it directly)
#   logs | stop           ./thenewminer --logs | --stop there
#   status                running or not, the version, the last rate lines
# Test hooks (tools/test_windows_wsl.py): TNM_WSL_BASE (default ~/thenewminer), TNM_WSL_LIB (default /usr/lib/wsl/lib),
# TNM_WSL_KERNEL (default uname -r), TNM_WSL_LINKDIR (default /usr/local/bin), TNM_WSL_PROC (default /proc),
# TNM_WSL_AVAIL_KB (default: df of the base).
set -u
BASE=${TNM_WSL_BASE:-$HOME/thenewminer}
CUR=$BASE/current
LIB=${TNM_WSL_LIB:-/usr/lib/wsl/lib}
PROC=${TNM_WSL_PROC:-/proc}
# One model store for every version (the miner's TNP_MODEL_DIR): an upgrade never downloads the 8.1 GiB again.
STORE=$BASE/models
MODEL_NAME=Qwen3-8B-Q8_0-full-v2.gguf
export TNP_MODEL_DIR=$STORE
say() { printf '%s\n' "$*"; }
OUT=""                                   # check FILE: its TNM_ lines go to FILE instead (the Windows side reads them)
kv() { if [ -n "$OUT" ]; then printf '%s\n' "$*" >> "$OUT"; else say "$*"; fi; }
strip() { sed 's/\x1b\[[0-9;]*m//g' "$@"; }

# msg ID [ARG...]: a line for people, in TNM_LANG (zh-Hant / zh-Hans; anything else = English; the Windows side
# sets it). One entry per line - tools/test_windows_wsl.py reads this table (all three languages, no Cantonese
# in zh-Hans / en). The texts are printf formats (%s only).
msg() {
  _id=$1; shift
  _h=''; _s=''; _e=''
  case "$_id" in
    kernel_wsl2) _h='WSL2 核心 %s'; _s='WSL2 内核 %s'; _e='WSL2 kernel %s' ;;
    wsl1) _h='呢個 distro 係 WSL 1(核心 %s):GPU 要 WSL 2'; _s='这个发行版以 WSL 1 运行(内核 %s):GPU 需要 WSL 2'; _e='this distro runs as WSL 1 (kernel %s): the GPU needs WSL 2' ;;
    not_wsl_kernel) _h='核心 %s(唔係 WSL 核心:呢個工具係俾 WSL2 用嘅)'; _s='内核 %s(不是 WSL 内核:这个工具用于 WSL2)'; _e='kernel %s (not a WSL kernel: this helper is meant for WSL2)' ;;
    smi_linked) _h='已經連結 %s -> %s(佢原本唔喺 PATH 入面)'; _s='已链接 %s -> %s(它原本不在 PATH 中)'; _e='linked %s -> %s (it was not on the PATH)' ;;
    smi_broken) _h='WSL 入面 nvidia-smi 用唔到:請更新 Windows 嘅 NVIDIA driver(580 或更新),再打 wsl --shutdown。'; _s='WSL 中 nvidia-smi 无法使用:请更新 Windows 的 NVIDIA 驱动(580 或更新),然后运行 wsl --shutdown。'; _e='nvidia-smi does not work inside WSL: update the NVIDIA driver on Windows (580 or newer) and run wsl --shutdown.' ;;
    gpu_in_wsl) _h='WSL 入面嘅 GPU:%s'; _s='WSL 中的 GPU:%s'; _e='GPU in WSL: %s' ;;
    no_libcuda) _h='冇 %s:Windows 嘅 NVIDIA driver 靠佢俾 WSL 用 CUDA'; _s='缺少 %s:Windows 的 NVIDIA 驱动通过它为 WSL 提供 CUDA'; _e='%s is missing: the Windows NVIDIA driver gives WSL its CUDA there' ;;
    linux_driver) _h='WSL 入面裝咗 Linux 版 NVIDIA driver 套件:佢會遮住 Windows driver 嘅 GPU(移除:apt-get purge "nvidia-*" "libnvidia-*")'; _s='WSL 中安装了 Linux 版 NVIDIA 驱动软件包:它会遮蔽 Windows 驱动提供的 GPU(移除方法:apt-get purge "nvidia-*" "libnvidia-*")'; _e='a Linux NVIDIA driver package is installed inside WSL: it hides the GPU of the Windows driver (remove it: apt-get purge "nvidia-*" "libnvidia-*")' ;;
    installing_pkgs) _h='裝緊礦工要用嘅套件:%s(大約 1-3 分鐘)'; _s='正在安装矿工所需的软件包:%s(约 1-3 分钟)'; _e='installing the packages the miner needs: %s (about 1-3 minutes)' ;;
    carried) _h='設定由 %s 帶過嚟'; _s='已沿用 %s 的设置'; _e='settings carried over from %s' ;;
    models_moved) _h='模型搬咗去 %s(所有版本共用,升級唔使再下載)'; _s='模型已移到 %s(所有版本共用,升级无需重新下载)'; _e='the model was moved to %s (shared by every version: an upgrade never downloads it again)' ;;
    pruned) _h='移除咗舊版本 %s'; _s='已删除旧版本 %s'; _e='removed the old version %s' ;;
    sha_again_bad) _h='WSL 入面再核對 sha256 唔啱(%s):個包喺複製途中變咗,唔會用'; _s='在 WSL 中再次校验 sha256 不符(%s):包在复制过程中被改动,不会使用'; _e='the sha256 checked again inside WSL does not match (%s): the package changed on the way and is not used' ;;
    no_space) _h='WSL 嘅磁碟空位唔夠:要約 %s MB,得 %s MB'; _s='WSL 磁盘空间不足:需要约 %s MB,只有 %s MB'; _e='not enough space on the WSL disk: about %s MB is needed, %s MB is free' ;;
    not_installed) _h='未裝:請先雙擊 TheNewMiner.bat'; _s='尚未安装:请先双击 TheNewMiner.bat'; _e='not installed: run TheNewMiner.bat first' ;;
  esac
  case "${TNM_LANG:-en}" in zh-Hant) _f=$_h ;; zh-Hans) _f=$_s ;; *) _f=$_e ;; esac
  [ -n "$_f" ] || _f=$_id
  # shellcheck disable=SC2059
  printf "$_f\n" "$@"
}

# DIR: the pids of the thenewminer front / miner processes whose working directory is DIR.
pids_in() {
  local d p c
  d=$(readlink -f "$1" 2>/dev/null) || return 0
  [ -n "$d" ] || return 0
  for p in "$PROC"/[0-9]*; do
    [ "$(readlink "$p/cwd" 2>/dev/null)" = "$d" ] || continue
    c=$(tr '\0' '\n' < "$p/cmdline" 2>/dev/null | head -1)
    case "${c##*/}" in thenewminer|thenewminer-miner) echo "${p##*/}" ;; esac
  done
}

installed_dir() { [ -e "$CUR" ] && readlink -f "$CUR" 2>/dev/null; }

# The kit's own install marker: <install>/.tnm-kit. <install>/.miner/installed is the FRONT's marker (its first line is
# the release stamp; ops/install.sh removes and rewrites it) and is never written here. Kits r3 / r4 wrote theirs
# there (version= / revision= / bundle_sha256= lines), so that file is still read as a fallback.
KIT_MARKER=.tnm-kit
kit_value() {   # DIR KEY
  local v=""
  [ -f "$1/$KIT_MARKER" ] && v=$(sed -n "s/^$2=//p" "$1/$KIT_MARKER" | head -1)
  [ -n "$v" ] || { [ -f "$1/.miner/installed" ] && v=$(sed -n "s/^$2=//p" "$1/.miner/installed" | head -1); }
  printf '%s' "$v"
}

# A miner of ours runs: by its process name anywhere (the sealed package runs its front and miner from a RAM folder,
# not from the install folder), like `pgrep -f 'thenew(miner|pool)-miner'`. TNM_WSL_PROC (tests) is scanned the same way.
miner_by_name() {
  local p c
  if [ "$PROC" = /proc ] && command -v pgrep >/dev/null 2>&1; then
    pgrep -f 'thenew(miner|pool)-miner' >/dev/null 2>&1
    return
  fi
  for p in "$PROC"/[0-9]*; do
    c=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null) || continue
    case "$c" in *thenewminer-miner*|*thenewpool-miner*) return 0 ;; esac
  done
  return 1
}
miner_running() { [ -n "$1" ] && [ -n "$(pids_in "$1")" ] && return 0; miner_by_name; }

# The version and the revision in a package / install name: TheNewMiner-v0.1.44-linux-x86_64-sealed-r2 -> 0.1.44, 2
# (no -rN = revision 1).
name_version() { printf '%s' "$1" | sed -n 's/^TheNewMiner-v\([0-9][0-9.]*\)-linux-x86_64.*/\1/p'; }
name_rev() {
  local r
  r=$(printf '%s' "$1" | sed -n 's/.*-r\([0-9][0-9]*\)$/\1/p')
  printf '%s' "${r:-1}"
}

# The model store used to be ~/.thenewminer/models (the miner's default): move what is there into $STORE once (the
# same ext4 disk: a rename, instant) and leave a symlink, so an install whose .miner/model.gguf points at the old
# place still finds it.
# The same for a models directory an earlier kit's install kept in its own .miner (<install>/.miner/models): moved into
# the store, and the directory becomes a symlink to it, so neither that install nor the next version downloads again.
migrate_models() {
  local old s t moved=""
  mkdir -p "$STORE"
  for old in "$HOME/.thenewminer/models" "$BASE"/TheNewMiner-v*-linux-x86_64*/.miner/models; do
    [ -d "$old" ] && [ ! -L "$old" ] || continue
    for s in "$old"/* "$old"/.[!.]*; do
      [ -e "$s" ] || [ -L "$s" ] || continue
      t=$STORE/${s##*/}
      if [ ! -e "$t" ] && [ ! -L "$t" ]; then mv "$s" "$t" && moved=1; fi
    done
    if rmdir "$old" 2>/dev/null; then ln -s "$STORE" "$old"; fi
  done
  [ -z "$moved" ] || msg models_moved "$STORE"
}

# yes when the model is on this disk already (an upgrade then needs no room for it).
have_model() {
  local f
  [ -n "$1" ] && [ -e "$1/.miner/model.gguf" ] && return 0
  [ -e "$STORE/$MODEL_NAME" ] && return 0
  for f in "$STORE"/*/"$MODEL_NAME"; do [ -e "$f" ] && return 0; done
  return 1
}

# Keep the install in use ($1) and the previous one ($2; when that is the same, the newest other version); remove the
# other versions that do not run. A model kept as a plain file inside one (older packages) is moved to the store first.
prune() {
  local keep1=$1 keep2=${2:-} d
  miner_by_name && return 0         # a miner runs (maybe from a RAM folder): remove nothing now
  if [ -z "$keep2" ] || [ "$keep2" = "$keep1" ]; then
    keep2=$(for d in "$BASE"/TheNewMiner-v*-linux-x86_64*; do
              [ -d "$d" ] && [ ! -L "$d" ] && [ "$d" != "$keep1" ] && printf '%s\n' "$d"
            done | sort -V | tail -1)
  fi
  for d in "$BASE"/TheNewMiner-v*-linux-x86_64*; do
    [ -d "$d" ] && [ ! -L "$d" ] || continue
    if [ "$d" = "$keep1" ] || [ "$d" = "$keep2" ]; then continue; fi
    [ -z "$(pids_in "$d")" ] || continue
    if [ -f "$d/.miner/model.gguf" ] && [ ! -L "$d/.miner/model.gguf" ] && [ ! -e "$STORE/$MODEL_NAME" ]; then
      mv "$d/.miner/model.gguf" "$STORE/$MODEL_NAME"
    fi
    rm -rf "$d" && msg pruned "${d##*/}"
  done
}

case "${1:-}" in
check)
  OUT=${2:-}; [ -z "$OUT" ] || : > "$OUT"
  k=${TNM_WSL_KERNEL:-$(uname -r)}
  case "$k" in
    *microsoft-standard*|*WSL2*) msg kernel_wsl2 "$k" ;;
    *Microsoft*) msg wsl1 "$k"; kv "TNM_FAIL=wsl1"; exit 2 ;;
    *) msg not_wsl_kernel "$k" ;;
  esac
  if ! command -v nvidia-smi >/dev/null 2>&1 && [ -x "$LIB/nvidia-smi" ]; then
    ln -sf "$LIB/nvidia-smi" "${TNM_WSL_LINKDIR:-/usr/local/bin}/nvidia-smi" \
      && msg smi_linked "${TNM_WSL_LINKDIR:-/usr/local/bin}/nvidia-smi" "$LIB/nvidia-smi"
  fi
  if ! out=$(nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv,noheader 2>&1); then
    say "$out"
    msg smi_broken
    kv "TNM_FAIL=nvidia-smi"; exit 3
  fi
  msg gpu_in_wsl "$out"
  [ -e "$LIB/libcuda.so.1" ] || { msg no_libcuda "$LIB/libcuda.so.1"; kv "TNM_FAIL=libcuda"; exit 3; }
  if dpkg-query -W -f='${Status} ${Package}\n' 2>/dev/null \
       | grep -qE '^install ok installed (nvidia-driver-|libnvidia-compute-|nvidia-utils-)'; then
    msg linux_driver
    kv "TNM_WARN=linux-nvidia-driver"
  fi
  need=()
  for p in python3 curl ca-certificates libgomp1 libgmp10 xz-utils; do dpkg -s "$p" >/dev/null 2>&1 || need+=("$p"); done
  if [ ${#need[@]} -gt 0 ]; then
    msg installing_pkgs "${need[*]}"
    export DEBIAN_FRONTEND=noninteractive
    # a first boot's unattended-upgrades may hold the dpkg lock for a while: wait up to 5 minutes for it
    apt-get -o DPkg::Lock::Timeout=300 update -q && apt-get -o DPkg::Lock::Timeout=300 install -y -q "${need[@]}" \
      || { kv "TNM_FAIL=apt"; exit 4; }
  fi
  kv "TNM_MEM_KIB=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  mkdir -p "$BASE"
  kv "TNM_DISK_GB=$(df -BG --output=avail "$BASE" 2>/dev/null | tail -1 | tr -dc 0-9)"
  kv "TNM_OK=check"
  ;;
unpack)
  src=${2:?unpack SRC NAME SHA}; name=${3:?unpack SRC NAME SHA}
  want=$(printf '%s' "${4:-}" | tr 'A-F' 'a-f')
  # The name (the install directory under ~/thenewminer) is the package file's name without .tar.xz: a plain
  # release (TheNewMiner-v...-linux-x86_64), the sealed / plain-engine variant (-sealed / -plain), each maybe -rN.
  case "$name" in
    TheNewMiner-v*-linux-x86_64 | TheNewMiner-v*-linux-x86_64-sealed | TheNewMiner-v*-linux-x86_64-plain) ;;
    TheNewMiner-v*-linux-x86_64-r[0-9]* | TheNewMiner-v*-linux-x86_64-sealed-r[0-9]* | TheNewMiner-v*-linux-x86_64-plain-r[0-9]*) ;;
    *) say "TNM_FAIL=name $name"; exit 6 ;;
  esac
  printf '%s' "$want" | grep -Eq '^[0-9a-f]{64}$' || { say "TNM_FAIL=no-sha"; exit 9; }
  mkdir -p "$BASE"; dir=$BASE/$name
  if [ -n "$(pids_in "$dir")" ]; then say "TNM_FAIL=running $dir"; exit 5; fi
  [ -f "$src" ] || { say "TNM_FAIL=missing $src"; exit 6; }
  # room for the copy, the unpacked files and the old version kept beside them (the unpacked size is a few times the .tar.xz)
  size_kb=$(( $(stat -c %s "$src") / 1024 + 1 ))
  need_kb=$(( size_kb * 6 + 262144 ))
  avail_kb=${TNM_WSL_AVAIL_KB:-$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2 {print $4}')}
  if [ -n "$avail_kb" ] && [ "$avail_kb" -lt "$need_kb" ]; then
    msg no_space $(( need_kb / 1024 )) $(( avail_kb / 1024 )); say "TNM_FAIL=disk"; exit 8
  fi
  # Copy the package into WSL's own disk first and check THAT copy: what is unpacked is exactly what was verified.
  stage=$(mktemp -d "$BASE/.stage.XXXXXX"); chmod 700 "$stage"
  if ! cp "$src" "$stage/pkg.tar.xz"; then rm -rf "$stage"; say "TNM_FAIL=copy"; exit 6; fi
  got=$(sha256sum "$stage/pkg.tar.xz" | awk '{print $1}')
  if [ "$got" != "$want" ]; then rm -rf "$stage"; msg sha_again_bad "$got"; say "TNM_FAIL=sha $got"; exit 9; fi
  tmp=$(mktemp -d "$BASE/.unpack.XXXXXX")
  if ! tar -xJf "$stage/pkg.tar.xz" -C "$tmp"; then rm -rf "$tmp" "$stage"; say "TNM_FAIL=tar"; exit 6; fi
  rm -rf "$stage"
  # The package's top directory may be the versioned name or simply "thenewminer" (the sealed release). Take the
  # one directory that holds the ./thenewminer program, whatever it is called.
  top=""
  for c in "$tmp"/*/; do
    if [ -x "$c/thenewminer" ]; then top=${c%/}; break; fi
  done
  if [ -z "$top" ]; then rm -rf "$tmp"; say "TNM_FAIL=layout (no */thenewminer in the package)"; exit 6; fi
  if [ -d "$dir" ]; then
    cp -a "$top/." "$dir/"           # the same version again: new program files, its .miner (install, settings) kept
  else
    mv "$top" "$dir"
  fi
  rm -rf "$tmp"
  prev=$(installed_dir || true)
  if [ -n "$prev" ] && [ "$prev" != "$dir" ] && [ -f "$prev/.miner/mining.json" ] && [ ! -f "$dir/.miner/mining.json" ]; then
    mkdir -p "$dir/.miner"
    cp -p "$prev/.miner/mining.json" "$dir/.miner/"
    [ -f "$prev/.miner/thenewminer.json" ] && cp -p "$prev/.miner/thenewminer.json" "$dir/.miner/"
    msg carried "${prev##*/}"
  fi
  ln -sfn "$dir" "$CUR"
  migrate_models
  prune "$dir" "$prev"
  # the kit's marker (never the front's .miner/installed): the version, the revision (-rN, 1 without) and the bundle
  # sha256 (verified twice above). Routing on later launches reads this; it never re-verifies an installed bundle.
  ver=$(name_version "$name")
  { printf 'version=%s\n' "$ver"; printf 'revision=%s\n' "$(name_rev "$name")"; printf 'bundle_sha256=%s\n' "$want"; } > "$dir/$KIT_MARKER"
  say "TNM_DIR=$dir"
  ;;
installed)
  migrate_models
  d=$(installed_dir)
  if [ -z "$d" ]; then
    say "TNM_INSTALLED_VERSION="; say "TNM_INSTALLED_REV="; say "TNM_INSTALLED_SHA="; say "TNM_HAVE_CONFIG=no"
    if have_model ""; then say "TNM_HAVE_MODEL=yes"; else say "TNM_HAVE_MODEL=no"; fi
    exit 0
  fi
  ver=$(kit_value "$d" version); rev=$(kit_value "$d" revision); sha=$(kit_value "$d" bundle_sha256)
  [ -n "$ver" ] || ver=$(name_version "${d##*/}")
  [ -n "$rev" ] || rev=$(name_rev "${d##*/}")
  say "TNM_INSTALLED_VERSION=$ver"
  say "TNM_INSTALLED_REV=$rev"
  say "TNM_INSTALLED_SHA=$sha"
  if [ -x "$d/thenewminer" ] && [ -f "$d/.miner/mining.json" ]; then say "TNM_HAVE_CONFIG=yes"; else say "TNM_HAVE_CONFIG=no"; fi
  if have_model "$d"; then say "TNM_HAVE_MODEL=yes"; else say "TNM_HAVE_MODEL=no"; fi
  ;;
settings)
  d=$(installed_dir)
  if [ -n "$d" ] && [ -f "$d/.miner/mining.json" ]; then
    python3 - "$d/.miner/mining.json" "$d/.miner/thenewminer.json" <<'PY'
import json, sys
m = json.load(open(sys.argv[1]))
w = m.get('WALLET_ADDRESS', '')
print('TNM_SET_WALLET=' + (w[:8] + '...' + w[-6:] if len(w) > 16 else w))
print('TNM_SET_WORKER=' + m.get('WORKER_NAME', ''))
try:
    p = json.load(open(sys.argv[2])).get('proxy') or 'direct'
except (OSError, ValueError):
    p = 'direct'
print('TNM_SET_PROXY=' + p)
PY
  else
    say "TNM_SET=none"
  fi
  ;;
logmark)
  # the install in use and its log's line count now (a test reads only the lines written after this)
  d=$(installed_dir)
  say "TNM_LOGDIR=${d:-none}"
  n=0; [ -n "$d" ] && n=$(grep -c '' "$d/.miner/thenewminer.log" 2>/dev/null); say "TNM_LOGLINES=${n:-0}"
  ;;
running)
  d=$(installed_dir)
  if miner_running "$d"; then say yes; else say no; fi
  ;;
run)
  shift
  migrate_models
  d=$(installed_dir)
  [ -n "$d" ] && [ -x "$d/thenewminer" ] || { msg not_installed; say "TNM_FAIL=not-installed"; exit 7; }
  cd "$d" && exec ./thenewminer "$@"
  ;;
logs|stop)
  d=$(installed_dir)
  [ -n "$d" ] && [ -x "$d/thenewminer" ] || { msg not_installed; say "TNM_FAIL=not-installed"; exit 7; }
  cd "$d" && exec ./thenewminer "--$1"
  ;;
status)
  d=$(installed_dir)
  [ -n "$d" ] || { say "TNM_RUNNING=no"; msg not_installed; exit 0; }
  if miner_running "$d"; then say "TNM_RUNNING=yes"; else say "TNM_RUNNING=no"; fi
  say "TNM_VERSION=${d##*/}"
  tail -n 2000 "$d/.miner/thenewminer.log" 2>/dev/null | strip | grep -a 'N/s' | tail -3
  ;;
*)
  say "usage: $0 check | unpack SRC NAME SHA | installed | settings | logmark | running | run [ARGS] | logs | stop | status"; exit 2
  ;;
esac
