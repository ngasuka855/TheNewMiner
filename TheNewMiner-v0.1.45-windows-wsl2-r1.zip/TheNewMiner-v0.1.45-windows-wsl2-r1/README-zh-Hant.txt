﻿TheNewMiner Windows 版(WSL2)— 一撳就用
==========================================

TheNewMiner 喺 Windows 內置嘅 WSL2(Linux 子系統)入面行 Linux 版礦工,計算結果同 Linux 一模一樣。
成個礦工都喺呢個 zip 入面,唔使另外下載;只有 WSL/Ubuntu 同 AI 模型會喺安裝時下載。

點用
1. 將成個 zip 解壓(右撳 > 全部解壓縮)去任何位置:任何資料夾、任何磁碟,有空格或者中文嘅路徑都得。
   唔好喺 zip 預覽視窗入面直接開。
2. 雙擊 TheNewMiner.bat。
   - 第一次:檢查 Windows / driver / 硬碟,開 WSL(彈一次管理員確認;可能要重新開機一次,之後會自動繼續),
     顯示資料會放喺邊(撳 Enter 確認),裝好內置嘅礦工,問你錢包 / 密碼 / 礦工名,下載模型,然後開始挖。
   - 之後每次:直接用儲存咗嘅設定開始挖 —— 唔會再問、唔會重裝、唔會再下載。
3. 問到嗰陣輸入:錢包地址(<你的錢包地址>,tc1...)、礦池密碼(<你的礦池密碼>,打兩次)、
   礦工名(直接撳 Enter = 電腦名)。礦池 tsc-wss.the-new.win 已經預設喺程式入面,直接連。

裝好之後桌面會有一個「TheNewMiner」捷徑,下次一撳就開始。

Windows 安全提示
- SmartScreen 可能顯示「Windows 已保護您的電腦」/「不明的發行者」,因為呢個 kit 冇程式碼簽署。
  撳「其他資訊」,再撳「仍要執行」。
- Microsoft Defender 或者其他防毒軟件,好多時會將任何加密貨幣礦工標做「可能不需要的應用程式」,
  就算係你自己揀嚟用嘅正當程式都會。如果佢隔離咗檔案:開「Windows 安全性 > 病毒與威脅防護 > 保護歷程記錄」,
  揀 TheNewMiner 嗰項,撳「允許」(或者將 kit 資料夾加入「排除項目」)。
  只係對由官方發佈頁下載、而且 sha256 核對啱嘅 zip 先咁做。

日常指令(喺呢個資料夾,開命令提示字元)
  TheNewMiner.bat              需要就安裝,然後開始挖(已裝就直接挖)
  TheNewMiner.bat background   背景挖(冇視窗)
  TheNewMiner.bat logs         睇礦工(Ctrl+C 離開,礦工照挖)
  TheNewMiner.bat stop         停
  TheNewMiner.bat status       睇狀態同最近速度
  TheNewMiner.bat setup        重新輸入錢包 / 密碼 / 礦工名
  TheNewMiner.bat uninstall    移除礦工、資料夾同捷徑(會先問你)

檔案放喺邊
- 礦工同佢嘅資料(包括約 8.1 GiB 模型)放喺一個專用嘅 WSL distro「TheNewMiner」。佢個磁碟喺第一次安裝時
  揀定嘅資料夾,唔係喺呢個 kit 資料夾入面:預設係 kit 所在磁碟根目錄嘅 TheNewMinerData(例如 D:\TheNewMinerData),
  如果呢個磁碟係可移除磁碟或者唔夠位,就揀另一個固定磁碟。嗰度要約 20 GB 空位。
  進階:TheNewMiner.bat setup -DataDir <資料夾>。
- 模型第一次開始時下載,之後所有新版本都會繼續用。

升級
將新版本解壓去任何位置,雙擊佢嘅 TheNewMiner.bat。佢會自己搵到已安裝嘅礦工,保留你嘅設定同模型,
冇問題就裝好新版本。之後舊嘅 kit 資料夾可以刪。如果資料夾被刪咗或者個磁碟拔咗,TheNewMiner.bat setup 會重新建立。

語言
畫面文字跟你嘅 Windows 顯示語言(繁體 / 简体 / English)。手動指定:TheNewMiner.bat setup -Lang zh-Hant(或者 zh-Hans、en)。

要求
64 位元 Windows 10 21H2(19044)或更新,或者 Windows 11。NVIDIA 30/40/50 系顯示卡,driver 580 或更新
(喺 Windows 裝,唔好喺 WSL 入面裝)。資料磁碟約 20 GB 空位。BIOS 已開虛擬化。

進階
- TheNewMiner.bat setup -Package <檔案> -Sha256 <64 個字元>:裝指定嘅包代替內置嘅
  (檔案旁邊有 .sha256 或者 SHA256SUMS 都得;冇校驗值嘅包會被拒絕)。
- Proxy(可選):TheNewMiner.bat setup -Proxy IP[:PORT] | socks5://主機:port | http://主機:port
