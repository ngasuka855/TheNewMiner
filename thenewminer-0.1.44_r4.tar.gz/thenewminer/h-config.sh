#!/usr/bin/env bash
# Flight sheet -> thenewminer arguments. The pool is fixed (tsc-wss.the-new.win), so the flight sheet's pool URL is
# ignored; the wallet is the flight sheet's wallet, the password its "pass" field, the rig name HiveOS's
# WORKER_NAME. "Extra config arguments" are passed through (e.g. --report-interval 60, --proxy none).
SELF_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SELF_DIR/h-manifest.conf" || exit 1
source "$SELF_DIR/h-args.sh" || exit 1

WALLET="${CUSTOM_TEMPLATE%% *}"
WALLET="${WALLET:-$CUSTOM_WALLET}"
# A "%WAL%.%WORKER_NAME%" template: the rig name goes to -w, not into the address.
WALLET="${WALLET%%.*}"
[[ "$WALLET" =~ ^tc1 ]] || { echo "thenewminer: the flight sheet wallet must be a tc1... address" >&2; exit 1; }
[[ -n "$CUSTOM_PASS" && "$CUSTOM_PASS" != x ]] || { echo "thenewminer: set the pool password in the flight sheet's Pass field" >&2; exit 1; }

tnp_parse_args "${CUSTOM_USER_CONFIG-}" || exit 1
base=(-u "$WALLET" -p "$CUSTOM_PASS")
[[ -n "${WORKER_NAME-}" ]] && base+=(-w "$WORKER_NAME")
# The conf holds the password: create it 0600 from the start (umask 077 in a subshell), not 0644-then-chmod.
( umask 077; tnp_format_args "${base[@]}" "${TNP_ARGS[@]}" > "$CUSTOM_CONFIG_FILENAME" ) || exit 1
chmod 600 "$CUSTOM_CONFIG_FILENAME"
echo "thenewminer configuration updated"
