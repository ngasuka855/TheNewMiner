#!/usr/bin/env bash
# HiveOS starts the miner here, in the foreground, inside its screen session. The sealed ./thenewminer launcher
# decrypts the real front into RAM (/dev/shm) and runs it; settings, logs and .miner/hive-stats.json persist on
# disk under this directory. We pass the wallet and password in the ENVIRONMENT (TNM_WALLET / TNM_PASSWORD), never
# on the command line, so the pool password never appears in /proc/PID/cmdline (the process list / `ps`). Only -w
# and the flight-sheet extra arguments go on argv. /proc/PID/environ is 0400 (owner only).
SELF_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SELF_DIR/h-manifest.conf" || exit 1
source "$SELF_DIR/h-args.sh" || exit 1
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
[[ -r "$CUSTOM_CONFIG_FILENAME" ]] || { echo "thenewminer: no config ($CUSTOM_CONFIG_FILENAME); apply the flight sheet" >&2; exit 1; }
tnp_parse_args "$(<"$CUSTOM_CONFIG_FILENAME")" || exit 1

# Lift the wallet and the password out of the argv into the environment; keep -w and extra args on argv. No echo of
# either. Both the space form (-p PASS, which h-config always writes) and an inline form (--pass=PASS, which an
# operator might type into the extra-config field) are caught, so neither credential ever lands on the command line.
RUN_ARGS=()
i=0
while (( i < ${#TNP_ARGS[@]} )); do
    case "${TNP_ARGS[i]}" in
        -u|--user|--wallet)   export TNM_WALLET="${TNP_ARGS[i+1]-}";   i=$((i+2)) ;;
        -p|--pass|--password) export TNM_PASSWORD="${TNP_ARGS[i+1]-}"; i=$((i+2)) ;;
        --user=*|--wallet=*)  export TNM_WALLET="${TNP_ARGS[i]#*=}";   i=$((i+1)) ;;
        --pass=*|--password=*) export TNM_PASSWORD="${TNP_ARGS[i]#*=}"; i=$((i+1)) ;;
        *) RUN_ARGS+=("${TNP_ARGS[i]}"); i=$((i+1)) ;;
    esac
done
[[ -n "${TNM_WALLET-}" && -n "${TNM_PASSWORD-}" ]] || { echo "thenewminer: config has no wallet/password; re-apply the flight sheet" >&2; exit 1; }

# The 8.1 GiB model lives OUTSIDE the package dir: HiveOS's custom-get does `rm -rf /hive/miners/custom/thenewminer`
# on every new-version install, which would otherwise re-download it each upgrade. The launcher and the model store
# (ops/model_store.py) honour TNP_MODEL_DIR. Default: /hive/miners/custom/.thenewminer-models on a rig.
export TNP_MODEL_DIR="${TNP_MODEL_DIR:-$(dirname "$SELF_DIR")/.${CUSTOM_NAME}-models}"
mkdir -p "$TNP_MODEL_DIR" && chmod 700 "$TNP_MODEL_DIR"

# HiveOS's miner-run exports LD_LIBRARY_PATH=/hive/lib (and may set LD_PRELOAD for old curl). Our core was tested
# with the system loader path only, so drop both: nothing of ours should resolve from /hive/lib.
unset LD_LIBRARY_PATH LD_PRELOAD

cd "$SELF_DIR" || exit 1
# The miner reads TNM_WALLET/TNM_PASSWORD from the environment (front.rs) when they are not on the command line.
# tee -i: HiveOS's `miner stop` sends ^C to the screen; let tee survive it so the shutdown lines reach the log.
"$SELF_DIR/thenewminer" "${RUN_ARGS[@]}" 2>&1 | tee -ia "${CUSTOM_LOG_BASENAME}.log"
echo "thenewminer has exited"
