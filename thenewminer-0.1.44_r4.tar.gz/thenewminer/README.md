# TheNewMiner(加殼版)

呢個係 TheNewMiner 嘅出貨版本。解壓之後只見到一個程式 `thenewminer` 同一個 `.miner/` 資料夾,行一句就開工。

## 開工

```
cd thenewminer
./thenewminer -u 錢包 -p 密碼 -w 礦機名 --proxy 中繼IP --background
```

- 第一次會自動裝嘢:檢查顯卡、下載模型(約 8.1 GiB,只下載一次,之後重用)、裝 GPU 引擎、喺你張卡上面自測。
- `./thenewminer --stop` 停機。
- 睇即時速度:`./thenewminer --logs`,或睇 `.miner/` 入面嘅 log。
- 要求:x86_64 Ubuntu 22.04 / 24.04 / 26.04(或對應 HiveOS),NVIDIA 驅動 580 或以上,主機最少 4 GB RAM。

## 關於「加殼」(誠實講清楚)

- 包入面**睇唔到**真正嘅礦工程式同 GPU 引擎:佢哋全部用 **ChaCha20-Poly1305(RFC 8439)驗證加密**,封喺 `.miner/seal/core.tnpseal` 一個 blob 入面。對住個包 `tar` / `strings` 係挖唔到引擎 kernel 出嚟嘅。
- 行嘅時候,`thenewminer` 會喺**記憶體**入面解密,解開嘅檔只落喺一個私有、權限 0700、記憶體(tmpfs / RAM)嘅臨時資料夾度行;**唔會寫落任何永久硬碟路徑**。`--stop` 或者重開機,呢啲解密檔就冇咗。
- 模型(8.1 GiB)唔喺 blob 入面:第一次下載到 `.miner/models/` 永久保存、之後每次重用,所以記憶體資料夾唔使裝落個模型。
- **呢層保護只係提高抄襲成本,唔係無得破。** 有機器管理權嘅人,始終可以喺呢個程式度攞到 key、或者喺 RAM 度攞到解密咗嘅引擎。我哋真正嘅優勢係**速度同顯卡覆蓋**,唔係個殼。

## 唔會改到計算

加殼只係一層包裝:解密出嚟嘅引擎同模型,同未加殼嘅 v0.1.44 **逐 byte 一樣**,所以出嘅 proof 數值完全一樣。`SEALED.json` 記錄咗來源 commit、來源 plain 包嘅 sha256、用咗咩加密同封入面有咩(member 清單),可以自己核對。
