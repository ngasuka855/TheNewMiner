#!/usr/bin/env bash
# HiveOS stats from .miner/hive-stats.json, which thenewminer rewrites at every rate line: one entry per GPU in PCI
# bus order (a rig mines every card), with its bus number in decimal as HiveOS's bus_numbers wants. The unit is
# TensorCash's N/s (completed windows per second), shown as "hs" so a tile reads e.g. 65 rather than 0.065 kH/s; the
# farm line (khs) is N/s / 1000. A file older than 3 minutes means the miner is not running: zeros.
# HiveOS sources this script: no exit, only $khs and $stats.
SELF_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SELF_DIR/h-manifest.conf"
stats_file="${THENEWMINER_STATS:-$SELF_DIR/.miner/hive-stats.json}"
stats_age=$(( $(date +%s) - $(stat -c %Y "$stats_file" 2>/dev/null || echo 0) ))
if [[ ! -s "$stats_file" ]] || (( stats_age > 180 )) || ! jq -e .cards "$stats_file" >/dev/null 2>&1; then
    stats=$(jq -nc --arg ver "$CUSTOM_VERSION" '{total_khs: 0, khs: 0, hs_units: "hs", hs: [0], temp: [0], fan: [0], uptime: 0, ver: $ver, ar: [0, 0], algo: "tensorcash"}')
else
    stats=$(jq -c --arg ver "$CUSTOM_VERSION" '{
        total_khs: ((.total // 0) / 1000), khs: ((.total // 0) / 1000), hs_units: "hs",
        hs: [.cards[] | (.hs // 0)], temp: [.cards[] | (.temp // 0)], fan: [.cards[] | (.fan // 0)],
        bus_numbers: [.cards[] | (.bus // 0)],
        uptime: (.uptime // 0), ver: (.ver // $ver),
        ar: [(.accepted // 0), (.rejected // 0)], algo: "tensorcash"}' "$stats_file")
fi
khs=$(echo "$stats" | jq -r .total_khs)
echo "khs:   $khs"
echo "stats: $stats"
echo "----------"
