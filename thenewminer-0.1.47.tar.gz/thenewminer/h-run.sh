#!/usr/bin/env bash
# HiveOS starts the miner here, in the foreground, inside its screen session. The sealed ./thenewminer launcher
# decrypts the real front into RAM (/dev/shm) and runs it; settings, logs and .miner/hive-stats.json persist on
# disk under this directory. We pass the wallet and password in the ENVIRONMENT (TNM_WALLET / TNM_PASSWORD), never
# on the command line, so the pool password never appears in /proc/PID/cmdline (the process list / `ps`). Only -w
# and the flight-sheet extra arguments go on argv. /proc/PID/environ is 0400 (owner only).
SELF_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SELF_DIR/h-manifest.conf" || exit 1
source "$SELF_DIR/h-args.sh" || exit 1
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
[[ -r "$CUSTOM_CONFIG_FILENAME" ]] || { echo "thenewminer: no config ($CUSTOM_CONFIG_FILENAME); apply the flight sheet" >&2; exit 1; }
tnp_parse_args "$(<"$CUSTOM_CONFIG_FILENAME")" || exit 1

# Lift the wallet and the password out of the argv into the environment; keep -w and extra args on argv. No echo of
# either. Both the space form (-p PASS, which h-config always writes) and an inline form (--pass=PASS, which an
# operator might type into the extra-config field) are caught, so neither credential ever lands on the command line.
RUN_ARGS=()
i=0
while (( i < ${#TNP_ARGS[@]} )); do
    case "${TNP_ARGS[i]}" in
        -u|--user|--wallet)   export TNM_WALLET="${TNP_ARGS[i+1]-}";   i=$((i+2)) ;;
        -p|--pass|--password) export TNM_PASSWORD="${TNP_ARGS[i+1]-}"; i=$((i+2)) ;;
        --user=*|--wallet=*)  export TNM_WALLET="${TNP_ARGS[i]#*=}";   i=$((i+1)) ;;
        --pass=*|--password=*) export TNM_PASSWORD="${TNP_ARGS[i]#*=}"; i=$((i+1)) ;;
        *) RUN_ARGS+=("${TNP_ARGS[i]}"); i=$((i+1)) ;;
    esac
done
[[ -n "${TNM_WALLET-}" && -n "${TNM_PASSWORD-}" ]] || { echo "thenewminer: config has no wallet/password; re-apply the flight sheet" >&2; exit 1; }

# The 8.1 GiB model lives OUTSIDE the package dir: HiveOS's custom-get does `rm -rf /hive/miners/custom/thenewminer`
# on every new-version install, which would otherwise re-download it each upgrade. The launcher and the model store
# (ops/model_store.py) honour TNP_MODEL_DIR. Default: /hive/miners/custom/.thenewminer-models on a rig.
export TNP_MODEL_DIR="${TNP_MODEL_DIR:-$(dirname "$SELF_DIR")/.${CUSTOM_NAME}-models}"
mkdir -p "$TNP_MODEL_DIR" && chmod 700 "$TNP_MODEL_DIR"
# v0.1.46: the CUDA compute cache lives beside the package too (a boot's HOME=/home/user and an SSH `miner start`'s
# /root then share it), so the first start's GPU compile is kept across restarts, reboots and upgrades.
CACHE_DIR="$(dirname "$SELF_DIR")/.${CUSTOM_NAME}-cache"
export CUDA_CACHE_PATH="${CUDA_CACHE_PATH:-$CACHE_DIR/nv}"
mkdir -p "$CUDA_CACHE_PATH" 2>/dev/null || true

# HiveOS's miner-run exports LD_LIBRARY_PATH=/hive/lib (and may set LD_PRELOAD for old curl). Our core was tested
# with the system loader path only, so drop both: nothing of ours should resolve from /hive/lib.
unset LD_LIBRARY_PATH LD_PRELOAD

cd "$SELF_DIR" || exit 1
# v0.1.47 (acceptance matrix blind spot 4): what the HiveOS dashboard shows while the miner has no rate - installing, or
# waiting after a failure with its reason - one short line that h-stats.sh puts beside the version.
STATE_FILE="$SELF_DIR/.miner/hive-state"
mkdir -p "$SELF_DIR/.miner" 2>/dev/null
hive_state() { printf '%s\n' "$1" > "$STATE_FILE" 2>/dev/null || true; }
if [[ -f $SELF_DIR/.miner/installed ]]; then hive_state "starting"; else hive_state "installing (first start)"; fi
# review: the reason must be this run's - a launcher that fails before the front runs records none
rm -f "$SELF_DIR/.miner/thenewminer.stopped" 2>/dev/null
rc=0
if [[ ! -x "$SELF_DIR/thenewminer" ]]; then
    # access(X_OK) fails on a noexec mount too: the kernel would refuse to run it with a bare "Permission denied"
    echo "thenewminer: $SELF_DIR/thenewminer cannot be run here (its folder is mounted noexec, or the file lost its execute permission): reinstall the miner from the flight sheet" | tee -ia "${CUSTOM_LOG_BASENAME}.log"
    printf '%s\n' "the miner file cannot be run (noexec folder or lost permission): reinstall the miner" "$(date -u '+%F %T UTC')" > "$SELF_DIR/.miner/thenewminer.stopped" 2>/dev/null
    rc=126
else
# The miner reads TNM_WALLET/TNM_PASSWORD from the environment (front.rs) when they are not on the command line.
# tee -i: HiveOS's `miner stop` sends ^C to the screen; let tee survive it so the shutdown lines reach the log.
"$SELF_DIR/thenewminer" "${RUN_ARGS[@]}" 2>&1 | tee -ia "${CUSTOM_LOG_BASENAME}.log"
rc=${PIPESTATUS[0]}
fi
echo "thenewminer has exited"
# Why it stopped, as the miner recorded it (front.rs record_stop: the first line), for this log and the dashboard.
REASON=$(head -1 "$SELF_DIR/.miner/thenewminer.stopped" 2>/dev/null | tr -d '\r' | cut -c1-200)
# v0.1.45 (audit R1): exit 77 = the pool rejected the wallet / password (or has not approved the account). HiveOS
# restarts a miner that exits; retrying the same credentials cannot succeed and the pool asks miners not to, so wait
# here (10 min) until the flight sheet is fixed (applying it restarts the miner at once).
if [[ $rc == 77 ]]; then
    hive_state "wrong wallet/password: fix the flight sheet"
    echo "thenewminer: the pool rejected the wallet / password - fix them in the flight sheet (waiting 10 min before HiveOS retries)" | tee -ia "${CUSTOM_LOG_BASENAME}.log"
    sleep "${TNP_CREDENTIALS_RETRY_S:-600}"
fi
# v0.1.46 (docs/handoffs/HIVEOS-FIRSTRUN-20261023.md fix 4): exit 78 = the one-time configuration for this GPU could not be
# prepared (its Reason: line is just above in the log). HiveOS restarts a miner 3 s after it exits; wait instead, 60 s
# and doubling up to 10 min (TNP_CAPTURE_RETRY_S / TNP_CAPTURE_RETRY_MAX_S), counted in a file beside the package so the
# pause grows across HiveOS's restarts. A count older than an hour starts again (a rig that mined for days and then
# fails once starts again from 60 s).
# v0.1.47 (acceptance matrix blind spot 4): the same for EVERY failure, not only 78 - an install that stops on the driver,
# the disk or the network (exit 1, 20-23) restarted every 3 s for ever, re-running the install each time, with the
# reason only somewhere in the log. Now it waits the same growing pause and says why (the miner's recorded reason) in the
# log and on the dashboard. Only a clean end (exit 0: HiveOS's own `miner stop`, or a stop) resets the count.
BACKOFF_FILE="$CACHE_DIR/start-retries"
rm -f "$CACHE_DIR/capture-retries" 2>/dev/null          # v0.1.46's name for the same count
if [[ $rc != 0 && $rc != 77 ]]; then
    n=$(cat "$BACKOFF_FILE" 2>/dev/null); [[ $n =~ ^[0-9]{1,6}$ ]] || n=0; n=$((10#$n))
    [[ -n $(find "$BACKOFF_FILE" -mmin +60 2>/dev/null) ]] && n=0
    base=${TNP_CAPTURE_RETRY_S:-60}; [[ $base =~ ^[0-9]{1,5}$ ]] || base=60
    max=${TNP_CAPTURE_RETRY_MAX_S:-600}; [[ $max =~ ^[0-9]{1,5}$ ]] || max=600
    wait_s=$base; for ((k = 0; k < n && wait_s < max; k++)); do wait_s=$((wait_s * 2)); done
    (( wait_s > max )) && wait_s=$max
    mkdir -p "$CACHE_DIR" 2>/dev/null; echo $((n + 1)) > "$BACKOFF_FILE" 2>/dev/null
    if [[ $rc == 78 ]]; then
        hive_state "GPU setup failed, retry in ${wait_s}s"
        echo "thenewminer: could not prepare the configuration for this GPU (attempt $((n + 1)); the Reason: line above says why) - waiting ${wait_s} s before HiveOS retries" | tee -ia "${CUSTOM_LOG_BASENAME}.log"
    else
        hive_state "retry in ${wait_s}s: ${REASON:-exit $rc}"
        echo "thenewminer: not mining (exit $rc, attempt $((n + 1))): ${REASON:-the lines above say why} - fix it, or wait: HiveOS retries in ${wait_s} s" | tee -ia "${CUSTOM_LOG_BASENAME}.log"
    fi
    sleep "$wait_s"
elif [[ $rc == 0 ]]; then
    rm -f "$BACKOFF_FILE" "$STATE_FILE" 2>/dev/null
fi
exit "$rc"
