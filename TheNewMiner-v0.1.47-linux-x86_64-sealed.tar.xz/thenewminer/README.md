# TheNewMiner

**English** · [简体中文](#简体中文)

TheNewMiner is a GPU miner for **TensorCash**. It mines on the pool `tsc-wss.the-new.win` (built in, 0% fee) with an
NVIDIA GeForce RTX 30, 40 or 50 series card that has 10 GB of VRAM or more.

## Start

```bash
cd thenewminer
./thenewminer -u <YOUR_WALLET> -p <YOUR_POOL_PASSWORD> -w rig-01 --background
```

| Command | What it does |
|---|---|
| `./thenewminer -u <YOUR_WALLET> -p <YOUR_POOL_PASSWORD> -w rig-01 --background` | First start: installs what is needed, then mines in the background |
| `./thenewminer --background` | Later starts: your settings are remembered |
| `./thenewminer` | Mine in the foreground (Ctrl+C stops) |
| `./thenewminer --logs` | Watch the miner (Ctrl+C leaves the view; mining continues) |
| `./thenewminer --status` | Whether it is mining, its last rate line and accepted / rejected shares |
| `./thenewminer --stop` | Stop mining |
| `./thenewminer --help` | All options |

- `-u` is your TensorCash wallet address, `-p` your pool password, `-w` the worker name shown on the pool
  (default: the machine's host name).
- The pool password: 6-128 characters, any visible character (punctuation and non-English letters too), no spaces.
  If it contains shell characters such as `$ ! " ' \` `` ` ``, quote it for your shell, e.g. `-p 'my$pass!'` (a `'` inside
  single quotes is written `'\''`).
- Your settings are saved in `thenewminer/.miner/` (the file with the password is readable only by you). The wallet
  and the password are taken off the command line at once, so other users of the machine do not see them in `ps`
  (your shell may still keep the command in its history).
- The first start downloads the model (about 8.1 GiB, once), installs the GPU engine for your card and runs a
  self-check on the card, then mines. Lines like `[ RATE] ... N/s` mean it is mining.
- The log is `thenewminer/.miner/thenewminer.log`.
- **Upgrade:** `./thenewminer --stop`, unpack the new package in the same place (your settings and the model in
  `thenewminer/.miner/` are kept), then start it again. Unpacked into a new folder instead, it finds the model of the
  old one (same size and SHA-256) and reuses it: no second 8.1 GiB download. Give `-u -p -w` again there.
- **If it stops,** `./thenewminer --status` says why and how to fix it (also after a `--background` start).
- On the first start of a single-GPU machine the miner checks your wallet and pool password with the pool **before**
  the 8.1 GiB download, so a typo is found in seconds (a multi-GPU rig finds it when mining starts).

## Proxy (optional)

The miner connects to the pool directly. If your network needs a proxy, add one of these (it is remembered):

```bash
./thenewminer --proxy <IP>[:<PORT>]            # TCP relay (port 443 if omitted)
./thenewminer --proxy socks5://<HOST>:<PORT>   # SOCKS5, also socks5://<USER>:<PASS>@<HOST>:<PORT>
./thenewminer --proxy http://<HOST>:<PORT>     # HTTP CONNECT proxy
./thenewminer --proxy none                     # back to a direct connection
```

TLS always runs end to end with the pool, so the proxy cannot read the connection.

## When it does not mine

| You see | What to do |
|---|---|
| `bash: ./thenewminer: Permission denied` | The folder does not allow programs (a `noexec` mount such as some `/tmp`, or a USB stick). Unpack it in your home folder: `cd ~ && tar -xJf <the package>.tar.xz && cd thenewminer` |
| `this package is on a FAT (vfat) drive` (or exFAT / NTFS, or `Windows (DrvFs, 9p)`: a Windows drive such as `/mnt/d` in WSL) | Such a drive cannot keep the miner's private settings (mode 600). Paste the `mkdir -p ~/thenewminer && cp -a ...` line it prints: it copies the folder to your Linux home folder and starts it there |
| `... cannot be kept private: it is mode ... after setting 600` | The same: the folder is on a drive without Linux permissions; paste the copy line it prints |
| `this system has no xz` | `sudo apt-get install -y xz-utils` (as root: without `sudo`), then start again |
| `This system is missing what TheNewMiner needs` | Run the `sudo apt-get install -y ...` line it prints, then start again |
| `No NVIDIA GPU found on this machine` | No NVIDIA card is seen. Check the card is seated and powered; on a cloud machine choose one with an NVIDIA GPU |
| `NVIDIA driver ... is too old` | Install the driver it names (580 or newer), reboot, start again. Debian: it prints NVIDIA's repository commands |
| `the pool rejected the wallet / password` | Check `-u` and `-p` (and that the pool has approved your account), then `./thenewminer -u <YOUR_WALLET> -p <YOUR_POOL_PASSWORD> --background` |
| `no download source answered` | The model download cannot reach the internet. Behind a proxy: `https_proxy=http://<HOST>:<PORT> ./thenewminer --background`; or copy `Qwen3-8B-Q8_0-full-v2.gguf` here and use `--model /path/to/it` |
| `cannot reach the pool` / `pool disconnected` | Check the internet connection and that the firewall allows outbound TCP 443; if your network blocks the pool, use `--proxy` (above). It reconnects by itself |

## Start after a reboot (optional)

The miner does not start by itself after a reboot (HiveOS does this for you). On Linux, either:

```bash
crontab -e      # then add this line (your folder):
@reboot cd /home/<YOU>/thenewminer && ./thenewminer --background
```

or a systemd user service (`loginctl enable-linger <YOU>` once, so it starts without a login):

```ini
# ~/.config/systemd/user/thenewminer.service, then: systemctl --user enable --now thenewminer
[Unit]
Description=TheNewMiner
After=network-online.target
[Service]
WorkingDirectory=%h/thenewminer
ExecStart=%h/thenewminer/thenewminer
ExecStop=%h/thenewminer/thenewminer --stop
Restart=on-failure
RestartSec=60
RestartPreventExitStatus=77
[Install]
WantedBy=default.target
```

Exit status 77 means the pool rejected the wallet / password: restarting cannot help, so the service stops there.

## Requirements

| Item | Requirement |
|---|---|
| GPU | NVIDIA GeForce RTX 30 / 40 / 50 series, 10 GB VRAM or more. Multi-GPU rigs: supported, each GPU mines; tested on 1 GPU per machine in this release |
| Driver | NVIDIA **580 or newer** (`nvidia-smi` must work) |
| System | x86_64 Linux with **glibc 2.34 or newer**, for example Ubuntu 22.04 or newer, Debian 12 or newer, or HiveOS on its Ubuntu 22.04 base (**HiveOS: experimental**, run once on a single-GPU HiveOS rig). The installer checks what it needs and names anything missing |
| Tools | `tar` and `xz`. If `tar` says `xz: Cannot exec`: `sudo apt-get install -y xz-utils` |
| Disk | about 20 GB free |
| RAM | 4 GB or more |

A stock Ubuntu 22.04 / 24.04 (WSL's included) already has every library the miner needs, so nothing is installed. Where
one is missing (Docker images, minimal systems), the first start on Ubuntu, Debian and HiveOS installs it with `apt`
(needs sudo or root); on other systems it names it for you to install.

The program files are unpacked into `/dev/shm` (memory). If it is too small (Docker's default is 64 MiB) or does not
allow running programs, the miner uses `thenewminer/.miner/run/` on disk instead and says so; to choose another
folder, start it with `TNPSEAL_RUNTIME_BASE=<folder> ./thenewminer` (a folder only you can write to: `chmod 700 <folder>`).

## Security note

The miner and the GPU engine are shipped encrypted (ChaCha20-Poly1305) in `.miner/seal/`. When it starts, the miner
decrypts its program files into a private directory in memory (RAM) that only your user can open (or, when `/dev/shm`
cannot be used, into the private `thenewminer/.miner/run/` on disk, removed when the miner stops); your settings,
the log, the model and the GPU engine installed for your card are kept on disk in `thenewminer/.miner/`. This raises
the cost of copying the miner, but it is **not unbreakable**: anyone with administrator access to a machine running
it can, with enough effort, recover the key or the decrypted code. Your wallet address and pool password are stored
on your own machine and sent only to the pool. `SEALED.json` records what was sealed and how.

---

# 简体中文

[English](#thenewminer) · **简体中文**

TheNewMiner 是 **TensorCash** 的 GPU 矿工,使用显存 10 GB 或以上的 NVIDIA GeForce RTX 30 / 40 / 50 系列显卡,
连接矿池 `tsc-wss.the-new.win`(已内置,0% 手续费)。

## 启动

```bash
cd thenewminer
./thenewminer -u <你的钱包地址> -p <你的矿池密码> -w rig-01 --background
```

| 命令 | 作用 |
|---|---|
| `./thenewminer -u <你的钱包地址> -p <你的矿池密码> -w rig-01 --background` | 第一次启动:自动安装所需组件,然后在后台挖矿 |
| `./thenewminer --background` | 之后启动:设置已记住,无需再输入 |
| `./thenewminer` | 在前台挖矿(Ctrl+C 停止) |
| `./thenewminer --logs` | 查看矿工运行情况(Ctrl+C 退出查看,挖矿不会中断) |
| `./thenewminer --status` | 是否正在挖矿、最近一行算力,以及接受 / 拒绝的份额数 |
| `./thenewminer --stop` | 停止挖矿 |
| `./thenewminer --help` | 全部选项 |

- `-u` 是你的 TensorCash 钱包地址,`-p` 是矿池密码,`-w` 是在矿池上显示的矿工名(默认:本机主机名)。
- 矿池密码:6-128 个字符,任何可见字符都可以(包括标点和中文),但不能有空格。密码里有 `$ ! " ' \` `` ` `` 这类
  shell 字符时,在命令行上要加引号,例如 `-p 'my$pass!'`(单引号里面的 `'` 写成 `'\''`)。
- 设置保存在 `thenewminer/.miner/` 中(保存密码的文件只有你本人可读)。钱包地址和密码会立即从命令行中移除,
  本机的其他用户用 `ps` 看不到(命令行历史中可能仍保留这条命令)。
- 第一次启动会下载模型(约 8.1 GiB,只下载一次)、安装适合你显卡的 GPU 引擎,并在你的显卡上自检,然后开始挖矿。
  看到 `[ RATE] ... N/s` 这样的行,就表示正在挖矿。
- 日志文件是 `thenewminer/.miner/thenewminer.log`。
- **升级:** 先 `./thenewminer --stop`,在同一位置解压新版本(`thenewminer/.miner/` 中的设置和模型会保留),
  然后重新启动。如果解压到新的文件夹,矿工会找到旧文件夹里的模型(大小和 SHA-256 都相同)并直接使用,不会再下载
  8.1 GiB;在新文件夹里要重新给出 `-u -p -w`。
- **如果停了,** `./thenewminer --status` 会说明原因和解决方法(用 `--background` 启动后也一样)。
- 单卡机器第一次启动时,矿工会在下载 8.1 GiB 模型**之前**先向矿池核对钱包地址和矿池密码,输错了几秒内就会知道
  (多卡矿机在开始挖矿时才核对)。

## 代理(可选)

矿工默认直接连接矿池。如果你的网络需要代理,加上以下其中一项(会被记住):

```bash
./thenewminer --proxy <IP>[:<端口>]             # TCP 中转(不写端口则为 443)
./thenewminer --proxy socks5://<主机>:<端口>    # SOCKS5,也支持 socks5://<用户名>:<密码>@<主机>:<端口>
./thenewminer --proxy http://<主机>:<端口>      # HTTP CONNECT 代理
./thenewminer --proxy none                      # 恢复直接连接
```

TLS 始终与矿池端到端加密,代理无法读取连接内容。

## 没有在挖矿时

| 你看到 | 怎么做 |
|---|---|
| `bash: ./thenewminer: Permission denied` | 这个文件夹不允许运行程序(`noexec` 挂载,例如某些 `/tmp`,或 U 盘)。解压到你的主目录:`cd ~ && tar -xJf <安装包>.tar.xz && cd thenewminer` |
| `this package is on a FAT (vfat) drive`(或 exFAT / NTFS,或 `Windows (DrvFs, 9p)`:WSL 里的 Windows 磁盘,例如 `/mnt/d`) | 这种磁盘保存不了矿工的私有设置(权限 600)。粘贴它显示的 `mkdir -p ~/thenewminer && cp -a ...` 那一行:把文件夹复制到 Linux 主目录并在那里启动 |
| `... cannot be kept private: it is mode ... after setting 600` | 同上:文件夹在没有 Linux 权限的磁盘上,粘贴它显示的复制命令 |
| `this system has no xz` | `sudo apt-get install -y xz-utils`(root 用户不用 `sudo`),然后重新启动 |
| `This system is missing what TheNewMiner needs` | 运行它显示的 `sudo apt-get install -y ...` 那一行,然后重新启动 |
| `No NVIDIA GPU found on this machine` | 系统看不到 NVIDIA 显卡。检查显卡是否插好、供电线是否接好;云服务器请选带 NVIDIA GPU 的机型 |
| `NVIDIA driver ... is too old` | 安装它指出的驱动(580 或更新),重启后再启动。Debian:它会显示 NVIDIA 软件源的命令 |
| `the pool rejected the wallet / password` | 检查 `-u` 和 `-p`(以及矿池是否已批准你的账户),然后 `./thenewminer -u <你的钱包地址> -p <你的矿池密码> --background` |
| `no download source answered` | 下载模型时连不上网络。需要代理上网:`https_proxy=http://<主机>:<端口> ./thenewminer --background`;或者把 `Qwen3-8B-Q8_0-full-v2.gguf` 复制到本机,用 `--model /文件路径` |
| `cannot reach the pool` / `pool disconnected` | 检查网络连接,以及防火墙是否允许对外的 TCP 443;如果你的网络屏蔽了矿池,使用 `--proxy`(见上文)。它会自动重连 |

## 开机自动启动(可选)

重启后矿工不会自己启动(HiveOS 会帮你启动)。在 Linux 上,二选一:

```bash
crontab -e      # 然后加入这一行(换成你的文件夹):
@reboot cd /home/<你的用户名>/thenewminer && ./thenewminer --background
```

或者 systemd 用户服务(先运行一次 `loginctl enable-linger <你的用户名>`,不登录也能启动):

```ini
# ~/.config/systemd/user/thenewminer.service,然后:systemctl --user enable --now thenewminer
[Unit]
Description=TheNewMiner
After=network-online.target
[Service]
WorkingDirectory=%h/thenewminer
ExecStart=%h/thenewminer/thenewminer
ExecStop=%h/thenewminer/thenewminer --stop
Restart=on-failure
RestartSec=60
RestartPreventExitStatus=77
[Install]
WantedBy=default.target
```

退出码 77 表示矿池拒绝了钱包地址或密码:重启也没用,所以服务会停在那里。

## 系统要求

| 项目 | 要求 |
|---|---|
| 显卡 | NVIDIA GeForce RTX 30 / 40 / 50 系列,显存 10 GB 或以上。多卡矿机:支持,每块显卡各自挖矿;本版本只在每台机器 1 块显卡上测试过 |
| 驱动 | NVIDIA **580 或更新**(`nvidia-smi` 能正常运行) |
| 系统 | x86_64 Linux,**glibc 2.34 或更新**,例如 Ubuntu 22.04 或更新、Debian 12 或更新,或基于 Ubuntu 22.04 的 HiveOS(**HiveOS:实验性支持**,已在单卡 HiveOS 矿机上运行过一次)。安装程序会检查所需组件,并指出缺少的部分 |
| 工具 | `tar` 和 `xz`。如果 `tar` 提示 `xz: Cannot exec`:`sudo apt-get install -y xz-utils` |
| 硬盘 | 约 20 GB 可用空间 |
| 内存 | 4 GB 或以上 |

标准的 Ubuntu 22.04 / 24.04(包括 WSL 的)已经有矿工需要的全部系统库,不会安装任何东西。缺少时(Docker 镜像、精简系统),
在 Ubuntu、Debian 和 HiveOS 上第一次启动会用 `apt` 安装(需要 sudo 或 root);其他系统会列出来让你自己安装。

程序文件会解压到 `/dev/shm`(内存)。如果空间不够(Docker 默认只有 64 MiB)或者不允许运行程序,矿工会改用硬盘上的
`thenewminer/.miner/run/`,并会提示;如需指定其他文件夹,用 `TNPSEAL_RUNTIME_BASE=<文件夹> ./thenewminer` 启动(只有你能写入的文件夹:`chmod 700 <文件夹>`)。

## 安全说明

矿工程序和 GPU 引擎以加密形式(ChaCha20-Poly1305)存放在 `.miner/seal/` 中。启动时,矿工把程序文件解密到内存(RAM)中
一个只有你本人能访问的私有目录(`/dev/shm` 不能用时,改为硬盘上私有的 `thenewminer/.miner/run/`,矿工停止时删除);你的设置、日志、模型以及为你的显卡安装的 GPU 引擎保存在硬盘上的 `thenewminer/.miner/` 中。
这能提高复制的成本,但 **并非无法破解**:任何拥有运行机器管理员权限的人,只要投入足够精力,都能取得密钥或解密后的代码。
你的钱包地址和矿池密码只保存在你自己的机器上,并且只发送给矿池。`SEALED.json` 记录了加密的内容和方式。
